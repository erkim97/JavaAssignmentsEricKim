/**
 * 
 */
package ca.bcit.comp1510.lab8;

/**
 * Driver for the Games java game.
 * @author erickim
 * @version 1.0
 */
public class GamesDriver {

    /**
     * Drives the program.
     * @param args unused
     */
    public static void main(String[] args) {
        Games myGame = new Games();
        myGame.play();
    }

}
