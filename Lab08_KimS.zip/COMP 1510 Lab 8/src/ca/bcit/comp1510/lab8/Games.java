/**
 * 
 */
package ca.bcit.comp1510.lab8;

import java.util.Random;
import java.util.Scanner;

/**
 * Game with random number guessing and rock, paper, scissors with a score
 * tracker.
 * 
 * @author erickim
 * @version 1.0
 */
public class Games {

    /**
     * Tracks the score the user obtains as a int.
     */
    private int userScore;

    /**
     * Initialize scanner object.
     */
    private Scanner scan;

    /**
     * Initialize random object.
     */
    private Random generator;

    /**
     * Magic number.
     */
    private final int three = 3;

    /**
     * Magic number.
     */
    private final int four = 4;

    /**
     * Magic number.
     */
    private final int five = 5;

    /**
     * Magic number.
     */
    private final int oneHundredOne = 101;

    /**
     * Constructor for games class.
     */
    public Games() {
        userScore = 0;
        scan = new Scanner(System.in);
        generator = new Random();

    }

    /**
     * Method that runs the game menu screen. Called by gamesDriver.
     */
    public void play() {

        do {

            System.out.print("Welcome to the Games Program! " 
            + "\n Make your choice (enter a number): " + "\n 1. See your score"
            + "\n 2. Guess a number" + "\n 3. Play Rock, Paper, Scissors" 
            + "\n 4. Quit" + "\n>");

            int userInput = scan.nextInt();

            if (userInput == 1) {
                System.out.println("Your Score is " + userScore);
            } else if (userInput == 2) {
                guessANumber();

            } else if (userInput == three) {
                rockPaperScissors();

            } else if (userInput == four) {
                System.exit(0);

            } else if (userInput < 1 || userInput > four) {
                System.out.println("That's not a valid choice!");

            }
        } while (true);
    }

    /**
     * Guessing number game method.
     */
    public void guessANumber() {
        int generatedGuess = generator.nextInt(oneHundredOne);

        System.out.println("I've picked a random number between" + " 0 and 100" 
                            + "\nCan you guess it?");
        System.out.println("Guess the number!");

        while (true) {
            int userGuess = scan.nextInt();

            if (userGuess > generatedGuess) {
                System.out.println("Too high, guess again!");
                System.out.println("Guess the number!");
            }

            if (userGuess < generatedGuess) {
                System.out.println("Too low, guess again!");
                System.out.println("Guess the number!");
            }
            if (userGuess == generatedGuess) {
                System.out.println("RIGHT!" + "\nFive Points!");
                userScore += five;
                play();
            }
        }
    }

    /**
     * Rock paper scissors game method.
     */
    public void rockPaperScissors() {

        int computerInt = generator.nextInt(three) + 1;
        String personPlay;
        String computerPlay = "";

        if (computerInt == 1) {
            computerPlay = "ROCK";
        } else if (computerInt == 2) {
            computerPlay = "PAPER";
        } else if (computerInt == three) {
            computerPlay = "SCISSORS";
        }

        System.out.print("I've picked one of ROCK, PAPER" + ", and SCISSORS" 
                            + "\nWhich one do you choose?" + "\n>");

        personPlay = scan.next();
        personPlay = personPlay.toUpperCase();

        while (!(personPlay.equals("ROCK") || personPlay.equals("PAPER") 
                || personPlay.equals("SCISSORS"))) {

            System.out.print("That's not a valid choice! Try Again!\n");
            personPlay = scan.next();
            personPlay = personPlay.toUpperCase();

        }
        while (personPlay.equals("ROCK") || personPlay.equals("PAPER") 
                || personPlay.equals("SCISSORS")) {

            if (personPlay.equals(computerPlay)) {
                System.out.println("It's a tie!");
                play();
            } else if (personPlay.equals("ROCK")) {
                if (computerPlay.equals("SCISSORS")) {
                    System.out.println("Rock breaks scissors. You win");
                    userScore += five;
                    play();
                } else if (computerPlay.equals("PAPER")) {
                    System.out.println("Paper wraps Rock. You lose");
                    userScore -= three;
                    play();
                }
            } else if (personPlay.equals("PAPER")) {
                if (computerPlay.equals("SCISSORS")) {
                    System.out.println("Scissor cuts paper. You lose");
                    userScore -= three;
                    play();
                } else if (computerPlay.equals("ROCK")) {
                    System.out.println("Paper wraps Rock. You win");
                    userScore += five;
                    play();
                }
            } else if (personPlay.equals("SCISSORS")) {

                if (computerPlay.equals("PAPER")) {
                    System.out.println("Scissor cuts Paper. You win");
                    userScore += five;
                    play();
                } else if (computerPlay.equals("ROCK")) {
                    System.out.println("Rock breaks Scissors. You lose");
                    userScore -= three;
                    play();
                }
            }
        }
    }
}
