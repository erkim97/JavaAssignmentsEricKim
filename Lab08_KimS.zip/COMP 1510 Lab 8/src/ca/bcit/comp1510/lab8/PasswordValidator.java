/**
 * 
 */
package ca.bcit.comp1510.lab8;

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.geometry.Pos;
import javafx.geometry.HPos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;

/**
 * Password Validator. Checks to see if input in both textfields are equal or
 * not.
 * 
 * @author erickim
 * @version 1.0
 *
 */
public class PasswordValidator extends Application {
    /**
     * Textfield for first input box.
     */
    private TextField tfCheck = new TextField();
    
    /**
     * Textfield for second input box.
     */
    private TextField tfPassword = new TextField();
    
    /**
     * Submit button to compare both inputs from txtfields.
     */
    private Button btSubmit = new Button("Submit");
    
    /**
     * Label which displays if valid or not for comparing inputs.
     */
    private Label lbValid = new Label();

    /**
     * Presents a GUI containing a two textfields and a submit
     * button to display if both texts are same or not.
     * @param primaryStage a Stage
     */
    public void start(Stage primaryStage) {
        GridPane gridPane = new GridPane();
        gridPane.setHgap(5);
        gridPane.setVgap(5);
        gridPane.add(new Label("Enter Password:"), 0, 0);
        gridPane.add(tfCheck, 1, 0);
        gridPane.add(new Label("Confirm Password:"), 0, 1);
        gridPane.add(tfPassword, 1, 1);
        gridPane.add(btSubmit, 0, 2);
        gridPane.add(lbValid, 1, 2);

        gridPane.setAlignment(Pos.CENTER);
        tfCheck.setAlignment(Pos.BOTTOM_LEFT);
        tfPassword.setAlignment(Pos.BOTTOM_LEFT);

        GridPane.setHalignment(btSubmit, HPos.LEFT);

        // Validation Event
        btSubmit.setOnAction(e -> validatePassword());

        Scene scene = new Scene(gridPane, 300, 150);
        primaryStage.setTitle("Password Validator");
        primaryStage.setScene(scene);
        primaryStage.show();

    }
    
    /**
     * Method to compare text in txtfield 1 and 2 and if same or not.
     */
    public void validatePassword() {
        if (tfCheck.getText().equals(tfPassword.getText())) {
            lbValid.setText("Valid");
        } else {
            lbValid.setText("Invalid");
        }

    }

    /**
     * Drives the program.
     * 
     * @param args unused
     */
    public static void main(String[] args) {
        launch(args);
    }

}
