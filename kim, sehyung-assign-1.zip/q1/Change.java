package q1;

import java.util.Scanner;

/**
 * Prompts for and reads a double value representing a monetary amount.
 * Determines the fewest number of each bill and coin needed to represent that
 * amount, starting with the highest (assume that a ten-dollar bill is the
 * maximum size needed), and that pennies exists.
 *
 * @author Sehyung Kim
 * @version 1.0
 */
public class Change {
    /**
     * This is the entry point that gets called to run the program.
     *
     * @param args unused.
     */
    public static void main(String[] args) {
        
        // Declaration of variables, includes final constant int values
        double amount;
        int tens;
        int fives;
        int toonies;
        int loonies;
        int quarters;
        int dimes;
        int nickels;
        int pennies;
        int centsRemainder;
        final int floatPennies = 100;
        final int tenValue = 1000;
        final int fiveValue = 500;
        final int toonValue = 200;
        final int loonValue = 100;
        final int quartValue = 25;
        final int dimeValue = 10;
        final int nickValue = 5;

        // Initialize Scanner object with input method
        Scanner scan = new Scanner(System.in);

        // User Prompt to enter monetary amount in type double
        System.out.println("Enter monetary amount in double format: ");

        // Stores input in double variable with a double method via scan object
        amount = scan.nextDouble();

        /*
         * Cast int type onto input double amount * pennies to convert amount to
         * pennies which prevents a floating rounding error with decimals 
         * causing wrong penny value output sometimes
         */
        centsRemainder = (int) (amount * floatPennies);

        // Calculates and stores type int of max amounts can fit
        tens = centsRemainder / tenValue; // Start from max value tens
        centsRemainder %= tenValue; // Remainder divided by smaller values
        fives = centsRemainder / fiveValue;
        centsRemainder %= fiveValue;
        toonies = centsRemainder / toonValue;
        centsRemainder %= toonValue;
        loonies = centsRemainder / loonValue;
        centsRemainder %= loonValue;
        quarters = centsRemainder / quartValue;
        centsRemainder %= quartValue;
        dimes = centsRemainder / dimeValue;
        centsRemainder %= dimeValue;
        nickels = centsRemainder / nickValue;
        centsRemainder %= nickValue;
        pennies = centsRemainder / 1;
        centsRemainder %= 1; // centsRemainder redeclared and initialized as 0

        // Prints out results
        System.out.println("The fewest number of bills and coins needed " 
                    + "are: ");
        System.out.println(tens + " ten dollar bill(s)");
        System.out.println(fives + " five dollar bill(s)");
        System.out.println(toonies + " toonies");
        System.out.println(loonies + " loonies");
        System.out.println(quarters + " quarter(s)");
        System.out.println(dimes + " dime(s)");
        System.out.println(nickels + " nickel(s)");
        System.out.println(pennies + " pennies");

        //close() method closes the scan
        scan.close();
    }

};
