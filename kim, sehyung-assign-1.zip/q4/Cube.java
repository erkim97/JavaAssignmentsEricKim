package q4;

import java.util.Scanner;

/**
 * Write an application that prompts for and reads an integer representing the
 * length of a cube's side, then prints the cube's volume and surface area.
 *
 * @author Sehyung Kim
 * @version 1.0
 */
public class Cube {
    /**
     * This is the entry point that gets called to run the program.
     *
     * @param args unused.
     */
    public static void main(String[] args) {

        // Declaration with initialization of constant integer
        final int volumeV = 3;
        final int surfaceS = 6;

        // Initialize Scanner object with input method
        Scanner scan = new Scanner(System.in);

        // User prompt to enter in integer for length
        System.out.println("Please enter an integer for the " 
                    + "cube's length: ");

        // Store user input by object of scanner class
        int length = scan.nextInt();

        // Stores calculations for volume = length^volumeV
        int volume = (int) Math.pow(length, volumeV);
        
        // Stores calculations for surface area, 6 sides
        int surfaceArea = (length * length) * surfaceS;
        
        // Prints out results
        System.out.println("The cube's volume is: " + volume);
        System.out.println("The cube's surface area is: " + surfaceArea);

        //close() method closes this scan
        scan.close();

    }

};
