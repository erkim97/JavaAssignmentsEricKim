[Sehyung Kim], [A01089966], [Set C], [February,2,2019]

This assignment is [100]% complete.


------------------------
Question one (Change) status:

[complete]
[explanation if not complete, what is working/not working]

------------------------
Question two (SecondsConvert) status:

[complete]
[explanation if not complete, what is working/not working]

------------------------
Question three (Arithmetic) status:

[complete]
[explanation if not complete, what is working/not working]

------------------------
Question four (Cube) status:

[complete]
[explanation if not complete, what is working/not working]

------------------------
Question five (Pack) status:

[complete]
[explanation if not complete, what is working/not working]
