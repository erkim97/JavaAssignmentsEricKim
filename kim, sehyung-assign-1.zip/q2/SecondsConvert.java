package q2;

import java.text.DecimalFormat;
import java.util.Scanner;

/**
 *  An application that reads an integer number in from the user 
 *  via the prompt. That integer value is a value in seconds.
 *  Convert the seconds into hours,  minutes and seconds in 
 *  the format hh:mm:ss.
 *
 * @author Sehyung Kim
 * @version 1.0
 */
public class SecondsConvert {
    /**
     * This is the entry point that gets called to run the program.
     *
     * @param args unused.
     */
    public static void main(String[] args) {
       
        // Initialize Scanner object with input method
        Scanner scan = new Scanner(System.in);
        
        // User prompt to type in seconds, int type
        System.out.print("Type in seconds: ");
        
       
        // Stores input into a int variable with a int method via scan object
        int seconds = scan.nextInt(); 

        // Declaration with initialization of type int constants
        final int conversion1 = 3600;
        final int conversion2 = 60;
        
        // Calculates and stores type int variable hours
        int hours = seconds / conversion1; //60 secs/min * 60 mins/hour = 3600
        
        // Calculates and stores type int variable remainder from hours
        int remainder = seconds - hours * conversion1; 

        // Calculates and stores type int variable mins.
        int mins = remainder / conversion2; //Divide remainder by 60, 60secs/min

        // Calculate new "remainder" for seconds to output
        remainder = remainder - mins * conversion2; //Remainder minus mins * 60
        
        // Store seconds variable of type int from remainder
        int secs = remainder;
        
        // Initializes fmt object with DecimalFormat class with method, 2 digits
        DecimalFormat fmt = new DecimalFormat("#00.###");
        
        // Prints hours : minutes : seconds. Minutes and seconds shown as ##:##
        System.out.print(hours + ":" + fmt.format(mins) + ":" 
                    + fmt.format(secs));

        //close() method closes this scan
        scan.close();
    }    
    }
