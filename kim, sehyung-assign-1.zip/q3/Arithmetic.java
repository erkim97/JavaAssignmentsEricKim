package q3;

import java.util.Scanner;

/**
 * Reads two floating point numbers and prints their sum, difference, quotient,
 * and product.
 *
 * @author Sehyung Kim
 * @version 1.0
 */
public class Arithmetic {
    /**
     * This is the entry point that gets called to run the program.
     *
     * @param args unused.
     */
    public static void main(String[] args) {
        
        // Declaration of float variables
        float numberOne;
        float numberTwo;
        float sum;
        float difference;
        float quotient;
        float product;

        // Initialize Scanner object with input method
        Scanner scan = new Scanner(System.in);

        // User prompt to enter a 1st number, with or without decimals
        System.out.println("Please enter the first float number: ");

        // Stores input into a float variable with float method via scan object
        numberOne = scan.nextFloat();

        // User prompt to enter a 2nd number, with or without decimals
        System.out.println("Please enter the second float number: ");

        // Store input into a float variable with a float method via scan object
        numberTwo = scan.nextFloat();

        // Calculates and stores the sum into the float variable sum
        sum = numberOne + numberTwo;

        // Calculates and stores the difference into float variable difference
        difference = numberOne - numberTwo;

        // Calculates and stores the quotient into the float variable quotient
        quotient = numberOne / numberTwo;

        // Calculates and stores the product into the float variable product
        product = numberOne * numberTwo;

        // Prints out results. Complete
        System.out.println("The sum is: " + sum);
        System.out.println("The difference is: " + difference);
        System.out.println("The quotient is: " + quotient);
        System.out.println("The product is: " + product);

        //close() method closes this scan
        scan.close();
    }

};
