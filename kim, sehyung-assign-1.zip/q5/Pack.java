package q5;

import java.util.Scanner;

/**
 * An application that encodes a 5 MIX-character string into a single int
 * variable and decode an int value back into MIX-characters. Read the string 
 * from the user and print the encoded number and decoded string.
 * 
 * @author Sehyung Kim
 * @version 1.0
 */
public class Pack {
    /**
     * This is the entry point that gets called to run the program.
     *
     * @param args unused.
     */
    public static void main(String[] args) {
        
        //Declaration, initialization of constant type int variables
        final int nZero = 0;
        final int nOne = 1;
        final int nTwo = 2;
        final int nThree = 3;
        final int nFour = 4;
        final int baseFiftySix = 56;

        // Initialize Scanner object with input method
        Scanner scan = new Scanner(System.in);

        // User prompt to enter in 5 MIX-characters between A-I
        System.out.println("Enter in 5 MIX-characters " 
                        + "from A - I, I inclusive: ");

        // Stores input as string variable with nextLine string method scan
        // object
        String input = scan.nextLine();

       
        // String method input.charAt(n) extracts nth character from the string
        char c1 = input.charAt(nZero);
        char c2 = input.charAt(nOne);
        char c3 = input.charAt(nTwo);
        char c4 = input.charAt(nThree);
        char c5 = input.charAt(nFour);

        // Convert input characters to MIX equivalent int
        int value1 = c1 - 'A' + 1;
        int value2 = c2 - 'A' + 1;
        int value3 = c3 - 'A' + 1;
        int value4 = c4 - 'A' + 1;
        int value5 = c5 - 'A' + 1;

        // Converts 5 values of Base56 to Base10, multiplying and adding values
        int encoded1 = (value1 * (int) Math.pow(baseFiftySix, nFour));
        int encoded2 = (value2 * (int) Math.pow(baseFiftySix, nThree));
        int encoded3 = (value3 * (int) Math.pow(baseFiftySix, nTwo));
        int encoded4 = (value4 * (int) Math.pow(baseFiftySix, nOne));
        int encoded5 = (value5 * (int) Math.pow(baseFiftySix, nZero));
        System.out.print("Encoded: ");

        // Print out encoded int using arithmetic operator
        System.out.println(encoded1 + encoded2 + encoded3 + encoded4 
                        + encoded5);

        // Declare a variable of type "int" and set to total encoded value
        int encodedNum = encoded1 + encoded2 + encoded3 + encoded4 + encoded5;

        // Converts Base10 to Base56 by dividing encoded int, remainders saved
        int digit1 = encodedNum / baseFiftySix;
        int rDigit1 = encodedNum % baseFiftySix;

        int digit2 = digit1 / baseFiftySix;
        int rDigit2 = digit1 % baseFiftySix;

        int digit3 = digit2 / baseFiftySix;
        int rDigit3 = digit2 % baseFiftySix;

        int digit4 = digit3 / baseFiftySix;
        int rDigit4 = digit3 % baseFiftySix;

        int rDigit5 = digit4 % baseFiftySix;

        // Convert encoded base10 numbers to char, look at remainders(bottom up)
        char char1 = (char) (rDigit5 - 1 + 'A');
        char char2 = (char) (rDigit4 - 1 + 'A');
        char char3 = (char) (rDigit3 - 1 + 'A');
        char char4 = (char) (rDigit2 - 1 + 'A');
        char char5 = (char) (rDigit1 - 1 + 'A');

        // Print out decoded 5 values from variables above, of type char
        System.out.print("Decoded: " + char1 + char2 + char3 + char4 + char5);

        //close() method closes this scan
        scan.close();

    }

};
