/**
 * 
 */
package ca.bcit.comp1510.lab5;

/**
 * Cone. Uses constructor, accessors and mutators, calculation methods 
 * and toString() method to calculate and return cone calculations.
 * @author erickim
 * @version 1.0
 */
public class Cone {
    
    /**
     * Declared cone private radiusCone as a double.
     */
    private double radiusCone;
    
    /**
     * Declared cone private heightCone as a double.
     */
    private double heightCone;
    
    /**
     * Declared int constant 1/3 as an integer.
     */
    private final int oneOverThree = 1 / 3;
    
    /**
     * Constructor with parameters.
     * @param radius as a double
     * @param height as a double
     */
    public Cone(double radius, double height) {
        radiusCone = radius;
        heightCone = height;
    }

    /**
     * Accessor.
     * @return the radiusCone
     */
    public double getRadiusCone() {
        return radiusCone;
    }

    /**
     * Mutator.
     * @param radius the radiusCone to set
     */
    public void setRadiusCone(double radius) {
        radiusCone = radius;
    }

    /**
     * Accessor.
     * @return the heightCone
     */
    public double getHeightCone() {
        return heightCone;
    }

    /**
     * Mutator.
     * @param height the heightCone to set
     */
    public void setHeightCone(double height) {
        heightCone = height;
    }
    
    
    /**
     * Method to calculate volume of a cone.
     * @return volume of cone is returned
     */
    public double volume() {
        
        double volume = oneOverThree * Math.PI * radiusCone 
                * radiusCone * heightCone;
        return volume;
    }
    
    
    /**
     * Method to calculate the slant height of a cone.
     * @return slant height of a cone is returned
     */
    public double slantHeight() {
        double radiusConeSquared = Math.pow(radiusCone, 2);
        double heightConeSquared = Math.pow(heightCone, 2);
        double addRadiusHeight = radiusConeSquared + heightConeSquared;
        double slantHeight = Math.sqrt(2) * addRadiusHeight;
                
        return slantHeight;
    }
    
    /**
     * Method to calculate surface area of a cone.
     * @return surfaceArea of cone is returned
     */
    public double surfaceArea() {
        double surfaceArea = (Math.PI * radiusCone * radiusCone) 
                            + (Math.PI * radiusCone * slantHeight());
        return surfaceArea;
    }

    /**
     * Method toString to return a string.
     * @return strings of methods and text.
     */
    public String toString() {
        return "Cone [radiusCone=" + radiusCone + ", heightCone=" 
                + heightCone + ", getRadiusCone()=" + getRadiusCone()
                + ", getHeightCone()=" + getHeightCone() + ", volume()=" 
                + volume() + ", slantHeight()=" + slantHeight()
                + ", surfaceArea()=" + surfaceArea() + "]";
    }
    
    
    
    
}
