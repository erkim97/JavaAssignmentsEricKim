/**
 * 
 */
package ca.bcit.comp1510.lab5;

/**
 * Name.  Uses constructor, accessors and mutators, specific type methods 
 * and toString() method to calculate and return name outputs. 
 * @author erickim
 * @version 1.0
 */

public class Name {
    /**
     * Declared private instance variable firstname.
     */
    private String firstName;
    /**
     * Declared private instance variable middlename.
     */
    private String middleName;
    /**
     * Declared private instance variable lastname.
     */
    private String lastName;

    /**
     * Constructor to set up the first, middle, and last name components.
     * @param first **first name**
     * @param middle **middle name**
     * @param last **last name** 
     */
    public Name(String first, String middle, String last) {
        firstName = first;
        middleName = middle;
        lastName = last;
    }

    /**
     * Accessor.
     * @return the firstName
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * Mutator.
     * @param first the firstName to set
     */
    public void setFirstName(String first) {
        firstName = first;
    }

    /**
     * Accessor.
     * @return the middleName
     */
    public String getMiddleName() {
        return middleName;
    }

    /**
     * Mutator.
     * @param middle the middleName to set
     */
    public void setMiddleName(String middle) {
        middleName = middle;
    }

    /**
     * Accessor.
     * @return the lastName
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * Mutator.
     * @param last the lastname to set
     */
    public void setLastName(String last) {
        lastName = last;
    }

    /**
     * Returns a String composed of the concatenation of the information in the
     * Name.
     * @return first,middle,last name as string
     */
    
    public int getNameLength() {
        int totalLength = firstName.length() + middleName.length() 
                          + lastName.length();
        return totalLength;
    }
    /**
     * Method to capitalize first letter of names.
     * @return capital initials of first,middle,last name.
     */
    public String getNameUpper() {
        String initialsUpper = firstName.substring(0, 1)
                            + middleName.substring(0, 1)
                            + lastName.substring(0, 1);
        return initialsUpper.toUpperCase();              
    }
    
    
    /**
     * Method to take first,middle,lastname inputs and change
     * order of them as written below.
     * @return rearranged string names
     */
    public String getNameOrder() {
        return lastName + ", " + firstName + ", "
               + middleName;
    }
    
    
    /**
     * Method to get n and return nth char.
     * @param n as an integer
     * @return int n character from string
     */
    public char getN(int n) {
        
        String str = firstName + middleName + lastName;
        return str.charAt(n - 1);
        
    }
    
    /**
     * Method to get n and return nth char.
     * @param input as a string
     * @return true or false if strings equal
     */
    public boolean getEqual(String input) {
        return input.equals(firstName);

    }
    
    /**
     * Method to compare two names.
     * @param nameParts as a string
     * @return true or false if strings equal
     */
    public boolean getName(String nameParts) {
        
        return nameParts.equals(firstName + middleName + lastName);
    }
    
 
    
    /** 
     * String method.
     * @return returns strings of methods.
     */
    public String toString() {
        return "Name [firstName= " + firstName + ", middleName= " 
                    + middleName + ", lastName= " + lastName + "]"
                    + "\nThe name length is= " + getNameLength()
                    + "\nThe capitalized initials are= " + getNameUpper()
                    + "\nThe name order changed is= " + getNameOrder();
    }

}
