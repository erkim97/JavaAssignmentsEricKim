/**
 * 
 */
package ca.bcit.comp1510.lab5;

/**
 * Cube.  Uses constructor, accessors and mutators, calculation methods 
 * and toString() method to calculate and return cube calculations.
 * @author erickim
 * @version 1.0
 */
public class Cube {

    /**
     * Declared cube private x-coordinate as a double.
     */
    private double xCoord;
    
    /**
     * Declared cube private y-coordinate as a double.
     */
    private double yCoord;
    
    /**
     * Declared cube private z-coordinate as a double.
     */
    private double zCoord;
    
    /**
     * Declared cube private edgelength as a double.
     */
    private double edgeLength;
    
    /**
     * Declared int constant 3.
     */
    private final int three = 3;
    
    /**
     * int constant 6.
     */
    private final int six = 6;
    
    /**
     * Constructor with parameters.
     * @param x as a double
     * @param y as a double
     * @param z as a double
     * @param edge as a double
     */
    public Cube(double x, double y, double z, double edge) {
        xCoord = x;
        yCoord = y;
        zCoord = z;
        edgeLength = edge;
    }

    /**
     * Accessor.
     * @return the xCoord
     */
    public double getxCoord() {
        return xCoord;
    }

    /**
     * Mutator.
     * @param x the xCoord to set
     */
    public void setxCoord(double x) {
        xCoord = x;
    }

    /**
     * Accessor.
     * @return the yCoord
     */
    public double getyCoord() {
        return yCoord;
    }

    /**
     * Mutator.
     * @param y the yCoord to set
     */
    public void setyCoord(double y) {
        yCoord = y;
    }

    /**
     * Accessor.
     * @return the zCoord
     */
    public double getzCoord() {
        return zCoord;
    }

    /**
     * Mutator.
     * @param z the zCoord to set
     */
    public void setzCoord(double z) {
        zCoord = z;
    }

    /**
     * Accessor.
     * @return the edgeCoord
     */
    public double getEdgeLength() {
        return edgeLength;
    }

    /**
     * Mutator.
     * @param edge the edgeCoord to set
     */
    public void setEdgeLength(double edge) {
        edgeLength = edge;
    }
    
/**
 * Method to calculate the surface area of a cube.
 * @return returns the cube surface area calcuated
 */
public double surfaceArea() {
        
        double surfaceArea = six * edgeLength * edgeLength;  
        return surfaceArea;
    }
  
    /**
     * Method to calculate the volume of a cube.
     * @return returns the cube volume calculated
     */
    public double volume() {
        
        double volume = Math.pow(edgeLength, three);
        return volume;
    }
/**
 * Method to calculate the face diagonal of a cube.
 * @return returns the cube face diagonal calculated
 */
public double faceDiagonal() {
        
        double faceDiagonal = Math.sqrt(edgeLength);
        return faceDiagonal;
    }
  
    /**
     * Method to calculate the space diagonal of a cube.
     * @return returns the cube space diagonal calculated
     */
    public double spaceDiagonal() {
        
        double spaceDiagonal = Math.cbrt(edgeLength);
        return spaceDiagonal;
    }

    /**
     * toString method that returns a string.
     * @return returns string of methods and text
     */
    public String toString() {
        return  "The surface area is: " + surfaceArea()  
                + " \n" + "The volume is: " + volume() + "\n" 
                + "The face diagonal" + " is: " + faceDiagonal() 
                + "\n" + "The space diagonal is: " + spaceDiagonal();
    }

}
