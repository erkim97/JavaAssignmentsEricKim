/**
 * 
 */
package ca.bcit.comp1510.lab5;

/**
 * Sphere. Uses constructor, accessors and mutators, calculation methods 
 * and toString() method to calculate and return sphere calculations.
 * @author erickim
 * @version 1.0
 */
public class Sphere {
    
    /**
     * Declared private x coordinate as a double.
     */
    private double x;
    
    /**
     * Declared private y coordinate as a double.
     */
    private double y;
    
    /**
     * Declared private z coordinate as a double.
     */
    private double z;
    
    /**
     * Declared private radius as a double.
     */
    private double radius;
   
    /**
     * Declared private int constant 2.
     */
    private final int two = 2;
    
    /**
     * Declared private int constant 3.
     */
    private final int three = 3;
    
    /**
     * Declared private int constant 4.
     */
    private final int four = 4;
    
    /**
     * Declared private int constant 4/3.
     */
    private final int fourOverThree = 4 / 3;
    
    /**
     * Constructor with parameters.
     * @param x1 as a double
     * @param y1 as a double
     * @param z1 as a double
     * @param radius1 as a double
     */
    public Sphere(double x1, double y1, double z1, double radius1) {
        x = x1;
        y = y1;
        z = z1;
        radius = radius1;
        
    }
    
    /**
     * Accessor.
     * @return the x
     */
    public double getX() {
        return x;
    }


    /**
     * Mutator.
     * @param x1 the x to set
     */
    public void setX(double x1) {
        x = x1;
    }


    /**
     * Accessor.
     * @return the y
     */
    public double getY() {
        return y;
    }


    /**
     * Mutator.
     * @param y1 the y to set
     */
    public void setY(double y1) {
        y = y1;
    }


    /**
     * Accessor.
     * @return the z
     */
    public double getZ() {
        return z;
    }


    /**
     * Mutator.
     * @param z1 the z to set
     */
    public void setZ(double z1) {
        z = z1;
    }


    /**
     * Accessor.
     * @return the radius
     */
    public double getRadius() {
        return radius;
    }


    /**
     * Mutator.
     * @param radius1 the radius to set
     */
    public void setRadius(double radius1) {
        radius = radius1;
    }


    /**
     * Method to calculate sphere surface area.
     * @return surface area calculated from sphere formula
     */
    public double surfaceArea() {
       
        double surfaceArea = four * Math.PI * Math.pow(radius, two);
        return surfaceArea;
    }
  
    /**
     * Method to calculate sphere volume.
     * @return volume calculated from sphere formula
     */
    public double volume() {
        double volume = (fourOverThree) * Math.PI 
                * Math.pow(radius, three);
        return volume;
    }
    
    /** 
     * toString method to return outputs for methods with a string.
     * @return returns the surfacearea method and volume method
     */
    public String toString() {
        return  "The surface area is: " + surfaceArea()  
                + "\n" + "The volume is: " + volume();
    }


 
}
