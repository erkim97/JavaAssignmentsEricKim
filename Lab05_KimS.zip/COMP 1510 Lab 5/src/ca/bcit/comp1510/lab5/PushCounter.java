package ca.bcit.comp1510.lab5;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.geometry.HPos;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

/**
 * Push Button. Demonstrates JavaFX buttons and event handlers.
 * 
 * @author erickim
 * @version 1.0
 */
public class PushCounter extends Application {
    
    /** Holds the number of time the button yes is pressed. */
    private int count;
    
    /** Holds the number of time the button no is pressed. */
    private int countN; 
    
    /** Displays the number of times the button yes is pressed. */
    private Text countText;
    
    /** Displays the number of times the button no is pressed. */
    private Text countTextN;
    
    /** Displays override textfield for user. */
    private TextField override;
    

    /**
     * Presents a GUI containing a button and text that displays
     * how many times the button is pushed.
     * @param primaryStage a Stage
     */
    public void start(Stage primaryStage) {
        count = 0;
        countN = 0;
        countText = new Text("Pushes: 0");
        countTextN = new Text("Pushes: 0");
        final int fontSize = 13;
        final int fieldWidth = 50;
      
        Font font = new Font(fontSize);

        //override textfield for user input with label.
        Label inputLabel = new Label("Override:");
        inputLabel.setFont(font);
        GridPane.setHalignment(inputLabel, HPos.RIGHT);
        
        override = new TextField();
        override.setFont(font);
        override.setPrefWidth(fieldWidth);
        override.setAlignment(Pos.CENTER);
        override.setOnAction(this::processReturn); 
        
        //button1&2 for yes counter
        Button push = new Button("YES!");
        push.setOnAction(this::processButtonPressY);
        Button push1 = new Button("MINUS YES!");
        push1.setOnAction(this::processButtonPressY1);
        
        //button3&4 for no counter
        Button pushN = new Button("NO!");
        pushN.setOnAction(this::processButtonPressN);
        Button pushN1 = new Button("MINUS NO!");
        pushN1.setOnAction(this::processButtonPressN1);
        
        //pane to hold in, in order, all parameters
        FlowPane pane = new FlowPane(push, push1, countText, pushN, pushN1, 
                countTextN, inputLabel, override);
        pane.setAlignment(Pos.CENTER);
     
        
        final int horizontalGap = 20;
        pane.setHgap(horizontalGap);
        pane.setStyle("-fx-background-color: cyan");

        final int appWidth = 1000;
        final int appHeight = 500;
        Scene scene = new Scene(pane, appWidth, appHeight);
        
       
        primaryStage.setTitle("Yes No Counter");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * Updates the counter and text when the button is pushed.
     * @param event invokes this method
     */
    public void processButtonPressY(ActionEvent event) {
        count++;
        countText.setText("Pushes: " + count);
        
    }
    /**
     * Updates the counter and text when the button is pushed.
     * @param event invokes this method
     */
    public void processButtonPressY1(ActionEvent event) {
        count--;
        countText.setText("Pushes: " + count);
        
    }
    
    /**
     * Updates the no counter and text when button is pushed.
     * @param event invokes this method
     */
    public void processButtonPressN(ActionEvent event) {
        countN++;
        countTextN.setText("Pushes: " + countN);   
    }
    
    /**
     * Updates the no counter and text when button is pushed.
     * @param event invokes this method
     */
    public void processButtonPressN1(ActionEvent event) {
        countN--;
        countTextN.setText("Pushes: " + countN);
    }
    
    /**
     * Overrides the counters and text when textinput put in.
     * @param event invokes thie method
     */
    public void processReturn(ActionEvent event) {
        int overrideNumber = Integer.parseInt(override.getText());
        count = overrideNumber;
        countN = overrideNumber;
        countText.setText("Pushes: " + overrideNumber);
        countTextN.setText("Pushes: " + overrideNumber);
    }

    /**
     * Launches the JavaFX application.
     * 
     * @param args
     *            command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
}

