
package ca.bcit.comp1510.lab5;

import java.text.DecimalFormat;
import java.util.Scanner;

/**
 * GeometryDriver. Prompts user for shape values, user input returns outputs of 
 * calculations of shapes by calling their respective class methods.
 * NOTE: REQUIRES TWO ENTERS AFTER EACH INPUT DUE TO SYSTEMATICAL USER INPUT
 * @author erickim
 * @version 1.0
 */
public class GeometryDriver {

    /**
     * Drives the program.
     * 
     * @param args unused.
     */
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        DecimalFormat fmt = new DecimalFormat("#.###");

        // ask user for the radius, and coordinates
        System.out.println("Enter radius of sphere");
        double userInputRadius = scan.nextDouble();

        System.out.println("Enter x coordinate");
        double x = scan.nextDouble();

        System.out.println("Enter y coordinate");
        double y = scan.nextDouble();

        System.out.println("Enter z coordinate");
        double z = scan.nextDouble();

        // create Sphere with the radius and coordinates
        Sphere mySphere = new Sphere(x, y, z, userInputRadius);

        // print out surface area and volume from radius input
        System.out.println("The surface area is: " 
                    + fmt.format(mySphere.surfaceArea()) + "\nThe volume is: "
                    + fmt.format(mySphere.volume()));

        // ask user for the edge length, and centre coordinates
        System.out.println("\n" + "Enter edge length of sphere");
        double userInputEdge = scan.nextDouble();

        System.out.println("Enter x centre coordinate");
        double cX = scan.nextDouble();

        System.out.println("Enter y centre coordinate");
        double cY = scan.nextDouble();

        System.out.println("Enter z centre coordinate");
        double cZ = scan.nextDouble();

        // creates and calls cube class with parameters input
        Cube myCube = new Cube(cX, cY, cZ, userInputEdge);

        System.out.println("The surface area is: " 
                    + fmt.format(myCube.surfaceArea()) 
                    + "\nThe volume of the cube is : "
                    + fmt.format(myCube.volume()) 
                    + "\nThe face diagonal of the cube is: "
                    + fmt.format(myCube.faceDiagonal()) 
                    + "\nThe space diagonal of the cube is: "
                    + fmt.format(myCube.spaceDiagonal()));

        // ask user for the edge length, and centre coordinates
        System.out.println("\n" + "Enter radius of a cone");
        double userInputConeRadius = scan.nextDouble();

        System.out.println("Enter height of a cone");
        double userInputConeHeight = scan.nextDouble();

        // creates and calls cone class with parameters input
        Cone myCone = new Cone(userInputConeRadius, userInputConeHeight);

        System.out.println("The volume is: " 
                    + fmt.format(myCone.volume()) 
                    + "\nThe slant height is: "
                    + fmt.format(myCone.slantHeight()) 
                    + "\nThe slant surface area is: "
                    + fmt.format(myCone.surfaceArea()));

        scan.close();
    }

}
