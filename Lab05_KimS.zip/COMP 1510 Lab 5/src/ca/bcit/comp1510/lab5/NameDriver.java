/**
 * 
 */
package ca.bcit.comp1510.lab5;
import java.util.Scanner;

/**
 * NameDriver. Prompts user for input, and returns output from user input
 * calling public Name class methods.
 * NOTE: REQUIRES TWO ENTERS AFTER EACH INPUT DUE TO SYSTEMATICAL USER INPUT
 * @author erickim
 * @version 1.0 
 */
public class NameDriver {

    /**
     * Drives the program.
     * @param args unused
     */
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        
        System.out.println("Enter in first name");
        String first = scan.next();
        
        System.out.println("Enter in middle name");
        String middle = scan.next();
        
        System.out.println("Enter in last name");
        String last = scan.next();
        
        // creates and calls name class with parameters input.
        Name name = new Name(first, middle, last);
       
        System.out.println("Enter in integer n: ");
        int n = scan.nextInt();
        
        System.out.println("Enter in another first name: ");
        String inputf = scan.next();
        
        System.out.println("Enter in another middle name: ");
        String inputm = scan.next();
       
        System.out.println("Enter in another last name: ");
        String inputl = scan.next();
        
        System.out.println(name);
        
        System.out.println("The nth char selected is: "
                + name.getN(n));
        
        System.out.println("The first name equals original first?: "
                + name.getEqual(inputf));
        
        System.out.println("All name parts equals original name?: "
                + name.getName(inputf + inputm + inputl));
        
        scan.close();
        
    }

}

//Yes it works for all names.