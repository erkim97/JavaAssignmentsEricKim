-Eric (Sehyung) Kim, A01089966, COMP 2526 A1c README file

Developed a program that prints out shapes instead of
arithmetic tables using parameters <type of shape>
<width><height>. 

Super class called Shape and contains all common data
and members and methods found in the classes that will
extend it. 

Shape class in addition to its constructor has the 
display method(like Table did)

Enumerated type file for shapes.

Triangle and Diamond need width to be odd in value else
throws BadWidthException.
Main will catch the exception and call usage() method.

The main driver class gets the shape type and then
has it displayed.