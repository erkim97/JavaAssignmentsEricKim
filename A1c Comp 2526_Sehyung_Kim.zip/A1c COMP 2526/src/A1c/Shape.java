package A1c;

import java.util.Arrays;

/**
 * Defines a shape.
 * 
 * @author Eric Kim
 * @version 1.0
 */
public class Shape {
    private int width;
    private int height;
    private ShapeType type;
    private String[][] createdShape;

    /**
     * Constructor.
     * 
     * @param width     
     * @param height       
     * @param type      
     * @throws BadWidthException 
     */
    protected Shape(final int width, final int height, final String type) {
        this.width = width;
        this.height = height;
        if (type.equals("r")) {
            this.type = ShapeType.RECTANGLE;
        }
        if (type.equals("t")) {
            this.type = ShapeType.TRIANGLE;
        }
        if (type.equals("d")) {
            this.type = ShapeType.DIAMOND;
        }
    }

    /**
     * @return the created shape.
     */
    public String[][] getCreatedShape() {
        return createdShape;
    }

    /**
     * Initialize 2D shape array.
     * @param mS the madeShape to init
     */
    public void initCreatedShape(String[][] cS) {
        this.createdShape = cS;
    }
    /**
     * Modifies the 2D array to hold the shape at [x][y].
     * @param x Row.
     * @param y Column.
     * @param s String to be inserted into 2D arr.
     */
    public void setCreatedShape(int x, int y, String s) {
        this.createdShape[x][y] = s;
    }

    /**
     * Draws shape according to 2D array createdShape.
     */
    void drawShape() {
        for (String[] rows : this.createdShape) {
            for (String s : rows) {
                System.out.print(s);
            }
            System.out.println();
        }
    }   
}