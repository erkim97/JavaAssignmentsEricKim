package A1c;
/**
 * ShapeType Class
 * @author Eric Kim
 * @version 1.0
 */
public enum ShapeType {
    /**
     * The shapes enum list
     */
    RECTANGLE, TRIANGLE, DIAMOND;
}