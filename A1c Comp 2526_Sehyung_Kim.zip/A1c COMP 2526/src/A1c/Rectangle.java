package A1c;
/**
 * Creating the Rectangle Shape
 * @author Eric Kim
 * @version 1.0
 */
public class Rectangle extends Shape {
    /**
     * Constructor for the Rectangle Shape.
     * @param w width
     * @param h height
     * @throws BadWidthException 
     */
    public Rectangle(int w, int h) {
        super(w, h, "r");
        super.initCreatedShape(new String[h][w]);
        for (int i = 0; i < h; i++) {
            for (int j = 0; j < w; j++) {
                super.setCreatedShape(i, j, "*");
            }
        }
    }
}