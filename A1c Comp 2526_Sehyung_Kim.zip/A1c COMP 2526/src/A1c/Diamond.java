package A1c;

/**
 * Creating the Diamond Shape
 * @author Eric Kim
 * @version 1.0
 */
public class Diamond extends Shape {
    
    /**
     * Constructor for the Diamond shape.
     * @param w 
     * @param h
     * @throws BadWidthException 
     */
    public Diamond(int w, int h) throws BadWidthException {
        super(w, h, "d");
        if (w % 2 == 0) {
            throw new BadWidthException("WIDTH NEEDS TO BE ODD.");
        }
        super.initCreatedShape(new String[w][w]);
        for (int i = 0; i < w / 2 + 1; i++) {
            for (int j = 0; j < w; j++) {
                if (j < w / 2 - i || j > w / 2 + i) {
                    super.setCreatedShape(i, j, " ");
                    super.setCreatedShape(w - i - 1, j, " ");
                } else {
                    super.setCreatedShape(i, j, "#");
                    super.setCreatedShape(w - i - 1, j, "#");
                }
            }
        }
    }
    
}