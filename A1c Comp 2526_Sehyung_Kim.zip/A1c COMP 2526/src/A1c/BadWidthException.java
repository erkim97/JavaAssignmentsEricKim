package A1c;
import java.lang.Exception;
/**
 * BadWidthException.
 * @author Eric Kim
 * @version 1.0
 */

@SuppressWarnings("serial")
public class BadWidthException extends Exception {

    public BadWidthException() {
    }

    /**
     * Super Method type BadWidthException.
     * @param message the message stored in the exception
     */
    public BadWidthException(String message) {
        super(message);
    }

    /**
     * Super Method type BadWidthException.
     * @param cause the cause of the exception
     */
    public BadWidthException(Throwable cause) {
        super(cause);
        // TODO Auto-generated constructor stub
    }

}