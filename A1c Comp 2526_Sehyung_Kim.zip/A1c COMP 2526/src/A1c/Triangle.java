package A1c;
/**
 * Creating the Triangle Shape
 * @author Eric Kim
 * @version 1.0
 */
public class Triangle extends Shape {
    
    /**
     * Constructor for the triangle shape.
     * @param width
     * @param height
     * @throws BadWidthException 
     */
    public Triangle(int width, int height) throws BadWidthException {
        super(width, height, "t");
        if (width % 2 == 0) {
            throw new BadWidthException(" ");
        }
        super.initCreatedShape(new String[width / 2 + 1][width]);
        for (int i = 0; i < width / 2 + 1; i++) {
            for (int j = 0; j < width; j++) {
                if (j < width / 2 - i || j > width / 2 + i) {
                    super.setCreatedShape(i, j, " ");
                } else {
                    super.setCreatedShape(i, j, "@");
                }
            }
        }
    }
    
}