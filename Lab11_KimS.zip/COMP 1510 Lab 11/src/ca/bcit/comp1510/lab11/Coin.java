package ca.bcit.comp1510.lab11;

/**
 * Represents a two-sided coin that can be flipped.
 * 
 * @author eric kim
 * @version 1.0
 */
public class Coin implements Lockable {
    /** Integer for coin showing heads. */
    public static final int HEADS = 0;

    /** Integer for coin showing tails. */
    public static final int TAILS = 1;

    /** Integer to store current coin face. */
    private int face;
    
    /** Integer key for lock. */
    private int key;
    
    /** boolean to check if object is locked. */
    private boolean locked = true;

    /**
     * Constructor for Coin object, flips it.
     */
    public Coin() {
        flip();
    }

    /**
     * Method to flip coin if unlocked by random face value.
     */
    public void flip() {
        if (!locked) {
            face = (int) (Math.random() * 2);
        } else {
            System.out.println("This Coin object is locked. No flip!");
        }
        
    }

    /**
     * Method to check if coin is heads.
     * @return boolean if current face is heads, else false.
     */
    public boolean isHeads() {
        return (face == HEADS);
    }

    /**
     * Method to print out the current face name of the coin.
     * @return toString description of coin face
     */
    public String toString() {
        String faceName;

        if (face == HEADS) {
            faceName = "Heads";
        } else {
            faceName = "Tails";
        }
        
        return faceName;
    }

    @Override
    /**
     * Mutator to Set the key.
     * @param key
     *            integer for the key
     */
    public void setKey(int key) {
        this.key = key;
        
    }

    @Override
    /**
     * Method to lock the object.
     * @param enterKey
     *            integer for the key
     * @return boolean if the object is locked
     */
    public boolean lock(int enterKey) {
        if (enterKey == this.key) {
            locked = true;
            return true;
        }
        return false;
    }

    /**
     * Method to unlock the object.
     * @param enterKey
     *            integer for the key
     * @return boolean if the object is unlocked
     */
    public boolean unlock(int enterKey) {
        if (enterKey == this.key) {
            locked = false;
            return true;
        }
        return false;
    }

    @Override
    /**
     * Method to check if object is locked.
     * @return boolean if the object is locked.
     */
    public boolean locked() {
        return locked;

    }
}