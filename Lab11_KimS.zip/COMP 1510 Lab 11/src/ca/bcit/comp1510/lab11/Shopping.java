package ca.bcit.comp1510.lab11;

import java.util.Scanner;

/**
 * Driver class which uses a loop to ask users to buy things.
 *
 * @author eric kim
 * @version 1.0
 */
public class Shopping {

    /**
     * Asks user to input items they want to buy and displays the items.
     * @param args unused
     */
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        for (int i = 0; i < 2; i++) {
            Transaction transaction = new Transaction(1);
            String name;
            double price;
            int quantity;
            boolean endLoop = true;
            
            if (i == 0) {
                System.out.println("Using three parameters"
                        + " of addToCart method.");
            } else {
                System.out.println("Using one Item object"
                        + " of addToCart method.");
            }
            do {                
                System.out.println("Enter name of item "
                        + "you want to buy: ");
                name = scan.next();
                System.out.println("Price:");
                price = scan.nextDouble();
                System.out.println("quantity:");
                quantity = scan.nextInt();
                if (i == 0) {
                    transaction.addToCart(name, price, quantity);
                } else {
                    transaction.addToCart(new Item(name, price, quantity));
                }
                               
                boolean valid = true;
                String answer = "";
                while (valid) {
                    System.out.println("Do you want to buy another item?(Y/N)");
                    answer = scan.next();
                    
                    if (!answer.equalsIgnoreCase("Y") 
                            && !answer.equalsIgnoreCase("N")) {
                        System.out.println("Enter Y or N");
                    } else {
                        valid = false;
                    }
                }
                if (answer.equals("N")) {
                    endLoop = false;
                }
            } while (endLoop);
            
            System.out.println(transaction.toString() + "\n");
        }
        
        scan.close();

    }

}
