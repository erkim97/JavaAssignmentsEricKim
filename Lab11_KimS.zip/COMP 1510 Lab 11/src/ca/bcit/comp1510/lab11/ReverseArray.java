
package ca.bcit.comp1510.lab11;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * Prompts the user for an integer, then asks the user to enter that 
 * many values. Stores these values in an array and prints the array in
 * reverse.
 * @author eric kim
 * @version 1.0
 */
public class ReverseArray {
    /** Declares an integer Array. */
    private static int[] intArray;
    
    /**
     * Swaps the elements inside int Array.
     */
    private static void swap() {
        int tempArray1;
        int tempArray2;
        
        for (int i = 0; i < intArray.length / 2; i++) {
            tempArray1 = intArray[i];
            tempArray2 = intArray[intArray.length - i - 1];
            
            intArray[i] = tempArray2;
            intArray[intArray.length - i - 1] = tempArray1;
        }
                
    }
    
    /**
     * Prompts user and gives reverse array from input.
     * @param args command line arguments (unused)
     */
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int numberOfInputs = 0;
        
        boolean endLoop = true;
        while (endLoop) {
            scan = new Scanner(System.in);
            
            try {
                System.out.println("Enter an integer greater than 0 for "
                        + "number of values in the array.");
                numberOfInputs = scan.nextInt();
                endLoop = false;
                if (numberOfInputs <= 0) {
                    System.out.println("Input should be greater than 0.");
                    endLoop = true;
                }
            } catch (InputMismatchException e) {
                System.out.println("Input mismatch exception!");
            }
               
        }

        intArray = new int[numberOfInputs];
        for (int i = 0; i < numberOfInputs; i++) {
            endLoop = true;
            while (endLoop) {
                scan = new Scanner(System.in);
                
                try {
                    System.out.println("Please enter No." 
                            + (i + 1) + " value:");
                    intArray[i] = scan.nextInt();
                    endLoop = false;
                } catch (InputMismatchException e) {
                    System.out.println("Wrong input! Please enter a integer!!");
                }
                   
            }
      
        }
        
        System.out.println("The array you entered:");
        for (int num : intArray) {
            System.out.print(num + " ");
        }
        swap();
        System.out.println("");
        System.out.println("The reversed array of input is:");
        for (int num : intArray) {
            System.out.print(num + " ");
        }
        scan.close();
        
    }

}