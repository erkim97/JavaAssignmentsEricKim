
package ca.bcit.comp1510.lab11;

/**
 * Interface class that functions as a lock.
 *
 * @author eric kim
 * @version 1.0
 */
public interface Lockable {
    /**
     * Establishes the key used to unlock.
     * @param key
     *            integer for the key
     */
    void setKey(int key);
    
    /**
     * Locks the implementing object if the correct key is provide.
     * @param key
     *            integer for the key
     * @return boolean if the object is locked
     */
    boolean lock(int key);
    
    /**
     * Unlocks the implementing object if the correct key is provide.
     * @param key
     *            integer for the key
     * @return boolean if the object is unlocked
     */
    boolean unlock(int key);
    
    /**
     * Return if the object is locked.
     * @return boolean if the object is locked.
     */
    boolean locked();
    
    
    

}