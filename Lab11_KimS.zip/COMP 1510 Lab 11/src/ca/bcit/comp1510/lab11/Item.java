/**
 * 
 */
package ca.bcit.comp1510.lab11;

/**
 * Represents a item which includes name, price and quantity
 * of the item being purchases. 
 *
 * @author eric kim
 * @version 1.0
 */
public class Item {
    /** Item name. */
    private final String name;
    
    /** Item price. */
    private final double price;
    
    /** Item quantity. */
    private final int quantity;
    
    /**
     * Constructor with item name, price and quantity.
     * @param name
     *            string for item name
     * @param price
     *            double for item price
     * @param quantity
     *            integer for item quantity
     */
    public Item(String name, double price, int quantity) {
        this.name = name;
        this.price = price;
        this.quantity = quantity;
    }
    
    /**
     * Constructor for Item name and price.
     * @param name
     *            string for item name
     * @param price
     *            string for item price
     */
    public Item(String name, double price) {
        this.name = name;
        this.price = price;
        this.quantity = 1;
    }

    /**
     * Accessor for item name.
     * @return String as item name
     */
    public String getName() {
        return name;
    }

    /**
     * Accessor for item price.
     * @return String as item price
     */
    public double getPrice() {
        return price;
    }

    /**
     * Accessor for item quantity.
     * @return String as item quantity
     */
    public int getQuantity() {
        return quantity;
    }
    
    /**
     * toString method to display the item name, price and quantity.
     * @return String of the item.
     */
    public String toString() {
        return "The item name is " + name + "\n" 
                + "The price is " + price + "\n" 
                + "The quantity is " + quantity + "\n";
    }

}