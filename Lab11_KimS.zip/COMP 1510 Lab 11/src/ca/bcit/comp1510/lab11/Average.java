package ca.bcit.comp1510.lab11;

/**
 * Prints the Strings passed to the program via the command line
 * and calculates the average. If no command line arguments are provided, 
 * prints “No arguments".
 *
 * @author eric kim
 * @version 1.0
 */
public class Average {

    /**
     * Uses command line to input number(s) to be averaged.
     * @param args command line arguments
     */
    public static void main(String[] args) {
        int i = 0;
        int isNotInt = 0;
        double sum = 0.0;
        while (args.length != i  && args[i] != null) {
            System.out.println(args[i]);
            
            try {
                sum += Integer.parseInt(args[i]);
            } catch (NumberFormatException e) {
                System.out.println("The number at array position" + (i + 1) 
                        + " argument is not an integer.");
                isNotInt++;
            }
            
            i++;
        }
        if (i == 0) {
            System.out.println("There are no args.");
        } else if (i - isNotInt == 0) {
            System.out.println("No valid args.");
        } else {
            System.out.println("The average: " + sum / (i - isNotInt));
        }
        
    }

}
