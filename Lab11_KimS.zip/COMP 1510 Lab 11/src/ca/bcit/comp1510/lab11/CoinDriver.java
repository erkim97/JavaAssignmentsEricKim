/**
 * 
 */
package ca.bcit.comp1510.lab11;

/**
 * Tests the Coin class which implements the Lockable interface.
 *
 * @author eric kim
 * @version 1.0
 */
public class CoinDriver {

    /**
     * Creates a Coin object and tries to lock and unlock.
     * @param args command line arguments (unused)
     */
    public static void main(String[] args) {
        System.out.println("Flip a coin");
        Coin myCoin = new Coin();
        System.out.println("Setting the key");
        final int key = 5678;
        myCoin.setKey(key);
        System.out.println("Flip again");
        myCoin.flip();
        System.out.println("Unlock the lock and flip coin 5 times");
        myCoin.unlock(key);
        final int flipTime = 5;
        for (int i = 0; i < flipTime; i++) {
            myCoin.flip();
            System.out.println(myCoin.toString());
        }
        System.out.println("Lock and flip coin again.");
        myCoin.lock(key);
        myCoin.flip();


    }

}