package ca.bcit.comp1510.lab11;

/**
 * Stores an array of item, total price of items in the array and 
 * counts the number of objects in the array.
 *
 * @author eric kim
 * @version 1.0
 */
public class Transaction {
    /** Declares an Item Array called cart. */
    private Item[] cart;
    /** Declares the total price. */
    private double totalPrice;
    /** Decalres the total number of items. */
    private int itemCount;
    
    /**
     * Constructor which initializes array of items to size n.
     * @param n
     *            a integer for how many items
     */
    public Transaction(int n) {
        cart = new Item[n];
        totalPrice = 0.0;
        itemCount = 0;
    }
    
    /**
     * Adds an item to the cart with item name, price and quantity.
     * @param name
     *            string for item name
     * @param price
     *            double for item price
     * @param quantity
     *            integer for item quantity
     */
    public void addToCart(String name, double price, int quantity) {
        Item item = new Item(name, price, quantity);
        if (itemCount == cart.length) {
            increaseSize();
        }
        cart[itemCount] = item;
        totalPrice += price * quantity;
        itemCount++;
    }
    
    /**
     * Method to add an item to cart.
     * @param item
     *            a Item object
     */
    public void addToCart(Item item) {
        if (itemCount == cart.length) {
            increaseSize();
        }
        cart[itemCount] = item;
        totalPrice += item.getPrice() * item.getQuantity();
        itemCount++;
    }
    
    /**
     * Method to increase the size of the cart array.
     */
    public void increaseSize() {
        //Ensures new local array can carry three more items
        final int addItems = 3;
        Item[] newItemArr = new Item[cart.length + addItems];
        for (int i = 0; i < cart.length; i++) {
            newItemArr[i] = cart[i];
        }
        cart = newItemArr;
    }
    
    /**
     * Accessor for total price.
     * @return double total price
     */
    public double getTotalPrice() {
        return totalPrice;
    }
    
    /**
     * Method to get the total number of all items.
     * @return double total number of all items
     */
    public double getCount() {
        double sum = 0;
        for (Item myItem: cart) {
            sum += myItem.getQuantity();
        }
        return sum;
    }
    
    /**
     * Method toString to display the transaction.
     * @return String of the transaction.
     */
    public String toString() {
        String result = "";
        for (Item myItem: cart) {
            if (myItem != null) {
                result += myItem.getName() + "\t" + myItem.getPrice() 
                + "\t" + myItem.getQuantity() + "\n";
            }
            
        }
        result += "The total price is: " + getTotalPrice();
        
        return result;
    }
    

}
