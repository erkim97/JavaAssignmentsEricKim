/**
 * 
 */
package ca.bcit.comp1510.lab4;

/**
 * Use toString method to return concatenation of public class Name
 * which uses a constructor which takes in private variables as parameters. 
 * @author erickim
 * @version 1.0
 */

public class Name {
    /**
     * Declared private instance variable firstname.
     */
    private String firstName;
    /**
     * Declared private instance variable middlename.
     */
    private String middleName;
    /**
     * Declared private instance variable lastname.
     */
    private String lastName;

    /**
     * Constructor to set up the first, middle, and last name components.
     * @param first **first name**
     * @param middle **middle name**
     * @param last **last name** 
     */
    public Name(String first, String middle, String last) {
        firstName = first;
        middleName = middle;
        lastName = last;
    }

    /**
     * @return the firstName
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * @param firstName the first to set
     */
    public void setFirstName(String first) {
        firstName = first;
    }

    /**
     * @return the middleName
     */
    public String getMiddleName() {
        return middleName;
    }

    /**
     * @param middleName the middle to set
     */
    public void setMiddleName(String middle) {
        middleName = middle;
    }

    /**
     * @return the lastName
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * @param lastName the last to set
     */
    public void setLastName(String last) {
        lastName = last;
    }

    /**
     * Returns a String composed of the concatenation of the information in the
     * Name.
     * @return first,middle,last name as string
     */
    public String toString() {
        return "Name [firstName=" + firstName + ", middleName=" 
                    + middleName + ", lastName=" + lastName + "]";
    }

}
//Can test by importing the class into different program which calls it