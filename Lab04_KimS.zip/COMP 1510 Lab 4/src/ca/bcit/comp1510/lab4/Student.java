/**
 * 
 */
package ca.bcit.comp1510.lab4;

/**
 * Use toString method to return concatenation of public class Student
 * which uses a constructor which private variables as parameters.
 * @author erickim
 * @version 1.0
 */
public class Student {

    /**
     * Declared private instance variable firstname.
     */
    private String firstName;

    /**
     * Declared private instance variable lastname.
     */
    private String lastName;

    /**
     * Declared private instance variable birthyear.
     */
    private int birthYear;

    /**
     * Declared private instance variable studentnumber.
     */
    private int studentNumber;

    /**
     * Declared private instance variable grade.
     */
    private double grade;

    /**
     * Here is a constructor of the student.
     * @param first  **first name**
     * @param last   **last name**
     * @param year   **integer year of birth**
     * @param number **integer student number**
     * @param gpa    **double gpa, decimal point**
     */
    public Student(String first, String last, int year, int number,
            double gpa) {
        firstName = first;
        lastName = last;
        birthYear = year;
        studentNumber = number;
        grade = gpa;
    }

    /**
     * @return the firstName
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * @param firstName the first to set
     */
    public void setFirstName(String first) {
        firstName = first;
    }

    /**
     * @return the lastName
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * @param lastName the last to set
     */
    public void setLastName(String last) {
        lastName = last;
    }

    /**
     * @return the birthYear
     */
    public int getBirthYear() {
        return birthYear;
    }

    /**
     * @param birthYear the year to set
     */
    public void setBirthYear(int year) {
        birthYear = year;
    }

    /**
     * @return the studentNumber
     */
    public int getStudentNumber() {
        return studentNumber;
    }

    /**
     * @param studentNumber the number to set
     */
    public void setStudentNumber(int number) {
        studentNumber = number;
    }

    /**
     * @return the grade
     */
    public double getGrade() {
        return grade;
    }

    /**
     * @param grade the gpa to set
     */
    public void setGrade(double gpa) {
        grade = gpa;
    }

    /**
     * Returns a String composed of the concatenation of the information in the
     * Student.
     * @return Student information as string
     */
    public String toString() {
        return "Student [firstName=" + firstName + ", lastName=" 
                + lastName + ", birthYear=" + birthYear + ", studentNumber=" 
                + studentNumber + ", grade=" + grade + "]";
    }

}

//Can test by importing the class into another program which calls it