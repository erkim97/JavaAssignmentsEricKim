/**
 * 
 */
package ca.bcit.comp1510.lab4;

import java.util.Scanner;

/**
 * Shows an integer wrapper, and converting string to int.
 * 
 * @author erickim
 * @version 1.0
 */
public class IntegerWrapper {

    /**
     * Drives the program.
     * @param args unused
     */
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        System.out.println("Please input an integer: ");
        int userInput = scan.nextInt();
        Integer wrapInteger = new Integer(userInput);

        System.out.println("The binary representation is: " 
                    + Integer.toBinaryString(wrapInteger));

        System.out.println("The octal representation is: " 
                    + Integer.toOctalString(wrapInteger));

        System.out.println("The hexadecimal representation is: " 
                    + Integer.toHexString(wrapInteger));

        // Print Max and Min possible Java int values
        System.out.println("The max int value is: " + Integer.MAX_VALUE);

        System.out.println("The min int value is: " + Integer.MIN_VALUE);
        
        // clears scan method
        scan.nextLine();
        
        // Prompts user to enter in two integers
        // Prompt 1
        System.out.println("Please enter in first integer:");
        String firstStr = scan.nextLine();
        
        // Prompt 2
        System.out.println("Please enter in second integer:");
        String secondStr = scan.nextLine();

        // Use num = Integer.parseInt(str); converts str to int
        Integer num1 = Integer.parseInt(firstStr);
        Integer num2 = Integer.parseInt(secondStr);

        // Add them together, print the sum
        System.out.println("The sum of the two integers is: " + (num1 + num2));

        scan.close();
    }

}
