/**
 * 
 */
package ca.bcit.comp1510.lab4;

import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Ellipse;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

/**
 * Generating and displaying shapes
 * @author erickim
 * @version 1.0
 */
public class Face extends Application {

    /**
     * Creates and displays a face via shapes.
     * @param primaryStage
     *              creates a scene
     */
    public void start(Stage primaryStage) {
        final int sceneD = 650;
        
        
        Ellipse face = new Ellipse(325, 325, 270, 320);
        face.setFill(Color.TRANSPARENT);
        face.setStroke(Color.BLACK);
        face.setStrokeWidth(3);
        
        Line nose = new Line(300, 330, 260, 350);
        nose.setStrokeWidth(5);
        Line nose1 = new Line(300, 370, 260, 350);
        nose1.setStrokeWidth(5);
        
        Ellipse mouth = new Ellipse(310, 470, 60, 30);
        mouth.setFill(Color.BLACK);
        mouth.setStroke(Color.RED);
        mouth.setStrokeWidth(10);

        
        Line leftEyebrow = new Line(150, 100 , 300, 125);
        leftEyebrow.setStrokeWidth(5);
        Line rightEyebrow = new Line(500, 100 , 350, 125);
        rightEyebrow.setStrokeWidth(5);

        Circle leftEye = new Circle(200, 200, 50);
        leftEye.setFill(Color.BROWN);
        Circle rightEye = new Circle(450, 200, 50); 
        rightEye.setFill(Color.BROWN);
        
        Circle leftPupil = new Circle(210, 200, 29);
        leftPupil.setFill(Color.BLACK);
        Circle rightPupil = new Circle(460, 200, 29);
        rightPupil.setFill(Color.BLACK);
        
        Rectangle hair = new Rectangle(150, 3, 350, 70);
        hair.setFill(Color.BLACK);
  
        
        Group root = new Group(leftEyebrow, rightEyebrow, leftEye, rightEye, 
                face, mouth, nose, nose1, hair, leftPupil, rightPupil);
        Scene scene = new Scene(root, sceneD, sceneD);
        primaryStage.setTitle("My Face.");
        primaryStage.setScene(scene);
        primaryStage.show();

    }

    /**
     * Drives the program.
     * @param args unused
     */
    public static void main(String[] args) {
        launch(args);
    }

}
