/**
 * 
 */
package ca.bcit.comp1510.lab4;

import javafx.application.Application;
import javafx.scene.shape.Circle;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.paint.Color;

/**
 * A program that creates a 500,500 scene and green circle centered.
 * @author erickim
 * @version 1.0
 */
public class MyFirstGraphicProgram extends Application {

    /**
     * Creates and displays a green circle.
     * @param primaryStage contains the scene
     */
    public void start(Stage primaryStage) {
        final int radius = 100;
        final int sceneD = 500;
        final int x = 250;
        final int y = 250;
        final int x1 = 227;
        
        Text text = new Text(x1, y, "Eric Kim");
        text.setFill(Color.YELLOW);
        
        Circle circle = new Circle(x, y, radius);
        circle.setFill(Color.GREEN);

        Group root = new Group(circle, text);
        Scene scene = new Scene(root, sceneD, sceneD);
        primaryStage.setTitle("My first JavaFX program.");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * Drives the program.
     * @param args unused
     */
    public static void main(String[] args) {
        launch(args);
    }

}

// 12. The circle is on the top left, only the quarter bottom
//     right part of the circle is shown. 0,0 is top left x,y
