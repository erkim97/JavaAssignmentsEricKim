import java.util.ArrayList;

/**
 * Creates an Entity of type Carnivore.
 * @author erickim
 * @version 1.0
 */
public class Carnivore extends Entity {
    private static ArrayList<Carnivore> carnivoreArray = new ArrayList<Carnivore>();
    private static int totalCarnivores;
    private static final int MAX_HEALTH = 5;
    private int health;
    private boolean moved;
    private boolean justCProduced = true;


    /**
     * Constructor for Carnivore Class, inside a cell.
     * @param cell
     */
    public Carnivore(Cell cell) {
        super(cell);
        setEntity(EntityType.CARNIVORE);
        totalCarnivores++;
    }
    
    /**
     * Method to initialize Carnivore with 5 health.
     */
    public void init() {
        this.health = MAX_HEALTH;
        carnivoreArray.add(this);
        this.justCProduced = false;
        this.moved = false;
    }
    
    /**
     * Method boolean to check if Carnivore newly reproduced.
     * @return justHProduced boolean
     */
    public boolean justCProduced() {
        return this.justCProduced;
    }
    
    /**
     * Method to eat omnivore/herbivore if carnivore is on a Cell that contains a omnivore/herbivore entity.
     */
    public void eatOmniHerbivore() {
        Cell cell = this.getEntityCell();
        
        Herbivore h = cell.getHerbivore();
        Omnivore o = cell.getOmnivore();
        if (o != null) {
            cell.removeOmnivore();
            o.removeFromAllOmni();
            resetHealth();
        } else if (h != null) {
            cell.removeHerbivore();
            h.removeFromAllHerbs();
            resetHealth();
        }
    }
    
   

    /**
     * Method to decrease health of Carnivore by 1, every turn it takes.
     */
    public void minusHealth() {
        this.health -= 1;
    }

    /**
     * Method to reset the health of Carnivore back to 5, once eaten plant.
     */
    public void resetHealth() {
        this.health = MAX_HEALTH;
    }

    /**
     * Static method to get all Carnivores.
     * @return an array of Carnivores
     */
    public static Carnivore[] getAllCarnivores() {
        return carnivoreArray.toArray(new Carnivore[carnivoreArray.size()]);
    }

    /**
     * Method to remove Carnivore from Carnivore array list.
     */
    public void removeFromAllCarns() {
        carnivoreArray.remove(this);
        totalCarnivores--;
    }
    
    /**
     * Method boolean to check if Carnivore moved this turn.
     * @return moved boolean
     */
    public boolean haveMoved() {
        return this.moved;
    }
    
    /**
     * Method to set the Carnviore moved status.
     * @param moved to boolean b true/false if moved.
     */
    public void setMoved(boolean b) {
        this.moved = b;
    }
    
    /**
     * Method boolean to check if Carnivore is dead this turn, health == 0.
     * @return boolean true/false
     */
    public boolean isDead() {
        if (this.health == 0) {
            return true;
        }
        return false;
    };
    
    /**
     * Method move for Cell Carnivore.move(), checks if there is adjacent Carnivore and avoids.
     * @return newCell the Carnivore moves into
     */
    public Cell move() {
        Cell[] adjCells = this.getEntityCell().getAdjacentCells(1);
        Cell[] validCells = new Cell[adjCells.length];
        Cell newCell = null;
        int validCellsIndex = 0;
        
        for (Cell cell : adjCells) {
            if (cell == null) {
                break;
            }
            //make sure not moving to another carnivore index
            if (cell.getCarnivore() != null) {
                continue;
            } else {
                validCells[validCellsIndex] = cell;
                validCellsIndex++;
            }
        }
        
        if (validCellsIndex > 0) {
            if (validCellsIndex == 1) {
                newCell = validCells[0];
            } else {
                newCell = validCells[RandomGenerator.nextNumber(validCellsIndex)];
            }
            
            super.move(getEntityCell(), newCell);
            setMoved(true);
        }
        return newCell;
    }
    
    
    /**
     * Returns the total amount of alive carnivores.
     * @return total number of alive Carnivores.
     */
    public static int countTotalAlive() {
        return totalCarnivores;
    }
}