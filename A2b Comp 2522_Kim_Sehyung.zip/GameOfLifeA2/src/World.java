import java.util.ArrayList;

/**
 * World class which contains cells, and controls take turn.
 * @author erickim
 * @version 1.0
 */
public class World {
    private final int rows;
    private final int columns;
    private Cell[][] cells;
    
    /**
     * Constructor for World class.
     * Holds Cells
     * @param rows
     * @param cols
     * 
     */
    public World(int rows, int cols) {
        super();
        this.rows = rows;
        this.columns = cols;
        this.cells = new Cell[rows][cols];
    }
    
    /**
     * Method init() to create and puts cells into the world,
     * newCell.init() calls Cell init() method to initialize herb/plants
     */
    public void init() {
        for (int row = 0; row < this.rows; row++) {
            for (int col = 0; col < this.columns; col++) {
                Cell cell = new Cell(this, row, col);
                cell.init();
                this.cells[row][col] = cell;
            }
        }
    }
    
    /**
     * Cell getCell method
     * @param col
     * @param row
     * @return cells
     */
    public Cell getCell(int row, int col) {
        return this.cells[row][col];
    }
    
    /**
     * Method to get Cells from Cells array
     * @return cells
     */
    public Cell[][] getCells() {
        return this.cells;
    }
    
    /**
     * Method to get row count.
     * @return rows
     */
    public int getRowCount() {
        return this.rows;
    }
    
    /**
     * Method to get column count.
     * @return columns
     */
    public int getColumnCount() {
        return this.columns;
    }
    
    /**
     * Method to take a turn, super methods with World object.
     **/
    public void takeTurn() {
        plantSeeds();
        removeDeadHerbivore();
        removeDeadCarnivore();
        removeDeadOmnivore();
        animalReproduction();
        herbivoreTakeTurn();
        carnivoreTakeTurn();
        omnivoreTakeTurn();
    }
    
    /**
     * Method to check plant reproduction.
     */
    private void plantSeeds() {
        ArrayList<Plant> newPlants = new ArrayList<Plant>();
        
        Plant[] plants = Plant.getAllPlants();
        for (Plant plant : plants) {
            //if plant boolean justSeeded is false
            if (!plant.justSeeded()) {
                Cell plantCell = plant.getEntityCell();
                //get seed cells method in Cell, using getAdjacent cells of radius 1.
                Cell[] seedCell = plantCell.getSeedCells(plantCell.getAdjacentCells(1));
                if (seedCell != null) {
                    plantCell = seedCell[RandomGenerator.nextNumber(seedCell.length)];
                    plantCell.seedCell();
                    newPlants.add(plantCell.getPlant());
                }
            }
        }
        
        for (Plant p : newPlants) {
            if (p != null) {
                p.init();
            }
        }
    }
    
    
    /**
     * Method to remove dead animals from cell.
     */
    public void removeDeadHerbivore() {
        Herbivore[] herbs = Herbivore.getAllHerbivores();
        for (Herbivore h: herbs) {
            if (h.isDead()) {
                h.getEntityCell().removeHerbivore();
                h.removeFromAllHerbs();
            }
        }
       
    }
    
    /**
     * Method to remove dead animals from cell.
     */
    public void removeDeadCarnivore() {
        Carnivore[] carns = Carnivore.getAllCarnivores();

        for (Carnivore c: carns) {
            if (c.isDead()) {
                c.getEntityCell().removeCarnivore();
                c.removeFromAllCarns();
            }
        }
    }
    
    /**
     * Method to remove dead animals from cell.
     */
    public void removeDeadOmnivore() {
        Omnivore[] omni = Omnivore.getAllOmnivores();
        for (Omnivore o: omni) {
            if (o.isDead()) {
                o.getEntityCell().removeOmnivore();
                o.removeFromAllOmni();
            }
        }
    }
    /**
     * Method to check animal reproduction
     */
    private void animalReproduction() {
        ArrayList<Herbivore> newHerbivores = new ArrayList<Herbivore>();
        ArrayList<Carnivore> newCarnivores = new ArrayList<Carnivore>();
        ArrayList<Omnivore> newOmnivores = new ArrayList<Omnivore>();

        Herbivore[] herbivores = Herbivore.getAllHerbivores();
        Carnivore[] carns = Carnivore.getAllCarnivores();
        Omnivore[] omni = Omnivore.getAllOmnivores();

        //HERBIVORE
        for (Herbivore herbivore : herbivores) {
            //if herbivore boolean herbivoreproduced is false
            if (!herbivore.justHProduced()) {
                Cell herbCell = herbivore.getEntityCell();
                //get herb cells method in Cell, using getAdjacent cells of radius 1.
                Cell[] hseedCell = herbCell.getHerbivoreCells(herbCell.getAdjacentCells(1));
                if (hseedCell != null) {
                    herbCell = hseedCell[RandomGenerator.nextNumber(hseedCell.length)];
                    herbCell.herbCell();
                    newHerbivores.add(herbCell.getHerbivore());
                }
            }
        }
        
        for (Herbivore h : newHerbivores) {
            if (h != null) {
                h.init();
            }
        }
        
        //CARNIVORE
        for (Carnivore carnivore : carns) {
            //if carnivore boolean carnivore reproduced is false
            if (!carnivore.justCProduced()) {
                Cell carnCell = carnivore.getEntityCell();
                //get carn cells method in Cell, using getAdjacent cells of radius 1.
                Cell[] cseedCell = carnCell.getCarnivoreCells(carnCell.getAdjacentCells(1));
                if (cseedCell != null) {
                    carnCell = cseedCell[RandomGenerator.nextNumber(cseedCell.length)];
                    carnCell.carnCell();
                    newCarnivores.add(carnCell.getCarnivore());
                }
            }
        }
        for (Carnivore c : newCarnivores) {
            if (c != null) {
                c.init();
            }
        }
        
        //OMNIVORE
        for (Omnivore omnivore : omni) {
            //if omnivore boolean omnivore reproduced is false
            if (!omnivore.justOProduced()) {
                Cell omniCell = omnivore.getEntityCell();
                //get herb cells method in Cell, using getAdjacent cells of radius 1.
                Cell[] oseedCell = omniCell.getOmnivoreCells(omniCell.getAdjacentCells(1));
                if (oseedCell != null) {
                    omniCell = oseedCell[RandomGenerator.nextNumber(oseedCell.length)];
                    omniCell.omniCell();
                    newOmnivores.add(omniCell.getOmnivore());
                }
            }
        }
        
        for (Omnivore o : newOmnivores) {
            if (o != null) {
                o.init();
            }
        }
    }
    
    /**
     * Method to make herbivores take 1 step turn, if landing on plant eat it.
     */
    private void herbivoreTakeTurn() {
        Herbivore[] herbs = Herbivore.getAllHerbivores();
        
        //herbivore
        for (Herbivore h : herbs) {
            if (!h.haveMoved()) {
                h.move();
                h.eatPlant();
            }
            h.minusHealth();
        }
        for (Herbivore h : herbs) {
            h.setMoved(false);
        }
        
        
    }
    
    private void carnivoreTakeTurn() {
        Carnivore[] carns = Carnivore.getAllCarnivores();
        
        //herbivore
        for (Carnivore c : carns) {
            if (!c.haveMoved()) {
                c.move();
                c.eatOmniHerbivore();
            }
            c.minusHealth();
        }
        for (Carnivore c : carns) {
            c.setMoved(false);
        }
        
        
    }
    
    private void omnivoreTakeTurn() {
        Omnivore[] omni = Omnivore.getAllOmnivores();
        
        //Omnivore
        for (Omnivore o : omni) {
            if (!o.haveMoved()) {
                o.move();
                o.eatPlantCarnivoreHerbivore();
            }
            o.minusHealth();
        }
        for (Omnivore o : omni) {
            o.setMoved(false);
        }
        
        
    }
    

}