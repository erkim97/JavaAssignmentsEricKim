/**
 * Enum class EntityType, used instead of instanceof, empty entity, plant entity, herbivore entity.
 * @author erickim
 * @version 1.0
 */
public enum EntityType {
    /**
     * Null empty entity.
     */
    EMPTY,
    /**
     * Plant Entity.
     */
    PLANT,
    /**
     * Herbivore Entity.
     */
    HERBIVORE,
    /**
     * Carnivore Entity.
     */
    CARNIVORE,
    /**
     * Omnivore Entity.
     */
    OMNIVORE,
}