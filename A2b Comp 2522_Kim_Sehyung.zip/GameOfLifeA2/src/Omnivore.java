import java.util.ArrayList;

/**
 * Creates an Entity of type Omnivore.
 * @author erickim
 * @version 1.0
 */
public class Omnivore extends Entity {
    private static ArrayList<Omnivore> omnivoreArray = new ArrayList<Omnivore>();
    private static int totalOmnivores;
    private static final int MAX_HEALTH = 5;
    private int health;
    private boolean moved;
    private boolean justOProduced = true;


    /**
     * Constructor for Omnivore Class, inside a cell.
     * @param cell
     */
    public Omnivore(Cell cell) {
        super(cell);
        setEntity(EntityType.OMNIVORE);
        totalOmnivores++;
    }
    
    /**
     * Method to initialize Omnivore with 5 health.
     */
    public void init() {
        this.health = MAX_HEALTH;
        omnivoreArray.add(this);
        this.justOProduced = false;
        this.moved = false;
    }
    
    /**
     * Method boolean to check if Omnivore newly reproduced.
     * @return justHProduced boolean
     */
    public boolean justOProduced() {
        return this.justOProduced;
    }
    
    /**
     * Method to eat plant/herbivore/carnivore if Omnivore is on a Cell that contains a plant/herbivore/carnivore entity.
     */
    public void eatPlantCarnivoreHerbivore() {
        Cell cell = this.getEntityCell();
        
        Herbivore h = cell.getHerbivore();
        Plant p = cell.getPlant();
        Carnivore c = cell.getCarnivore();
        if (p != null) {
            cell.removePlant();
            p.removeFromAllPlants();
            resetHealth();
        } else if (h != null) {
            cell.removeHerbivore();
            h.removeFromAllHerbs();
            resetHealth();
        } else if (c != null) {
            cell.removeCarnivore();
            c.removeFromAllCarns();
            resetHealth();
        }
    }
    
   

    /**
     * Method to decrease health of Omnivore by 1, every turn it takes.
     */
    public void minusHealth() {
        this.health -= 1;
    }

    /**
     * Method to reset the health of Omnivore back to 5, once eaten.
     */
    public void resetHealth() {
        this.health = MAX_HEALTH;
    }

    /**
     * Static method to get all Omnivores.
     * @return an array of Omnivores
     */
    public static Omnivore[] getAllOmnivores() {
        return omnivoreArray.toArray(new Omnivore[omnivoreArray.size()]);
    }

    /**
     * Method to remove Omnivore from Omnivore array list.
     */
    public void removeFromAllOmni() {
        omnivoreArray.remove(this);
        totalOmnivores--;
    }
    
    /**
     * Method boolean to check if Omnivore moved this turn.
     * @return moved boolean
     */
    public boolean haveMoved() {
        return this.moved;
    }
    
    /**
     * Method to set the Omnivore moved status.
     * @param moved to boolean b true/false if moved.
     */
    public void setMoved(boolean b) {
        this.moved = b;
    }
    
    /**
     * Method boolean to check if Omnivore is dead this turn, health == 0.
     * @return boolean true/false
     */
    public boolean isDead() {
        if (this.health == 0) {
            return true;
        }
        return false;
    };
    
    /**
     * Method move for Cell Omnivore.move(), checks if there is adjacent Omnivore and avoids.
     * @return newCell the Omnivore moves into
     */
    public Cell move() {
        Cell[] adjCells = this.getEntityCell().getAdjacentCells(1);
        Cell[] validCells = new Cell[adjCells.length];
        Cell newCell = null;
        int validCellsIndex = 0;
        
        for (Cell cell : adjCells) {
            if (cell == null) {
                break;
            }
            //make sure not moving to another omnivore index
            if (cell.getOmnivore() != null) {
                continue;
            } else {
                validCells[validCellsIndex] = cell;
                validCellsIndex++;
            }
        }
        
        if (validCellsIndex > 0) {
            if (validCellsIndex == 1) {
                newCell = validCells[0];
            } else {
                newCell = validCells[RandomGenerator.nextNumber(validCellsIndex)];
            }
            
            super.move(getEntityCell(), newCell);
            setMoved(true);
        }
        return newCell;
    }
    
    
    /**
     * Returns the total amount of alive carnivores.
     * @return total number of alive Carnivores.
     */
    public static int countTotalAlive() {
        return totalOmnivores;
    }
}