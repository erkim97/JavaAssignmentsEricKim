package q3;

/**
 * Cylinder. Design and implement a class called Cylinder that contains
 * instance data that represents the cylinder’s radius and height. 
 *
 * @author Sehyung Kim
 * @version 1.0
 */
public class Cylinder {
    
    /**
     * Instantiates constant value for PI to be used in calculations.
     */
    private static final double PI = 3.14159;
    
    /**
     * Declared cylinder private radius as a double.
     */
    private double cylinderRadius;
    
    /**
     * Declared cylinder private height as a double.
     */
    private double cylinderHeight;
    
    /**
     * Constructor with parameters.
     * @param radius as a double
     * @param height as a double
     */
    public Cylinder(double radius, double height) {
        this.cylinderRadius = radius;
        this.cylinderHeight = height;
    }

    /**
     * Accessor.
     * @return the cylinderRadius
     */
    public double getCylinderRadius() {
        return cylinderRadius;
    }

    /**
     * Mutator.
     * @param cylinderRadius the cylinderRadius to set
     */
    public void setCylinderRadius(double cylinderRadius) {
        this.cylinderRadius = cylinderRadius;
    }

    /**
     * Accessor.
     * @return the cylinderHeight
     */
    public double getCylinderHeight() {
        return cylinderHeight;
    }

    /**
     * Mutator.
     * @param cylinderHeight the cylinderHeight to set
     */
    public void setCylinderHeight(double cylinderHeight) {
        this.cylinderHeight = cylinderHeight;
    }
    
    /**
     * Method for the surface area of a cylinder using formula.
     * @return the surface area of a cylinder
     */
    public double cylinderSurfaceArea() {
        double cylinderSurfaceArea = (2 * PI * cylinderRadius 
                * (cylinderRadius + cylinderHeight));
        return cylinderSurfaceArea;
    }
    
    /**
     * Method for the surface area of a cylinder using formula.
     * @return the surface area of a cylinder
     */
    public double cylinderVolume() {
        double cylinderVolume = PI * Math.pow(cylinderRadius, 2)
                                * cylinderHeight;
        return cylinderVolume;
    }

    /** 
     * toString method to return desired string output.
     * @return string of the description of cylinder
     */
    
    public String toString() {
        return "Your Cylinder has radius= " + cylinderRadius + "\nYour Cylinder"
                + " has height= " + cylinderHeight + "\nSurface Area is= " 
                + cylinderSurfaceArea() + "\nVolume is= " + cylinderVolume();
                
    }
    
};
