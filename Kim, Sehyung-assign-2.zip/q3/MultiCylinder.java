package q3;

import java.util.Scanner;

/**
 * Create a driver class, called MultiCylinder, that instantiates and updates
 * two Cylinder objects, printing their radius and height before and after
 * modification, and prints the final volume and surface area of each cylinder.
 *
 * @author Sehyung Kim
 * @version 1.0
 */
public class MultiCylinder {
    /**
     * This is the main method (entry point) that gets called by the JVM.
     *
     * @param args command line arguments.
     */
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        System.out.println("Enter in the cylinder radius and height");
        int radius = scan.nextInt();
        int height = scan.nextInt();
        // create Cylinder object with the radius and height
        Cylinder cylinder = new Cylinder(radius, height);
        System.out.println(cylinder);

        System.out.println("Enter in new cylinder radius and height");
        int radius1 = scan.nextInt();
        int height1 = scan.nextInt();
        // create new Cylinder object with the radius1 and height1
        Cylinder cylinder1 = new Cylinder(radius1, height1);
        System.out.println(cylinder1);

        System.out.println("Question three was called and ran sucessfully.");
        scan.close();
    }

}
