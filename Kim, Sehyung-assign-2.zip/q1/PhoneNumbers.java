package q1;

import java.text.DecimalFormat;
import java.util.Random;

/**
 * PhoneNumbers. Generates a random phone number what creates and prints a
 * random phone number of the form ###-###-####. First three numbers can't
 * contain 8 or 9, zero's can be anywhere.
 * 
 * @author Sehyung Kim
 * @version 1.0
 */
public class PhoneNumbers {

    /**
     * Random generator int 8, as req. 0-7 excluding 8 or 9.
     */
    private static final int EIGHT = 8;

    /**
     * First three numbers with restriction, hundreds place.
     */
    private static final int ONE_HUNDRED = 100;

    /**
     * First three numbers with restriction, tens place.
     */
    private static final int TEN = 10;

    /**
     * Random number below 635 random generation int.
     */
    private static final int SIX_THREE_SIX = 636;

    /**
     * Random number below 10000 random generation int.
     */
    private static final int TEN_THOUSAND = 10000;

    /**
     * This is the main method (entry point) that gets called by the JVM.
     *
     * @param args command line arguments.
     */
    public static void main(String[] args) {

        Random generator = new Random();
        int num1 = (generator.nextInt(EIGHT)) * ONE_HUNDRED 
                + (generator.nextInt(EIGHT) * TEN)
                + generator.nextInt(EIGHT);

        int num2 = generator.nextInt(SIX_THREE_SIX);
        int num3 = generator.nextInt(TEN_THOUSAND);

        DecimalFormat df3 = new DecimalFormat("000"); // 3 zeros
        DecimalFormat df4 = new DecimalFormat("0000"); // 4 zeros

        String phoneNumber = df3.format(num1) + "-" + df3.format(num2) + "-" 
                           + df4.format(num3);

        System.out.println(phoneNumber);

        System.out.println("Question one was called and ran sucessfully.");
    }

};
