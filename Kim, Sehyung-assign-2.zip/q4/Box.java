package q4;

/**
 * Box. Design and implement a class called Box that contains instance data
 * representing the height, width, and depth of the box. Also include a boolean
 * variable called full as instance data that represents whether the box is full
 * or not.
 * 
 * @author Sehyung Kim
 * @version 1.0
 */
public class Box {

    /**
     * Declared box variable private height as a double.
     */
    private double height;

    /**
     * Declared box variable private width as a double.
     */
    private double width;

    /**
     * Declared box variable private depth as a double.
     */
    private double depth;

    /**
     * Declared box fullness as a boolean.
     */
    private boolean full;

    /**
     * Constructor with parameters.
     * 
     * @param h as a double for height
     * @param w as a double for width
     * @param d as a double for depth
     */
    public Box(double h, double w, double d) {
        this.height = h;
        this.width = w;
        this.depth = d;
        this.full = false;
    }

    /**
     * Accessor.
     * 
     * @return the height
     */
    public double getHeight() {
        return height;
    }

    /**
     * Mutator.
     * 
     * @param height the height to set
     */
    public void setHeight(double height) {
        this.height = height;
    }

    /**
     * Accessor.
     * 
     * @return the width
     */
    public double getWidth() {
        return width;
    }

    /**
     * Mutator.
     * 
     * @param width the width to set
     */
    public void setWidth(double width) {
        this.width = width;
    }

    /**
     * Accessor.
     * 
     * @return the depth
     */
    public double getDepth() {
        return depth;
    }

    /**
     * Mutator.
     * 
     * @param depth the depth to set
     */
    public void setDepth(double depth) {
        this.depth = depth;
    }

    /**
     * Accessor boolean method for box fullness.
     * 
     * @return the full
     */
    public boolean isFull() {
        return full;
    }

    /**
     * Mutator boolean method for box fullness.
     * 
     * @param full the full to set
     */
    public void setFull(boolean full) {
        this.full = full;
    }

    /**
     * toString method to return desired string output.
     * 
     * @return string of the description of box object
     */
    public String toString() {
        return "Height: " + height + "| Width: " + width + "| Depth: " 
                + depth + " | Full? " + isFull();

    }
};
