package q4;

/**
 * BoxTest. Driver whose main method instantiates and updates two Box objects.
 * BoxTest should call each Box method at least once and print enough
 * information to indicate that the methods worked correctly.
 *
 * @author Sehyung Kim
 * @version 1.0
 */
public class BoxTest {
    
    /**
     * Magic number value 3.
     */
    private static final double THREE = 3.0;
    
    /**
     * Magic number value 4.
     */
    private static final double FOUR = 4.0;
    
    /**
     * Magic number value 5.
     */
    private static final double FIVE = 5.0;
    /**
     * This is the main method (entry point) that gets called by the JVM.
     *
     * @param args command line arguments.
     */
    public static void main(String[] args) {
        Box box = new Box(1.0, 2.0, THREE);
        System.out.println("First box:");
        System.out.println("  " + box);
        System.out.println();
        box.setFull(true);
        
        System.out.println("After filling first box:");
        System.out.println("  " + box);
        System.out.println();
        
        Box box2 = new Box(THREE, FOUR, FIVE);
        System.out.println("Second box:");
        System.out.println("  " + box2);
        System.out.println();
        box2.setFull(true);

        System.out.println("Calling all getter methods on the first box: ");
        System.out.println("Height: " + box.getHeight());
        System.out.println("Width: " + box.getWidth());
        System.out.println("Depth: " + box.getDepth());
        System.out.println("Full: " + box.isFull());
    }
}
