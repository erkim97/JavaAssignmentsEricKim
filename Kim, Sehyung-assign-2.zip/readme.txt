[Sehyung Kim], [A01089966], [C], [March, 2, 2019]

This assignment is [100]% complete.


------------------------
Question one (PhoneNumbers) status:

[complete]

------------------------
Question two (CylinderStats) status:

[complete]

------------------------
Question three (Cylinder) status:

[complete]

------------------------
Question four (Box) status:

[complete]

------------------------
Question five (Email) status:

[complete]
