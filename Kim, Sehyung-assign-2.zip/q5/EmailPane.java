package q5;

import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;
import javafx.scene.control.TextField;

/**
 * EmailPane. Gridpane which implements a prototype user interface for 
 * composing an email message. The application should have labeled text 
 * fields for the To, CC, and Bcc address lists, a subject line, and 
 * one for the message body.
 * 
 * @author Sehyung Kim
 * @version 1.0
 */

public class EmailPane extends GridPane {
    /** Displays To textfield for user. */
    private TextField textFieldTo;

    /** Displays Cc textfield for user. */
    private TextField textFieldCc;
    
    /** Displays Bcc textfield for user. */

    private TextField textFieldBcc;

    /** Displays Subject textfield for user. */
    private TextField textFieldSub;
    
    /** Displays Message textfield for user. */
    private TextArea textFieldMsg;
    
    /**
     * Magic number value 3.
     */
    private final double threeHundred = 300;
    
    /**
     * Magic number value 3.
     */
    private final double fiveHundred = 500;
    
    /**
     * Magic number value 3.
     */
    private final int three = 3;

    /**
     * Magic number value 4.
     */
    private final int four = 4;
    
    /**
     * Magic number value 5.
     */
    private final int five = 5;
    
    /**
     * Magic number value 6.
     */
    private final int six = 6;
    
    /**
     * Magic number value 10.
     */
    private final int ten = 10;

    /**
     * EmailPane class method runs code, used in Email.java in setScene.
     */
    public EmailPane() {
        // Creating a Grid Pane
        GridPane grid = new GridPane();

        Text to = new Text("To:");
        Text cc = new Text("CC:");
        Text bcc = new Text("Bcc:");
        Text subject = new Text("Subject:");
        Text message = new Text("Message Body:");

         textFieldTo = new TextField();
         textFieldCc = new TextField();
         textFieldBcc = new TextField();
         textFieldSub = new TextField();
         textFieldMsg = new TextArea();
         textFieldMsg.setPrefSize(fiveHundred, threeHundred);

        Button button = new Button("Send");

        grid.add(to, 0, 1);
        grid.add(textFieldTo, 1, 1);
        grid.add(cc, 0, 2);
        grid.add(textFieldCc, 1, 2);
        grid.add(bcc, 0, three);
        grid.add(textFieldBcc, 1, three);
        grid.add(subject, 0, four);
        grid.add(textFieldSub, 1, four);
        grid.add(message, 0, five);
        grid.add(textFieldMsg, 1, five);
        grid.add(button, 0, six, 1, 1);
        grid.setHgap(ten);
        grid.setVgap(ten);
        grid.setPadding(new Insets(0, ten, 0, ten));

        button.setOnAction(this::handleSubmitButtonAction);

        getChildren().addAll(grid);
    }

    /**
     * setOnAction ActionEvent event for handleSubmitButtonAction for 
     * println output inside the message textArea.
     * @param event invokes this method.
     */
    public void handleSubmitButtonAction(ActionEvent event) {
        System.out.println("To: " + textFieldTo.getText() + "\n" + "Cc: " 
                           + textFieldCc.getText() + "\n" + "Bcc: " 
                           + textFieldBcc.getText() +  "\n" + "Subject: " 
                           + textFieldSub.getText() + "\n" + "Message: " 
                           + textFieldMsg.getText());
    }
}
