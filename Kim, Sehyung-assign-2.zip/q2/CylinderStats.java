package q2;

import java.text.DecimalFormat;
import java.util.Scanner;

/**
 * CylinderStats. Reads the radius and height of a cylinder and prints its
 * surface area and volume. Prints the output to four decimal places. In the
 * formulas, r represents the radius and h the height.
 *
 * @author Sehyung Kim
 * @version 1.0
 */
public class CylinderStats {

    /**
     * Instantiates constant value for PI to be used in calculations.
     */
    private static final double PI = 3.14159;

    /**
     * This is the main method (entry point) that gets called by the JVM.
     *
     * @param args command line arguments.
     */
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        System.out.println("What is the Cylinder's Radius?");
        double inputRadius = scan.nextDouble();

        System.out.println("What is the Cylinder's Height?");
        double inputHeight = scan.nextDouble();

        // SurfaceArea of Cylinder Calculation
        double cylinderSurfaceArea = (2 * PI * inputRadius 
                                        * (inputRadius + inputHeight));
        // Volume of Cylinder Calculation
        double cylinderVolume = PI * Math.pow(inputRadius, 2) * inputHeight;

        DecimalFormat fmt = new DecimalFormat("0.0000");
        System.out.println("The Surface Area of your Cylinder is: " 
                            + fmt.format(cylinderSurfaceArea)
                            + "\nThe Volume of your" + "Cylinder is: " 
                            + fmt.format(cylinderVolume));

        System.out.println("Question two was called and ran sucessfully.");
        scan.close();

    }
};
