import javafx.scene.control.RadioButton;
import javafx.scene.layout.Pane;

/**
 * RadioButton for Square
 */
class SquareButton extends Pane {

    /**
     * RadioButton staticobject for square.
     */
    static RadioButton square;

    /**
     * Constructor for Square button.
     */
    SquareButton() {
        square = new RadioButton("Square");
        square.setToggleGroup(PanelButtons.tools);
        getChildren().add(square);
    }
}
