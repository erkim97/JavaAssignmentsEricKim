import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;

/**
 * Creates buttons on the panel on the left side extends VBox
 */
class PanelButtons extends VBox {

    /**
     * ToggleGroup static object tools.
     */
    static ToggleGroup tools;

    Pane squarePane;
    Pane rectanglePane;
    Pane circlePane;
    Pane ovalPane;
    Pane selectPane;
    Pane deletePane;
    Pane polygonPane;

    PanelButtons(){
        tools = new ToggleGroup();
        squarePane = new SquareButton();
        rectanglePane = new RectangleButton();
        circlePane = new CircleButton();
        ovalPane = new OvalButton();
        selectPane = new SelectButton();
        deletePane = new DeleteButton();

        VBox panelButtons = new VBox(20);
        //Add all ToggleGroups to panel as btns
        panelButtons.getChildren().addAll(rectanglePane, ovalPane, squarePane, circlePane, selectPane, deletePane);
        getChildren().add(panelButtons);
    }

    RadioButton getSelectedButton() {
        return (RadioButton) tools.getSelectedToggle();
    }


}
