import javafx.scene.canvas.Canvas;

/**
 * Rectangle extends abstract class shape.
 */
public class Rectangle extends Shape {

    /**
     * Constructor for Rectangle.
     * @param startX Starting X coordinate.
     * @param startY Starting Y coordinate.
     * @param endX Ending X coordinate.
     * @param endY Ending Y coordinate.
     * @param canvas Canvas object.
     */
    Rectangle(double startX, double startY, double endX, double endY, Canvas canvas) {
        super(startX, startY, endX, endY, canvas);
    }

    @Override
    public void fillShape() {
        gc = canvas.getGraphicsContext2D();
        gc.setFill(color);
        gc.fillRect(drawStartX, drawStartY, getWidth(), getHeight());
    }

    @Override
    public boolean shapeLocation(double x, double y) {
        if(x <= drawEndX && x >= drawStartX && y <= drawEndY && y >= drawStartY) {
            return true;
        }
        return false;
    }

}
