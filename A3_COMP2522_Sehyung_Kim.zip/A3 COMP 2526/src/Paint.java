import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.control.RadioButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.util.ArrayList;

/**
 * Painting the Canvas creating the canvas and mouse events.
 * 
 * @author Eric Kim
 * @version 1.0
 */
public class Paint extends Application {
    
    private String shapeString;
    static Color color;
    private static double startX;
    private static double startY;
    private double endX;
    private double endY;
    private static Pane pane;
    private LeftPanel leftPanel;
    private Canvas canvas;
    private Shape shape;
    private static ArrayList<Shape> listOfShapes = new ArrayList<>();
    private int shapeIndex = -1;
    private RadioButton radioButton;

    public Paint(){
    }

    @Override
    public void start(Stage stage) {
        stage.setTitle("Assignment 3");

        leftPanel = new LeftPanel();
        HBox root = new HBox(leftPanel);

        pane = new Pane();
        pane.setStyle("-fx-background-color: white;");
        pane.setPrefSize(600, 600);
        pane.setOnMousePressed(this::onMousePressed);
        pane.setOnMouseDragged(this::onMouseDragged);
        pane.setOnMouseReleased(this::onMouseReleased);
        
        root.getChildren().add(pane);
        Scene scene = new Scene(root, 800, 600);
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Mouse Press Event, gets X,Y Coordinates, Color, RadioBtn, and shapeindex, draws shape
     * @param event OnMousePressed.
     */
    private void onMousePressed(MouseEvent event) {
        startX = event.getX();
        startY = event.getY();

        color = leftPanel.clr.getColor();
        radioButton = leftPanel.btn.getSelectedButton();


        if (radioButton == SelectButton.select) {
            for (int i = listOfShapes.size() - 1; i >= 0; i--) {
                if (listOfShapes.get(i).shapeLocation(startX, startY)) {
                    shapeIndex = i;
                    break;
                }
            }
        }
        else if (radioButton == DeleteButton.delete) {
            for (int i = listOfShapes.size() - 1; i >= 0; i--) {
                if (listOfShapes.get(i).shapeLocation(startX, startY)) {
                    shapeIndex = i;
                    break;
                }
            }
            if (shapeIndex != -1) {
                Canvas cv = listOfShapes.get(shapeIndex).getCanvas();
                pane.getChildren().remove(cv);
                listOfShapes.remove(shapeIndex);
                shapeIndex = -1;
            }
        }
        else {
            if (radioButton == RectangleButton.rec) {
                shapeString = "rectangle";
            }
            if (radioButton == SquareButton.square) {
                shapeString = "square";
            }
            if (radioButton == OvalButton.oval) {
                shapeString = "oval";
            }
            if (radioButton == CircleButton.circle) {
                shapeString = "circle";
            }
            assert shapeString != null;
            drawShape(shapeString);
        }
    }

    /**
     * Determines which shape based on which radiobutton is currently selected.
     * @param shapeString Shape as a string.
     */
    private void drawShape(String shapeString) {
        canvas = new Canvas(600, 600);
        switch(shapeString) {
            case "rectangle":
                this.shape = new Rectangle(startX, startY, endX, endY, canvas);
                break;
            case "square":
                this.shape = new Square(startX, startY, endX, endY, canvas);
                break;
            case "oval":
                this.shape = new Oval(startX, startY, endX, endY, canvas);
                break;
            case "circle":
                this.shape = new Circle(startX, startY, endX, endY, canvas);
                break;
        }
        this.shape.setColor(color);
        pane.getChildren().add(canvas);
    }

    /**
     * Creates a shape using X,Y coordinates on dragging event.
     * @param event OnMouse Dragged.
     */
    private void onMouseDragged(MouseEvent event) {

        endX = event.getX();
        endY = event.getY();

        if(radioButton == SelectButton.select) {
            if(shapeIndex != -1) {
                moveShape(endX, endY);
            }
        }
        else if (radioButton == DeleteButton.delete){
        }
        else {
            shape.setEndX(endX);
            shape.setEndY(endY);
            createShape();
        }
    }

    /**
     * Based on current mouse X,Y, moveShape method
     * @param x current X coordinate.
     * @param y current Y coordinate.
     */
    private void moveShape(double x, double y) {
        Shape moveShape = listOfShapes.get(shapeIndex);
        pane.getChildren().remove(moveShape.getCanvas());
        moveShape.setCanvas(new Canvas(600,600));
        moveShape.setDrawStartX(x);
        moveShape.setDrawStartY(y);
        moveShape.fillShape();
        moveShape.confirmShape();
        pane.getChildren().add(moveShape.getCanvas());
    }

    /**
     * Removes and creates a new canvas method while dragging mouse event. 
     */
    private void createShape() {
        pane.getChildren().remove(canvas);
        canvas = new Canvas(600,600);
        shape.setCanvas(canvas);
        shape.fillShape();
        pane.getChildren().add(canvas);
    }

    /**
     * On mouse release, confirm shape method, adds to array of shapes
     * @param me On Mouse Release.
     */
    private void onMouseReleased(MouseEvent me) {
                shape.confirmShape();
                listOfShapes.add(shape);
               
    }

    public static void main(String[] args){
        launch(args);
    }

}

