import javafx.scene.control.RadioButton;
import javafx.scene.layout.Pane;

/**
 * RadioButton for the select button.
 */
class SelectButton extends Pane{

    /**
     * RadioButton static object for select.
     */
    static RadioButton select;
    /**
     * Constructor for Select button.
     */
    SelectButton() {
        select = new RadioButton("Move");
        select.setToggleGroup(PanelButtons.tools);
        getChildren().add(select);
    }
}
