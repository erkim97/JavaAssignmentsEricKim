import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

/**
 * Abstract super class.
 */
public abstract class Shape {

    double startX;
    double startY;
    double endX;
    double endY;
    double drawStartX;
    double drawStartY;
    double drawEndX;
    double drawEndY;
    Canvas canvas;
    Color color;

    GraphicsContext gc;

    /**
     * Constructor for Shape.
     * @param strtX Starting X coordinate.
     * @param strtY Starting Y coordinate.
     * @param eX Ending X coordinate.
     * @param eY Ending Y coordinate.
     * @param canvas Canvas object.
     */
    Shape(double strtX, double strtY, double eX, double eY, Canvas canvas){
        this.startX = strtX;
        this.startY = strtY;
        this.endX = eX;
        this.endY = eY;
        this.canvas = canvas;
        this.drawStartX = startX;
        this.drawStartY = startY;
        this.drawEndX = endX;
        this.drawEndY = endY;
    }

    /**
     * Setter for endX coordinate.
     * Negative X coordinates will be replaced by opposite coordinates.
     * (Start to end & vice versa).
     * @param eX End X coordinate.
     */
    void setEndX(double eX){
        if(eX - startX < 0) {
            drawStartX = eX;
            drawEndX = startX;
        }
//        this.startX = sX;
        this.endX = eX;
    }

    /**
     * Setter for endY coordinate.
     * Negative Y coordinates will be replaced by opposite coordinates.
     * (Start to end & vice versa).
     * @param eY End Y coordinate.
     */
    void setEndY(double eY){
        if(eY - startY < 0) {
            drawStartY = eY;
            drawEndY = startY;
        }
//        this.startY = sY;
        this.endY = eY;
    }

    /**
     * Setter method
     * @param drawStX Draw Starting X coordinate.
     */
    void setDrawStartX(double drawStX) {
        this.drawStartX = drawStX;
    }

    /**
     * Setter method.
     * @param drawStY Draw starting Y coordinate
     */
    void setDrawStartY(double drawStY) {
        this.drawStartY = drawStY;
    }

    /**
     * Getter method.
     * @return canvas.
     */
    Canvas getCanvas() {
        return canvas;
    }

    /**
     * Setter method.
     * @param c canvas.
     */
    void setCanvas(Canvas c) {
        this.canvas = c;
    }

    /**
     * Setter method.
     * @param c color.
     */
    void setColor(Color c){
        this.color = c;
    }

    /**
     * Helper method for onMouseReleased() setting the shape of the drawing.
     */
    void confirmShape(){
        drawEndX = drawStartX + getWidth();
        drawEndY = drawStartY + getHeight();
    }

    /**
     * Getter method.
     * @return width.
     */
    double getWidth(){
        return Math.abs(endX - startX);
    }

    /**
     * Getter method.
     * @return height.
     */
    double getHeight() {
        return Math.abs(endY - startY);
    }

    /**
     * Fills the abstract canvas shape.
     * note: fillRect(left, top, width, height);
     */
    public abstract void fillShape();

    /**
     * Determines current shape and its location.
     * @param x Starting X coordinate.
     * @param y Starting Y coordinate.
     * @return Boolean.
     */
    public abstract boolean shapeLocation(double x, double y);

}
