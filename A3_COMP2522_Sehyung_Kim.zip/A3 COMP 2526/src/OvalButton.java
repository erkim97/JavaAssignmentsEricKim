import javafx.scene.control.RadioButton;
import javafx.scene.layout.Pane;

/**
 * RadioButton for the oval button.
 */
class OvalButton extends Pane {

    /**
     * RadioButton object for oval.
     */
    static RadioButton oval;
    /**
     * Constructor for Oval button.
     */
    OvalButton() {
        oval = new RadioButton("Oval");
        oval.setToggleGroup(PanelButtons.tools);
        getChildren().add(oval);
    }
}
