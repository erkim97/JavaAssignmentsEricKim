import javafx.scene.control.RadioButton;
import javafx.scene.layout.Pane;

/**
 * RadioButton for the rectangle button.
 */
class RectangleButton extends Pane {

    /**
     * RadioButton static object for rectangle.
     */
    static RadioButton rec;

    /**
     * Constructor for Rectangle button.
     */
    RectangleButton() {
        rec = new RadioButton("Rectangle");
        rec.setToggleGroup(PanelButtons.tools);
        getChildren().add(rec);
        rec.setSelected(true);
    }


}
