import javafx.scene.control.RadioButton;
import javafx.scene.layout.Pane;

/**
 * RadioButton for the circle button.
 */
class CircleButton extends Pane {

    /**
     * RadioButton static object for circle.
     */
    static RadioButton circle;

    /**
     * Constructor Circle button.
     */
    CircleButton() {
        circle = new RadioButton("Circle");
        circle.setToggleGroup(PanelButtons.tools);
        getChildren().add(circle);
    }
}
