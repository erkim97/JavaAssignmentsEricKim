import javafx.scene.canvas.Canvas;

/**
 * Circle extends abstract class shape.
 */
public class Circle extends Shape {

    /**
     * Constructor for circle
     * @param startX Starting X coordinate.
     * @param startY Starting Y coordinate.
     * @param endX Ending X coordinate.
     * @param endY Ending Y coordinate.
     * @param canvas Canvas object.
     */
    Circle(double startX, double startY, double endX, double endY, Canvas canvas) {
        super(startX, startY, endX, endY, canvas);
    }

    @Override
    public void fillShape() {
        endY = startY + (endX - startX);
        gc = canvas.getGraphicsContext2D();
        gc.setFill(color);
        gc.fillOval(drawStartX, drawStartY, getWidth(), getWidth());
    }

    @Override
    public void setEndY(double endY){
        if(endY - startY < 0) {
            drawStartY = startY - getWidth();
            drawEndY = startY;
        }
        this.endY = endY;
//        this.startY = sY;
    }

    @Override
    public boolean shapeLocation(double x, double y) {
        if(x <= drawEndX && x >= drawStartX && y <= drawEndY && y >= drawStartY) {
            return true;
        }
        return false;
    }


}
