import javafx.scene.layout.VBox;

/**
 * Left panel class extends vertical box.
 */
class LeftPanel extends VBox{

    private VBox vbox;
    PanelButtons btn;
    PanelColors clr;

    /**
     * Panel for the left side of scene.
     */
    LeftPanel() {
        btn = new PanelButtons();
        clr = new PanelColors();
        vbox = new VBox(60, btn, clr);
        getChildren().add(vbox);
    }

}
