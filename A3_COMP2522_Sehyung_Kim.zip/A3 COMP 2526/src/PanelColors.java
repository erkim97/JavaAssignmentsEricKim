import javafx.event.ActionEvent;
import javafx.scene.control.ColorPicker;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;

/**
 * Panel color selection pane drop down.
 */
public class PanelColors extends Pane {

    private Color selectedColor;

    private ColorPicker colorPicker;

    /**
     * PanelColors Constrcutor.
     */
    PanelColors() {
        colorPicker = new ColorPicker();
        selectedColor = Color.BLACK;
        colorPicker.setValue(Color.BLACK);
        colorPicker.setOnAction(this::setColor);
        getChildren().add(colorPicker);

    }

    /**
     * Gets the color.
     * @return color
     */
    Color getColor() {
        return selectedColor;
    }

    /**
     * Setter method.
     * @param event Color.
     */
    private void setColor(ActionEvent event) {
        selectedColor = colorPicker.getValue();
        Paint.color = selectedColor;
    }
}
