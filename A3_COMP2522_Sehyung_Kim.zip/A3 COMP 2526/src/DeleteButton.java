import javafx.scene.control.RadioButton;
import javafx.scene.layout.Pane;

/**
 * RadioButton for the delete button.
 */
class DeleteButton extends Pane{

    /**
     * RadioButton static object for delete.
     */
    static RadioButton delete;

    /**
     * Constructor for Select button.
     */
    DeleteButton() {
        delete = new RadioButton("Delete");
        delete.setToggleGroup(PanelButtons.tools);
        getChildren().add(delete);
    }
}
