
package ca.bcit.comp1510.lab10;
import java.util.Random;
import java.util.Scanner;

/**
 * The program will simulate a drunk staggering around on 
 * some square platform (imagine a square dock in the middle of a lake). 
 * The goal of the program is to simulate the walk many times and see how many 
 * times the drunk falls off the platform (goes out of bounds).
 * 
 * @author eric kim
 * @version 1.0
 */
public class DrunkWalker {

    /**
     * Runs the simulation with boundary, # of steps, and with # of drunks.
     * @param args command line arguments (unused)
     */
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        Random generator = new Random();
        System.out.println("Enter the boundary");
        int boundary = scan.nextInt();
        System.out.println("Enter the steps");
        int maxSteps = scan.nextInt();
        System.out.println("Enter number of drunks");
        int drunks = scan.nextInt();
        int falls = 0;
                
        for (int i = 1; i <= drunks; i++) {
            int currentX = 0;
            int currentY = 0;
            int steps = 0;
            
            while ((currentX <= boundary && currentX >= -boundary 
                    && currentY <= boundary && currentY >= -boundary) 
                    && steps <= maxSteps) {
              //0,1,2,3 random generation 3 
                final int three = 3;
                final int directions = 4;
                int move = generator.nextInt(directions);
                        
                switch (move) {
                case 0:
                    currentX++;
                    break;
                case 1:
                    currentY++;
                    break;
                case 2:
                    currentX--;
                    break;
                case three:
                    currentY--;
                    break;
                default:
                }
                steps++;
               
            }
            if (steps <= maxSteps) {
                falls++;
            }
               
        }
        
        System.out.println("The total number of tests:" + drunks);
        System.out.println("The number of falls:" + falls);
        scan.close();
       
    }

}
