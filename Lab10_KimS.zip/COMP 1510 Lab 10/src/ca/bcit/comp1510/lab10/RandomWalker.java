package ca.bcit.comp1510.lab10;

import java.util.Random;

/**
 * A simple robot to model a random walk on a two-dimensional square grid.
 *
 * @author eric kim
 * @version 1.0
 */
public class RandomWalker {
    /** Integer for the current X-coordinate. */
    private int currentX;
    
    /** Integer for the current Y-coordinate. */
    private int currentY;
    
    /** Integer for the max steps. */
    private int maxSteps;
    
    /** Integer for the current steps. */
    private int currentSteps;
    
    /** Integer for the boundary. */
    private int maxBoundary;
    
    /** Integer for the maximum distance. */
    private int maximumDistance;
    
    /**
     * Constructor for a random walker object with max steps and boundary.
     * @param maxSteps
     *            integer for max steps
     * @param boundary
     *            integer for max boundary
     */
    public RandomWalker(int maxSteps, int boundary) {
        this.maxSteps = maxSteps;
        this.maxBoundary = boundary;
        this.currentX = 0;
        this.currentY = 0;
        this.currentSteps = 0;
        this.maximumDistance = 0;
    }
    
    /**
     * Constructor for a random walker object with its current X-coordinate, 
     * current Y-coordinate, max steps and boundary.
     * @param currentX
     *            integer for current X-coordinate
     * @param currentY
     *            integer for current Y-coordinate
     * @param maxSteps
     *            integer for max steps
     * @param boundary
     *            integer for boundary
     */
    public RandomWalker(int currentX, int currentY,
            int maxSteps, int boundary) {
        this.currentX = currentX;
        this.currentY = currentY;
        this.maxSteps = maxSteps;
        this.maxBoundary = boundary;
        this.currentSteps = 0;
        this.maximumDistance = 0;
    }
    
    /**
     * a toString that prints out the coordinates and the current step number.
     * @return integer of x and y coordinates and integer of current steps
     */
    public String toString() {
        return "currentX = " + currentX + ", currentY = " + currentY 
                + ", currentSteps = " + currentSteps + ".";
    }
    
    /**
     * Simulation of a single random step.
     */
    public void takeStep() {
        Random generator = new Random();
        final int directions = 4;
        final int three = 3;
        int move = generator.nextInt(directions);
                
        switch (move) {
        case 0:
            currentX++;
            break;
        case 1:
            currentY++;
            break;
        case 2:
            currentX--;
            break;
        case three:
            currentY--;
            break;
        default:
        }
        currentSteps++;
        maximumDistance = max(maximumDistance,
                max(Math.abs(currentX), Math.abs(currentY)));
                
    }
    
    /**
     * Returns if the current steps less than max steps.
     * @return boolean represents if the number of steps less than max steps.
     */
    public boolean moreSteps() {
        return currentSteps < maxSteps;
    }
    
    /**
     * Returns if the current coordinates is in boundary.
     * @return boolean represents if the current coordinates is in boundary.
     */
    public boolean inBounds() {
        return currentX <= maxBoundary && currentX >= -maxBoundary 
                && currentY <= maxBoundary && currentY >= -maxBoundary;
    }
    
    /**
     * Uses a loop to simulate a random walk. Keep taking steps 
     * with two conditions of max steps not taken and still in boundary.
     */
    public void walk() {
        while (this.moreSteps() && this.inBounds()) {
            this.takeStep();
        }
    }
    
    /**
     * Returns larger integer of the two integers.
     * @param a
     *            integer for first number
     * @param b
     *            integer for second number
     * @return the integer that is larger, a or b.
     */
    private int max(int a, int b) {
        if (a > b) {
            return a;
        } else {
            return b;
        }
    }
    
    /**
     * Accessor for maximum distance.
     * @return integer of maximum distance.
     */
    public int getMaximumDistance() {
        return maximumDistance;
    }
    
    /**
     * Accessor for current X-coordinate.
     * @return integer of current X-coordinate.
     */
    public int getCurrentX() {
        return currentX;
    }
    
    /**
     * Accessor for current Y-coordinate.
     * @return integer of current Y-coordinate.
     */
    public int getCurrentY() {
        return currentY;
    }

}