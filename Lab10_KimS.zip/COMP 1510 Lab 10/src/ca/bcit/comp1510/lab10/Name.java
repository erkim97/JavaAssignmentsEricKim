package ca.bcit.comp1510.lab10;

/**
 * Name object implementing Comparable, of first name,
 * middle name, and last name.
 * @author erickim
 * @version 1.0
 * 
 */
public class Name implements Comparable<Name> {
    /** String variable to hold first name. */
    private final String firstName;
    
    /** String variable to hold middle name. */
    private final String middleName;
    
    /** String variable to hold last name. */
    private final String lastName;
    
    /**
     * Constructor for a Name with first, middle and last name.
     * @param firstName a String for first name
     * @param middleName a String for middle name
     * @param lastName a String for last name
     */
    public Name(String firstName, String middleName, String lastName) {
        
        if (firstName.trim().equals("")) {
            throw new IllegalArgumentException("Please put a first name!");
        }
        this.firstName = firstName;
        
        if (middleName == null) {
            this.middleName = "";
        } else {
            this.middleName = middleName;
        }        
        if (lastName.trim().equals("")) {
            throw new IllegalArgumentException("Please put a last name!");
        }
        this.lastName = lastName;
        
    }

    /**
     * Accessor method to get the first name of person.
     * @return the firstName
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * Accessor method to get the middle name of person.
     * @return the middleName
     */
    public String getMiddleName() {
        return middleName;
    }

    /**
     * Accessor method to get the last name of person. 
     * @return the lastName
     */
    public String getLastName() {
        return lastName;
    }
    
    /**
     * Compares different Name objects from last name, then middle
     * name, then last name.
     * @return integer of the result of comparing each Name
     */
    @Override
    public int compareTo(Name o) {
        
        if (!this.lastName.equals(o.lastName)) {
            return this.lastName.compareTo(o.lastName);
        } else if (!this.middleName.equals(o.middleName)) {
            return this.middleName.compareTo(o.middleName);
        } else if (!this.firstName.equals(o.firstName)) {
            return this.firstName.compareTo(o.firstName);
        } else {
            return 0;
        }
}
}