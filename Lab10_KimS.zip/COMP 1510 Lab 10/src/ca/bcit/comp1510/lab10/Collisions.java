package ca.bcit.comp1510.lab10;

/**
 * This next program will simulate two particles in a space and how many times 
 * they collide, i.e., occupy the same coordinates. 
 * The goal of the program is to determine and report the number of collisions.
 *
 * @author eric kim
 * @version 1.0
 */
public class Collisions {

    /**
     * Creates two RandomWalker objects and simulates they are moving and 
     * colliding.
     * @param args unused
     */
    public static void main(String[] args) {
        final int firstXCoordinate = -3;
        final int firstYcoordinate = 0;
        final int secondXCoordinat = 3;
        final int secondYcoordinate = 0;
        final int boundary = 2000000;
        final int maxSteps = 100000;
        RandomWalker particle1 = new RandomWalker(firstXCoordinate,
                firstYcoordinate, maxSteps, boundary);
        RandomWalker particle2 = new RandomWalker(secondXCoordinat,
                secondYcoordinate, maxSteps, boundary);
        
        int numCollisions = 0;
        for (int i = 1; i <= maxSteps; i++) {
            particle1.takeStep();
            particle2.takeStep();
            if (samePosition(particle1, particle2)) {
                numCollisions++;
            }
        }
        
        System.out.println("Collisions:" + numCollisions);
        
        //6.The farthest distance a particle gets with these settings is 100003.
        
    }
    
    /**
     * Checks if the two particles have collided, in the same position.
     * @param randomW1
     *            first RandomWalker
     * @param randomW2
     *            second RandomWalker
     * @return boolean if they have collided or not.
     */
    public static boolean samePosition(RandomWalker randomW1, 
                                       RandomWalker randomW2) {
        return randomW1.getCurrentX() == randomW2.getCurrentX() 
                && randomW1.getCurrentY() == randomW2.getCurrentY();
    }

}
