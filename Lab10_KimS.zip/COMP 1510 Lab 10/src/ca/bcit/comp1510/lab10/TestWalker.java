package ca.bcit.comp1510.lab10;
import java.util.Scanner;

/**
 * Driver class for the RandomWalker class.
 *
 * @author eric kim
 * @version 1.0
 */
public class TestWalker {

    /**
     * Creates one new RandomWalker object and uses the randomwalker class
     * to drive its functionality as stated in lab 10 question.
     * @param args unused
     */
    public static void main(String[] args) {
        final int firstMaxSteps = 10;
        final int firstBoundarySize = 5;
        RandomWalker firstRandomWalker = 
                new RandomWalker(firstMaxSteps, firstBoundarySize);
        
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter the maximum steps:");
        
        int secondMaxSteps = scan.nextInt();
        System.out.println("Enter the max boundary size:");
        int secondBoundarySize = scan.nextInt();
        
        RandomWalker secondRandomWalker = 
                new RandomWalker(secondMaxSteps, secondBoundarySize);
        
        System.out.println("Let's go on a walk:");
        System.out.println("First Robot:\n" + firstRandomWalker.toString());
        System.out.println("Second Robot:\n" + secondRandomWalker.toString());
        System.out.println("Movements:");
        final int times = 5;
        for (int i = 1; i <= times; i++) {
            firstRandomWalker.takeStep();
            secondRandomWalker.takeStep();
            System.out.println("First Robot's maximum distance:" 
            + firstRandomWalker.getMaximumDistance());
            System.out.println("Second Robot's maximum distance:" 
            + secondRandomWalker.getMaximumDistance());
        }
        
        System.out.println("After walking:");
        System.out.println("First Robot:\n" + firstRandomWalker.toString());
        System.out.println("Second Robot:\n" + secondRandomWalker.toString());
        
        final int thirdMaximumSteps = 200;
        final int thirdBoundarySize = 10;
        RandomWalker thirdRandomWalker = 
                new RandomWalker(thirdMaximumSteps, thirdBoundarySize);
        System.out.println("Third Robot:");
        System.out.println("Before walking:\n" + thirdRandomWalker.toString());
        thirdRandomWalker.walk();
        System.out.println("After walking:\n" + thirdRandomWalker.toString());
        
        scan.close();

    }

}
