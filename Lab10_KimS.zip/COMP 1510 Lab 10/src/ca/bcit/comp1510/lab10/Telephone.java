package ca.bcit.comp1510.lab10;

import java.util.ArrayList;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 * A JavaFX program that displays the number pad for a phone.
 * 
 * @author eric kim
 * @version 1.0
 */
public class Telephone extends Application {
    
    /** String result for showing. */
    private String result = "";
    
    /** Label of the result. */
    private Label numberLabel = new Label(result);
    
    /** ArrayList for Buttons. */
    private ArrayList<Button> buttonList = new ArrayList<Button>();

    /**
     * JavaFX GUI with 12 buttons and
     * a label box which displays the button numbers pressed.
     * 
     * @param primaryStage
     *            a Stage
     */
    public void start(Stage primaryStage) {
        String allPadNumbers = "123456789*0#";
        String pushPadNumber;
        GridPane gridPane = new GridPane();
        gridPane.setAlignment(Pos.CENTER);
        VBox pane = new VBox(numberLabel, gridPane);
        pane.setAlignment(Pos.CENTER);
        
        final int buttonNumber = 12;
        final int buttonNumbersOnRow = 3;
        
        for (int i = 0; i < buttonNumber; i++) {
            pushPadNumber = allPadNumbers.substring(i, i + 1);
            buttonList.add(i, new Button(pushPadNumber));
            gridPane.add(buttonList.get(i), i % buttonNumbersOnRow,
                    i / buttonNumbersOnRow + 1);
            buttonList.get(i).setOnAction((e) -> {
                result = result + ((Button) e.getSource()).getText();
                numberLabel.setText(result);
            });
        }
                
        final int appWidth = 300;
        final int appHeight = 300;
        Scene scene = new Scene(pane, appWidth, appHeight);

        primaryStage.setTitle("Telephone");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * Launches the JavaFX application.
     * 
     * @param args unused
     *            
     */
    public static void main(String[] args) {
        launch(args);

    }

}