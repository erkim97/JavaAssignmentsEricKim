/**
 * 
 */
package ca.bcit.comp1510.lab10;

import java.util.ArrayList;

/**
 * Driver for the Name class to sort an ArrayList of Names.
 * @author erickim
 * @version 1.0
 */
public class NameDriver {

    /**
     * Creates four different names into an arraylist after creating 
     * a Name object for each. Sorts these using sort arraylist
     * method. 
     * @param args unused
     */
    public static void main(String[] args) {
        
        Name name1 = new Name("Fred", "Ed", "Rick");
        Name name2 = new Name("Bill", "Jobs", "Gates");
        Name name3 = new Name("Willy", null, "Wonka");
        Name name4 = new Name("Ned", "", "Bed");
        
        ArrayList<Name> namesList = new ArrayList<Name>();
        namesList.add(name1);
        namesList.add(name2);
        namesList.add(name3);
        namesList.add(name4);
        
        System.out.println("Before sorting: ");
        for (Name sorted : namesList) {
            System.out.println(sorted.getFirstName() 
                    + " " + sorted.getMiddleName() + " " 
                    + sorted.getLastName());
        }
        
        namesList.sort(null);
        System.out.println("\nAfter sorting: ");
        for (Name sorted : namesList) {
            System.out.println(sorted.getFirstName() 
                    + " " + sorted.getMiddleName()
                    + " " + sorted.getLastName());
}

    }

}
