package A1b;

/**
 * Enumerated type to determine  type of arithmetic table.
 * 
 * @author Eric Kim
 */
enum TableType  
{
    ADD, MULT
};