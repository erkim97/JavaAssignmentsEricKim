package A1b;

/**
 * The driver program. Displays the specified arithmetic table with
 * the specified start/stop values.
 * 
 * @author Eric Kim
 */

public class Main
{
    /**
     * Disallow the creation of any Main objects.
     */
    private Main()
    {
    }
    /**
     * The entry point to the program.
     * 
     * @param argv command line args.
     * arg[0] - the type (+ or *)
     * arg[1] - the type (>1 && < 100)
     * arg[2] - the type (>1 && < 100)
     */
    public static void main(final String[] argv)
    {
        final TableType type;
        final int       start;
        final int       stop;
        final Table table;
        
        if(argv.length != 3)
        {
            usage();
        }

        type  = getType(argv[0]);
        start = getNumber(argv[1]);
        stop  = getNumber(argv[2]);
        table = getTable(type, start, stop);
        table.display();
    }
    
    public static TableType getType(final String str)
    {
        final TableType type;
        
        if(str.equals("+"))
        {
            type = TableType.ADD;
        }
        else if(str.equals("*"))            
        {
            type = TableType.MULT;
        }
        else
        {
            usage();
            type = null;
        }
        
        return (type);
    }
    
    /**
     * Convert the supplied string into an int
     * If the string is not a valid int then exit the program.
     * To be valid the string must be an integer and be >0 and <100.
     * 
     * @param str the string to convert
     * @return the converted number
     */
    
    public static int getNumber(final String str)
    {
        int val;
        
        try
        {
            val = Integer.parseInt(str);
            
            if(val < 1 || val > 100)
            {
                usage();
            }
        }
        catch(NumberFormatException ex)
        {
            usage();
            val = 0;
        }
        
        return (val);
    }
    public static Table getTable(final TableType type,
                               final int start,
                               final int stop)
    {
        Table table = null;
        // if TableType is ADD, create and display addiction table
        if (type == TableType.ADD)
        {
            table = new AdditionTable(start, stop);
            table.createTable();
        }
        // if TableType is MULT, create and display multiplication table
        else
        {
            table = new MultiplicationTable(start, stop);
            table.createTable();
        }
       
        return table;
    }    
    
    public static void usage()
    {
        System.err.println("Usage: Main <type> <start> <stop>");
        System.err.println("\tWhere <type> is one of +, \"*\"");
        System.err.println("\tand <start> is between 1 and 100");
        System.err.println("\tand <stop> is between 1 and 100");
        System.err.println("\tand start < stop");
        System.exit(1);
    }            
}