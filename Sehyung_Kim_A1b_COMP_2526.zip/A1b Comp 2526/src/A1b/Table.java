package A1b;

/**
 * Class Table acts as a parent class to allow subclasses to extend from it.
 * 
 * @author Eric Kim
 */

public class Table {
        
    /** 2D array for multiplication table */
    protected float[][] table;     
    
    /** Stores array size */
    protected int arraySize;
    
    /** Stores tables start value */
    protected int start;
    
    /** Stores tables end value */
    protected int stop;
    
    /**
     * Non-default constructor.
     * 
     * @param start tables starting value
     * @param stop  tables ending value
     * @param t     tables arithmetic operator
     */
    protected Table(final int start, final int stop)
    {
        this.start = start;
        this.stop = stop;
        this.table = new float[arraySize][arraySize];
    }
    
    /**
     * Undefined method to create table.
     */
    protected void createTable()
    {
        
    }
    
    /**
     * Undefined method to display table.
     */
    protected void display()
    {
        
    }
}