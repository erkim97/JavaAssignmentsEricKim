package A1b;

/**
 * Class MultiplicationTable extends from class Table and 
 * represents a multiplication table.
 * 
 * @author Eric Kim
 */

public class MultiplicationTable extends Table {
 
     /**
     * Non-default constructor.
     * 
     * @param start tables starting value
     * @param stop  tables ending value
     */
    public MultiplicationTable(int start, int stop)
    {
        // calls parent constructor
        super(start, stop - start + 1);
        this.stop = stop;
    }
    
    /**
     * Method to create table.
     */
    public void createTable()
    {
        arraySize = stop - start + 1;               
        table = new float[arraySize][arraySize];    
        
        // creates multiplication table
        for (int row = 0; row < table.length; row++)
                    for (int col = 0; col < table.length; col++)
                        table[row][col] = (row + start) * (col + start);
    }
    
    /**
     * Method to display table.
     */
    public void display()
    {
        String operator = "*";
        String s = "-----";
        System.out.printf("\n");
        
        System.out.printf("%4s", operator);

        // prints header numbers
        System.out.printf("  ");
        for (int i = 0; i < table.length; i++)
            System.out.printf("%4d", (i + start));

        // prints operator
        System.out.printf("\n");

        // prints underline under header numbers
        System.out.printf("  ");
        for (int i = 0; i <= table.length; i++)
            System.out.printf("%4s", s);

        System.out.printf("\n");

        // prints side column numbers and elements of 2D array
        for (int row = 0; row < table.length; row++)
        {
            System.out.printf("%4d |", row + start);
            for (int col = 0; col < table.length; col++)
                System.out.printf("%4.0f", table[row][col]);
            
            System.out.printf("\n");
        }
    }
}