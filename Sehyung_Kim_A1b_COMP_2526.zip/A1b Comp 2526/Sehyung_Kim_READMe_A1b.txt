-Eric (Sehyung) Kim, A01089966, COMP 2526 A1a README file

The program will make use of the System.out.printf() method to allow formatted output.

The program contains TWO methods with the following name and signature:

1. public void createTable(int begin, int finish, TableType tableType)

2. public void printTable()

An additional method to check on arguments passed in to main is used, called argumentCheck()). This method will return true if the arguments passed in are valid and will set the data members: start, end and tableType.

There is no constructor, nor any other method (including overloaded methods).

The class will contain a data member (handle) for the table (a 2D array of type float), start and end (ints) for the start and end values of the table, and tableType (TableType) an enumerated type consisting of {MULT, ADD}.

With a spacing of 5 between numbers in the table when printing 

Enumerated type “TableType”  is declared a private member.

The class is called ArithmeticTable

When executed, the program takes in the start, end and table type (‘*’ or ‘+’). Default is ‘*’ and default size is start=1, end=10. 
If out of parameters, type of bounds set will show up as error message.