/**
 * 
 */
package ca.bcit.comp1510.lab9;

import java.io.IOException;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.stage.Stage;
import javafx.geometry.Pos;
import javafx.geometry.HPos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;

/**
 * Password Validator. Checks to see if input in both textfields are equal or
 * not.
 * 
 * @author Eric Kim
 * @version 1.0
 *
 */
public class PasswordValidator extends Application {
    /**
     * Textfield for first input box.
     */
    private TextField tfCheck = new TextField();

    /**
     * Textfield for second input box.
     */
    private TextField tfPassword = new TextField();

    /**
     * Submit button to compare both inputs from txtfields.
     */
    private Button btSubmit = new Button("Submit");

    /**
     * Label which displays if valid or not for comparing inputs.
     */
    private Label lbValid = new Label();

    /** List of ForbiddenWords variable. */
    private ForbiddenWords wordList;

    /**
     * Presents a GUI containing a two textfields and a submit button to display
     * if both texts are same or not.
     * 
     * @param primaryStage a Stage
     * @throws IOException If issue
     */
    public void start(Stage primaryStage) throws IOException {

        wordList = new ForbiddenWords("src/ca/bcit/comp1510/lab9/wordlist.txt");

        GridPane gridPane = new GridPane();
        gridPane.setHgap(5);
        gridPane.setVgap(5);
        gridPane.add(new Label("Enter Password:"), 0, 0);
        gridPane.add(tfCheck, 1, 0);
        gridPane.add(new Label("Confirm Password:"), 0, 1);
        gridPane.add(tfPassword, 1, 1);
        gridPane.add(btSubmit, 0, 2);
        gridPane.add(lbValid, 1, 2);

        gridPane.setAlignment(Pos.CENTER);
        tfCheck.setAlignment(Pos.BOTTOM_LEFT);
        tfPassword.setAlignment(Pos.BOTTOM_LEFT);

        GridPane.setHalignment(btSubmit, HPos.LEFT);

        // Validation Event
        btSubmit.setOnAction(e -> validatePassword(e));

        Scene scene = new Scene(gridPane, 300, 150);
        primaryStage.setTitle("Password Validator");
        primaryStage.setScene(scene);
        primaryStage.show();

    }

    /**
     * Method to check if password contains at least one upper-case.
     * 
     * @param check invokes this method
     * @return If password is valid or not
     */
    private boolean oneUpperCase(String check) {

        boolean valid = !check.equals(check.toLowerCase());
        return valid;
    }

    /**
     * Method to check if password contains at least one lower-case.
     * 
     * @param check invokes this method
     * @return If password is valid or not
     */
    private boolean oneLowerCase(String check) {

        boolean valid = !check.equals(check.toUpperCase());
        return valid;
    }

    /**
     * Method to check if password contains at least one number.
     * 
     * @param check invokes this method
     * @return If password is valid or not
     */
    private boolean oneNumber(String check) {

        for (int i = 0; i < check.length(); i++) {

            char ch = check.charAt(i);
            if (Character.isDigit(ch)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Method to check if password contains at least one special character.
     * 
     * @param check invokes this method.
     * @return If password is valid or not
     */
    private boolean oneSpecial(String check) {

        for (int i = 0; i < check.length(); i++) {

            char ch = check.charAt(i);

            if (!Character.isDigit(ch) && !Character.isLetter(ch)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Method to check if password is 8 to 10 characters long.
     * 
     * @param check invokes this method
     * @return whether password is valid or not.
     */
    private boolean minMax(String check) {

        final int eight = 8;
        final int ten = 10;

        if ((check.length() >= eight) && (check.length() <= ten)) {
            return true;
        }
        return false;
    }

    /**
     * Returns Valid if passwords entered is the same, otherwise not.
     * 
     * @param event invokes this method.
     * @throws IOException
     */
    public void validatePassword(ActionEvent event) {

        String password = tfCheck.getText();

        if (password.length() == 0) {
            lbValid.setText("INVALID");
        } else if (password.equals(tfPassword.getText()) 
                && (oneUpperCase(password)) 
                && (oneLowerCase(password)) 
                && (oneNumber(password))
                && (oneSpecial(password)) 
                && (minMax(password)) 
                && (!wordList.containsWord(password))) {
            lbValid.setText("VALID");
        } else {
            lbValid.setText("INVALID");
        }
    }

    /**
     * Drives the program.
     * 
     * @param args unused
     */
    public static void main(String[] args) {
        launch(args);
    }

}
