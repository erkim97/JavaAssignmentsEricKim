/**
 * 
 */
package ca.bcit.comp1510.lab9;
import java.util.Random;
/**
 * Driver for the cat and cathotel, generators random cat objects with ages.
 * @author Eric Kim
 * @version 1.0
 *
 */
public class CatDriver {
    
    /**
     * Drives the program.
     * @param args unused
     */
    public static void main(String[] args) {
        /**
         * Integer max age of the cat 0-99 random generator.
         */
        final int maxAge = 100;
        
        /**
         * Integer age limit of the cats to be removed if older.
         */
        final int ageLimit = 60;
        
        Random generator = new Random();
        
        Cat cat1 = new Cat("CatOne", generator.nextInt(maxAge));
        Cat cat2 = new Cat("CatTwo", generator.nextInt(maxAge));
        Cat cat3 = new Cat("CatThree", generator.nextInt(maxAge));
        Cat cat4 = new Cat("CatFour", generator.nextInt(maxAge));
        Cat cat5 = new Cat("", generator.nextInt(maxAge));

        CatHotel meowHotel = new CatHotel("MeowHotel");
        meowHotel.addCat(cat1);
        meowHotel.addCat(cat2);
        meowHotel.addCat(cat3);
        meowHotel.addCat(cat4);
        meowHotel.addCat(cat5);
        
        meowHotel.printGuestList();
        //List Guest List Size
        System.out.println("Cat count: " + meowHotel.guestCount());
        //Removing cats over age limit
        System.out.println("Cats to be removed: " 
                        + meowHotel.removeOldGuests(ageLimit));
        
        System.out.println("\n**List of Cats After Removal of "
                            + "Cats over 60 Yrs Old**");
        meowHotel.printGuestList();
        
        System.out.println("Cat count: " + meowHotel.guestCount());
    }

}
