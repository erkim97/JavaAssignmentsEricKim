/**
 * 
 */
package ca.bcit.comp1510.lab9;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * CatHotel with methods to add, remove, and count cat objects in an arraylist, 
 * display hotel name and cats inside.
 * @author Eric Kim
 * @version 1.0
 */
public class CatHotel {
    /**
     * ArrayList for cats.
     */
    private final List<Cat> cats;
    /**
     * String which contains hotel name.
     */
    private String hotelName;
    
    /**
     * Constructor for CatHotel with arraylist and hotelname.
     * @param hotelName String hotel name
     */
    public CatHotel(String hotelName) {
        this.cats = new ArrayList<Cat>();
        this.hotelName = hotelName;
    }
    
    /**
     * Method to add a cat name to cats arraylist.
     * @param name invokes this method
     */
    public void addCat(Cat name) {
        cats.add(name);
    }
     
    /**
     * Method to removal all cat names from cats arraylist.
     */
    public void removeAllGuests() {
        cats.clear();
    }
    
    /**
     * Method to count number of objects inside cats arraylist.
     * @return the number of objects inside cats arraylist
     */
    public int guestCount() {
        int numberOfGuests = cats.size();
        return numberOfGuests;
    }
    
    /**
     * Method to remove all cats over specified age.
     * @param catAge invokes this method
     * @return number of removed cat objects from cats arraylist
     */
    public int removeOldGuests(int catAge) {
        Iterator<Cat> catIterator = cats.iterator();
        int removedCats = 0;
        while (catIterator.hasNext()) {
            Cat temp = catIterator.next();
            if (temp.getCatAge() > catAge) {
                catIterator.remove();
                removedCats++;
            }
        }
        
        return removedCats;
        
    }
    
    /**
     * Method to print hotel name and all cats currently inside.
     */
    public void printGuestList() {
        System.out.println(hotelName + "\n");
       
        for (int i = 0; i < cats.size(); i++) {
            System.out.println(cats.get(i) + "\n");
        }
                
    }
    
}
