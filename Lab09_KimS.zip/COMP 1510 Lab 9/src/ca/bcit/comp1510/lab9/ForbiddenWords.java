package ca.bcit.comp1510.lab9;

import java.util.Scanner;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

/**
 * Scan words in a text file and adds them to an array list.
 * 
 * @author Eric Kim
 * @version 1.0
 *
 */
public class ForbiddenWords {
        
    /** 
     * ArrayList for forbidden strings.
     */
    private ArrayList<String> forbidden;
    
    /** 
     * File scanner. 
     */
    private Scanner scan;
    
    /**
     * Method for adding words in text file to array list.
     * @param fileName name of the file.
     * @throws IOException thrown
     */
    public ForbiddenWords(String fileName) throws IOException {
        
        forbidden = new ArrayList<String>();
        
        scan = new Scanner(new File(fileName));
        
        while (scan.hasNext()) {
            forbidden.add(scan.nextLine());
        }
        scan.close();   
    }

    /**
     * Drives the program.
     * @param check string
     * @return true or false
     */
    public boolean containsWord(String check) {
        
        for (int i = 0; i < forbidden.size(); i++) {
            if (check.contains(forbidden.get(i))) {
                return true;
            }
        } 
        return false;
    }

}
