/**
 * 
 */
package ca.bcit.comp1510.lab9;

/**
 * Returns cat names and ages; includes a toString method.
 * @author Eric Kim
 * @version 1.0
 */
public class Cat {
    /**
     * String for a cat's name.
     */
    private String catName;
    /**
     * Integer for a cat's age.
     */
    private int catAge;

    /**
     * Constructor with cat's name and age. If blank cat's
     * name = Cleo.
     * @param catName cat's name
     * @param catAge cat's age
     */
    public Cat(String catName, int catAge) {
        if (catName.length() == 0) {
            this.catName = "Cleo";
        } else {
            this.catName = catName;
        }

        if (catAge < 0) {
            catAge = 0;
        } else {
            this.catAge = catAge;
        }
    }

    /**
     * Accessor for getting the cat name.
     * @return the catName
     */
    public String getCatName() {
        return catName;
    }

    /**
     * Accessor for getting the cat age.
     * @return the catAge
     */
    public int getCatAge() {
        return catAge;
    }

    /**
     * Mutator for setting the cat age.
     * @param catAge the catAge to set
     */
    public void setCatAge(int catAge) {
        this.catAge = catAge;
    }

    /**
     * toString method of Cat.java to return a string.
     * @return returns string concatenation of name and age of cat.
     */
    public String toString() {
        return "Cat [catName=" + catName + ", catAge=" + catAge + "]";
    }

}
