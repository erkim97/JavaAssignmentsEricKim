package ca.bcit.comp1510.lab9;

/**
 * Driver for the coin class, flips the coin 100 times and determines longest
 * heads streak.
 * 
 * @author Eric Kim
 * @version 1.0
 */
public class CoinRunner {
    /**
     * Number of coin flips.
     */
    private static final int FLIPS = 100;

    /**
     * Creates a Coin object, flips it, and prints the result.
     * 
     * @param args command line arguments (unused)
     */
    public static void main(String[] args) {
        Coin myCoin = new Coin();
        int streak = 0;
        int maxHeadStreak = 0;

        for (int i = 0; i < FLIPS; i++) {
            myCoin.flip();

            if (!myCoin.isHeads()) {
                streak = 0;
            } else {
                streak++;
                maxHeadStreak = Math.max(streak, maxHeadStreak);
            }

            System.out.println(myCoin);
        }

        System.out.println("The longest run of heads was: " + maxHeadStreak);
    }
}
