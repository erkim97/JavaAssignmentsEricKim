import java.util.ArrayList;

/**
 * Plant class that resides inside a Cell.
 * @author erickim
 * @version 1.0
 */
public class Plant extends Entity {
    private static ArrayList<Plant> plantArray = new ArrayList<Plant>();
    private static int totalPlants;
    private boolean justSeeded = true;
    
    /**
     * Constructor for Plant class.
     * @param cell
     */
    public Plant(Cell cell) {
        super(cell);
        setEntity(EntityType.PLANT);
        totalPlants++;
    }
    
    /**
     * Inits the Plant object.
     */
    public Plant init() {
        plantArray.add(this);
        this.justSeeded = false;
        return this;
    }
    
    /**
     * Method boolean to check if plant newly reproduced.
     * @return justSeeded boolean
     */
    public boolean justSeeded() {
        return this.justSeeded;
    }
    
    /**
     * Method to get all Plants from array list.
     * @return plantArray
     */
    public static Plant[] getAllPlants() {
        return plantArray.toArray(new Plant[plantArray.size()]);
    }
    
    /**
     * Method to remove Plant from Plant array list.
     */
    public void removeFromAllPlants() {
        plantArray.remove(this);
        totalPlants--;
    }
        
    /**
     * Returns the total amount of Plants.
     * @return total amount of Plants.
     */
    public static int getTotalNum() {
        return totalPlants;
    }
}