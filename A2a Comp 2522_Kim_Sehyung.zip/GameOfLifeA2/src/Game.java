
import java.awt.GridLayout;
import javax.swing.JFrame;

/**
 * Game class that intializes JFrame gameframe
 * @author erickim
 * @version 1.0
 */
@SuppressWarnings("serial")
public class Game extends JFrame {
    
    private final World world;


    /**
     * Constructor Game class, two way communication with World.
     * @param w the world this GameFrame is referencing.
     */
    public Game(final World w) {
        world = w;
    }
    
    /**
     * Method to initialize Game.
     */
    public void init() {
        setTitle("Assignment 2a Game of Life");
        setLayout(new GridLayout(world.getRowCount(), world.getColumnCount()));

        for (int row = 0; row < world.getRowCount(); row++) {
            for (int col = 0; col < world.getColumnCount(); col++) {
                add(world.getCell(row, col));
            }
        }
        addMouseListener(new TurnListener(this));
    }
    
    /**
     * Method responding to MouseListener click, world takes a turn and repaints JFrame.
     */
    public void takeTurn() {
        world.takeTurn();
        repaint();
    }
}