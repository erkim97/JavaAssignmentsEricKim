import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 * Mouse click event to make game take a turn
 * @author erickim
 * @version 1.0
 */
public class TurnListener extends MouseAdapter {
    
    private final Game game;
    /**
     * Constructor for TurnListener class.
     * @param gf
     */
    public TurnListener(Game gf) {
        game = gf;
    }
    
    /**
     * Method MouseEvent e to make game take a turn.
     * @param e a MouseEvent
     */
    public void mouseClicked(MouseEvent e) {
        game.takeTurn();       
    }
}