import java.util.ArrayList;

/**
 * World class which contains cells, and controls take turn.
 * @author erickim
 * @version 1.0
 */
public class World {
    private final int rows;
    private final int columns;
    private Cell[][] cells;
    
    /**
     * Constructor for World class.
     * Holds Cells
     * @param rows
     * @param cols
     * 
     */
    public World(int rows, int cols) {
        super();
        this.rows = rows;
        this.columns = cols;
        this.cells = new Cell[rows][cols];
    }
    
    /**
     * Method init() to create and puts cells into the world,
     * newCell.init() calls Cell init() method to initialize herb/plants
     */
    public void init() {
        for (int row = 0; row < this.rows; row++) {
            for (int col = 0; col < this.columns; col++) {
                Cell cell = new Cell(this, row, col);
                cell.init();
                this.cells[row][col] = cell;
            }
        }
    }
    
    /**
     * Cell getCell method
     * @param col
     * @param row
     * @return cells
     */
    public Cell getCell(int row, int col) {
        return this.cells[row][col];
    }
    
    /**
     * Method to get Cells from Cells array
     * @return cells
     */
    public Cell[][] getCells() {
        return this.cells;
    }
    
    /**
     * Method to get row count.
     * @return rows
     */
    public int getRowCount() {
        return this.rows;
    }
    
    /**
     * Method to get column count.
     * @return columns
     */
    public int getColumnCount() {
        return this.columns;
    }
    
    /**
     * Method to take a turn, super methods with World object.
     **/
    public void takeTurn() {
        plantSeeds();
        removeDeadHerbivores();        
        herbivoreTakeTurn();
    }
    
    /**
     * Method to check plant reproduction.
     */
    private void plantSeeds() {
        ArrayList<Plant> newPlants = new ArrayList<Plant>();
        
        Plant[] plants = Plant.getAllPlants();
        for (Plant plant : plants) {
            //if plant boolean justSeeded is false
            if (!plant.justSeeded()) {
                Cell plantCell = plant.getEntityCell();
                //get seed cells method in Cell, using getAdjacent cells of radius 1.
                Cell[] seedCell = plantCell.getSeedCells(plantCell.getAdjacentCells(1));
                if (seedCell != null) {
                    plantCell = seedCell[RandomGenerator.nextNumber(seedCell.length)];
                    plantCell.seedCell();
                    newPlants.add(plantCell.getPlant());
                }
            }
        }
        
        for (Plant p : newPlants) {
            if (p != null) {
                p.init();
            }
        }
    }
    
    
    /**
     * Method to remove dead herbivores from cell.
     */
    public void removeDeadHerbivores() {
        Herbivore[] herbs = Herbivore.getAllHerbivores();
        for (Herbivore h: herbs) {
            if (h.isDead()) {
                h.getEntityCell().removeHerbivore();
                h.removeFromAllHerbs();
            }
        }
    }
    
    /**
     * Method to make herbivores take 1 step turn, if landing on plant eat it.
     */
    private void herbivoreTakeTurn() {
        Herbivore[] herbs = Herbivore.getAllHerbivores();
        for (Herbivore h : herbs) {
            if (!h.haveMoved()) {
                h.move();
                h.eatPlant();
            }
            h.minusHealth();
        }
        for (Herbivore h : herbs) {
            h.setMoved(false);
        }
    }
    

}