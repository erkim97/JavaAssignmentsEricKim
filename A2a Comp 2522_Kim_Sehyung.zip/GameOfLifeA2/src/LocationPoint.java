/**
 * Class locationpoint to set and get x and y coord. of 2D array list
 * @author erickim
 * @version 1.0
 */
public class LocationPoint {
    private int row;
    private int col;
    
    /**
     * Constructor for LocationPoint class
     * @param row  
     * @param col
     */
    public LocationPoint(int row, int col) {
        this.row = row;
        this.col = col;
    }
    
    /**
     * Setter the set the point at row and col.
     * @param row
     * @param col 
     */
    public void setPoint(int row, int col) {
        this.row = row;
        this.col = col;
    }
    
    /**
     * Getter to get the row.
     * @return row int
     */
    public int getRow() {
        return this.row;
    }
    
    /**
     * Getter to get the column.
     * @return  col int
     */
    public int getCol() {
        return this.col;
    }
}