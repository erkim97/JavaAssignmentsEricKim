import java.util.ArrayList;

/**
 * Creates an Entity of type Herbivore.
 * @author erickim
 * @version 1.0
 */
public class Herbivore extends Entity {
    private static ArrayList<Herbivore> herbivoreArray = new ArrayList<Herbivore>();
    private static int totalHerbivores;
    private static final int MAX_HEALTH = 5;
    private int health;
    private boolean moved;


    /**
     * Constructor for Herbivore Class, inside a cell.
     * @param cell
     */
    public Herbivore(Cell cell) {
        super(cell);
        setEntity(EntityType.HERBIVORE);
        totalHerbivores++;
    }
    
    /**
     * Method to initialize Herbivore with 5 health.
     */
    public void init() {
        this.health = MAX_HEALTH;
        herbivoreArray.add(this);
        this.moved = false;
    }
    
    /**
     * Method to eat plant if herbivore is on a Cell that contains a plant entity.
     */
    public void eatPlant() {
        Cell cell = this.getEntityCell();
        Plant p = cell.getPlant();
        if (p != null) {
            cell.removePlant();
            p.removeFromAllPlants();
            resetHealth();
        }
    }

    /**
     * Method to decrease health of Herbivore by 1, every turn it takes.
     */
    public void minusHealth() {
        this.health -= 1;
    }

    /**
     * Method to reset the health of Herbivore back to 5, once eaten plant.
     */
    public void resetHealth() {
        this.health = MAX_HEALTH;
    }

    /**
     * Static method to get all Herbivores.
     * @return an array of Herbivores
     */
    public static Herbivore[] getAllHerbivores() {
        return herbivoreArray.toArray(new Herbivore[herbivoreArray.size()]);
    }

    /**
     * Method to remove Herbivore from Herbivore array list.
     */
    public void removeFromAllHerbs() {
        herbivoreArray.remove(this);
        totalHerbivores--;
    }
    
    /**
     * Method boolean to check if Herbivore moved this turn.
     * @return moved boolean
     */
    public boolean haveMoved() {
        return this.moved;
    }
    
    /**
     * Method to set the Herbivore moved status.
     * @param moved to boolean b true/false if moved.
     */
    public void setMoved(boolean b) {
        this.moved = b;
    }
    
    /**
     * Method boolean to check if Herbivore is dead this turn, health == 0.
     * @return boolean true/false
     */
    public boolean isDead() {
        if (this.health == 0) {
            return true;
        }
        return false;
    };
    
    /**
     * Method move for Cell Herbivore.move(), checks if there is adjacent Herbivore and avoids.
     * @return newCell the Herbivore moves into
     */
    public Cell move() {
        Cell[] adjCells = this.getEntityCell().getAdjacentCells(1);
        Cell[] validCells = new Cell[adjCells.length];
        Cell newCell = null;
        int validCellsIndex = 0;
        
        for (Cell cell : adjCells) {
            if (cell == null) {
                break;
            }
            //make sure not moving to another herbivore index
            if (cell.getHerbivore() != null) {
                continue;
            } else {
                validCells[validCellsIndex] = cell;
                validCellsIndex++;
            }
        }
        
        if (validCellsIndex > 0) {
            if (validCellsIndex == 1) {
                newCell = validCells[0];
            } else {
                newCell = validCells[RandomGenerator.nextNumber(validCellsIndex)];
            }
            
            super.move(getEntityCell(), newCell);
            setMoved(true);
        }
        return newCell;
    }
    
    
    /**
     * Returns the total amount of alive herbivores.
     * @return total number of alive Herbivores.
     */
    public static int countTotalAlive() {
        return totalHerbivores;
    }
}