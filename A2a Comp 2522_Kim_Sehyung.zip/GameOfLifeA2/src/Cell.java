import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

import javax.swing.JPanel;

/**
 * Cell class.
 * 
 * @author erickim
 * @version 1.0
 */

@SuppressWarnings("serial")
public class Cell extends JPanel {
    private static final int HERB_RATIO = 85;
    private static final int PLANT_RATIO = 65;
    private static final int MIN_PLANT = 4;
    private static final int MIN_EMPTY = 3;
    private ArrayList<Entity> entities = new ArrayList<Entity>();
    private final World world;
    private final LocationPoint locationPoint;

    /**
     * Constructor for Cell class, cells in a world, located at yrow, xcolumn.
     * 
     * @param world
     * @param row
     * @param column
     */
    public Cell(World world, int row, int column) {
        super();
        this.world = world;
        this.locationPoint = new LocationPoint(row, column);
    }

    /**
     * Sets up the cell to have randomly a plant or herbivore.
     */
    public void init() {
        Random generator = new Random();
        int random = generator.nextInt(100 + 1) +1;
        
        if (random >= HERB_RATIO) {
            Herbivore newHerbivore = new Herbivore(this);
            newHerbivore.init();
            entities.add(newHerbivore);
        } else if (random >= PLANT_RATIO) {
            Plant newPlant = new Plant(this);
            newPlant.init();
            entities.add(newPlant);
        }

    }

    /**
     * Colors the entity based on what entity type it is.
     * @param g
     */
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (entityEmpty(entities)) {
            g.setColor(Color.WHITE);
        } else if (this.getHerbivore() != null) {
            g.setColor(Color.YELLOW);
        } else {
            g.setColor(Color.GREEN);
        }

        //fill in the rectangle with intx, inty, width, height
        g.fillRect(0, 0, getSize().width, getSize().height);
        g.setColor(Color.BLACK);
        g.drawRect(0, 0, getSize().width, getSize().height);
    }

    /**
     * Method to return the LocationPoint of cell.
     * 
     * @return locationPoint
     */
    public LocationPoint getLocationPoint() {
        return this.locationPoint;
    }

    /**
     * Grabs all the 8 cells around it. based on radius, so 1 radius = all cells 1 range away from it.
     * 
     * @return adjacentCells
     * @param radius
     */
    public Cell[] getAdjacentCells(int radius) {
        int index = 0;
        int totalAdjCells = (radius * 2 + 1) * (radius * 2 + 1) - 1;
        
        Cell[] adjacentCells = new Cell[totalAdjCells];
        int currRow = this.locationPoint.getRow();
        int currCol = this.locationPoint.getCol();
        for (int i = currRow - radius; i <= currRow + radius; i++) {
            if (i < 0 || i >= world.getColumnCount()) {
                continue;
            }
            for (int j = currCol - radius; j <= currCol + radius; j++) {
                if (j < 0 || j >= world.getRowCount()) {
                    continue;
                }
                if (i == currRow && j == currCol) {
                    continue;
                }
                adjacentCells[index] = world.getCell(i, j);
                index++;
            }
        }
        return adjacentCells;
    }

    /**
     * Method to check if cells around plant is null or contains plant entity
     * @param cells
     * @return validSeedCells
     */
    public Cell[] getSeedCells(Cell[] cells) {
        Cell[] validCells = new Cell[cells.length];
        int adjEmpty = 0;
        int adjPlants = 0;
        int validSeedCellIndex = 0;

        for (Cell cell : cells) {
            if (cell == null) {
                break;
            }
            
            //Get plant entity in cell
            Plant p = cell.getPlant();
            if (entityEmpty(cell.entities)) {
                adjEmpty++;
                validCells[validSeedCellIndex] = cell;
                validSeedCellIndex++;
            } else if (p != null) {
                adjPlants++;
            }
        }
        // For adjacent empty cells and plant cells, if adjacent plants == 4 & null spaces >= 3, valid seed cell.
        if (adjEmpty >= MIN_EMPTY && adjPlants == MIN_PLANT 
                && validSeedCellIndex > 0) {
            Cell[] validSeedCells = new Cell[validSeedCellIndex];
            System.arraycopy(validCells, 0, validSeedCells, 0, validSeedCellIndex);
            
            return validSeedCells;
        }
        return null;
    }

    /**
     * Method to seed a plant entity into a cell(this).
     */
    public void seedCell() {
        Plant p = new Plant(this);
        this.insertEntity(p);
    }

    /**
     * Method boolean to check if entity array is null or not.
     * 
     * @param array
     * @return true
     */
    private boolean entityEmpty(ArrayList<Entity> eArray) {
        for (Entity en : eArray) {
            if (en != null) {
                return false;
            }
        }
        return true;
    }

    /**
     * Method to insert entity into entity array list.
     * 
     * @param en
     */
    public void insertEntity(Entity en) {
        this.entities.add(en);
    }

    /**
     * Method to get entity type for each entity in the array.
     * 
     * @param entityType
     * @return 
     */
    protected Entity getEntity(EntityType entityType) {
        Entity returnEntity = null;
        
        for (Entity en : entities) {
            if (en.getEntityType() == entityType) {
                returnEntity = en;
            }
        }
        return returnEntity;
    }
    
    /**
     * Method to remove entity from entity iterator list.
     * 
     * @param entityType
     */
    protected void removeEntity(EntityType entityType) {
        for (Iterator<Entity> iterator = entities.iterator(); 
                iterator.hasNext();) {
            Entity en = iterator.next();
            if (en.getEntityType() == entityType) {
                iterator.remove();
            }
        }
    }

    /**
     * Method to get plant entity types from entity array list.
     * @return Plant p, else null
     */
    public Plant getPlant() {
        Plant p = null;
        p = (Plant) getEntity(EntityType.PLANT);
        return p;
    }

    /**
     * Method to remove entity type plants from entity array list.
     */
    public void removePlant() {
        removeEntity(EntityType.PLANT);
    }
    
    /**
     * Method to get herbivore entity types from entity array list.
     * 
     * @return Herbivore h, else null
     */
    public Herbivore getHerbivore() {
        Herbivore h = null;
        h = (Herbivore) getEntity(EntityType.HERBIVORE);
        return h;
    }

    /**
     * Method to remove entity type herbivores from entity array list.
     */
    public void removeHerbivore() {
        removeEntity(EntityType.HERBIVORE);
    }


}