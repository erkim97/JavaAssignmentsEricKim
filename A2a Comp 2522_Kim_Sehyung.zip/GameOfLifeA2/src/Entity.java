/**
 * Class Entity with Lifeform entities that are placed within the Cell(s).
 * 
 * @author erickim
 * @version 1.0
 */
public class Entity {
    private Cell location;
    private EntityType entityType;
    
    /**
     * Constructor for Entity class.
     * @param cell
     */
    public Entity(Cell cell) {
        super();
        this.location = cell;
    }
    
    /**
     * Gets the EntityType of this Entity.
     * @return entityType
     */
    public EntityType getEntityType() {
        return entityType;
    }
    
    /**
     * Sets the entityType of this Entity.
     * @param set entityType to entityType
     */
    public void setEntity(EntityType entityType) {
        this.entityType = entityType;
    }
    
    /**
     * Gets the Cell location where Entity is.
     * @return location
     */
    public Cell getEntityCell() {
        return location;
    }
    
    /**
     * Sets the Cell location where Entity is.
     * @param set location to c
     */
    public void setLocation(Cell c) {
        location = c;
    }
    
    /**
    * Move method for entity.
    * @param oldC
    * @param newC
    */
    protected void move(Cell oldC, Cell newC) {
       oldC.removeEntity(entityType);
       this.setLocation(newC);
       newC.insertEntity(this);
    }

}