[Sehyung Kim], [A01089966], [C], [April 7th, 2019]

This assignment is [100]% complete.


------------------------
Question one (Statistics) status:

[complete]

------------------------
Question two (DrawStar) status:

[complete]

------------------------
Question three (TestMIXChar) status:

[complete]
