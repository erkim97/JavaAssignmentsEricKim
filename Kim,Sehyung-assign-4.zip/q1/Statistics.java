package q1;

import java.text.DecimalFormat;
import java.util.Scanner;

/**
 * <p>
 * Application that computes and prints the mean and standard deviation of list 
 * integers x1 through xn.  Assumes there will be no more than 50 input values
 * and that the values are valid integers. Reads the values into an array 
 * from System.in with no prompt, terminating when there is no more data
 * </p>
 *
 * @author sehyung kim
 * @version 1.0
 */
public class Statistics {
    /**
     * <p>This is the main method (entry point) that gets called by the JVM.</p>
     *
     * @param args cmd line arguments
     */
    public static void main(String[] args) {
        final int maxNumbers = 50;
        int[] numbers = new int[maxNumbers];
        int sumOfNumbers = 0;
        int numberCount = 0;
        
        System.out.println("Enter in data values:");
        Scanner scan1 = new Scanner(System.in);
        Scanner scan2 = new Scanner(scan1.nextLine());
        
        int i = 0;
        while (scan2.hasNext()) {
            numbers[i] = scan2.nextInt();
            sumOfNumbers += numbers[i];
            numberCount++;
            i++;
        }
        
        double mean = (double) sumOfNumbers / numberCount;
        
        
        double topOfSD = 0.0;
        for (int j = 0; j < numberCount; j++) {
            topOfSD += Math.pow((numbers[j] - mean), 2);
        }
        
        double sd; 
        if (numberCount == 1) {
            sd = 0.0;
        } else {
            sd = Math.sqrt(topOfSD / (numberCount - 1));
        }
        
        DecimalFormat df = new DecimalFormat("#.##");
        
        System.out.println("Mean= " + df.format(mean));
        System.out.println("Standard deviation= " + df.format(sd));
        
        scan1.close();
        scan2.close();
        
        System.out.println("Question one was called and ran sucessfully.");
    }

}