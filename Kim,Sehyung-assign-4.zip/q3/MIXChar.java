package q3;

/**
 * Creates a class of MIXChar to represent a single MIXChar 
 * character.
 * @author sehyung kim
 * @version 1.0
 */
public class MIXChar {

    /** integer max ordinal value. */
    private static final int MAX_ORDINAL = 56;

    /** delta mixCHAR value. */
    private static final char DELTA = '\u0394';

    /** sigma mixCHAR value. */
    private static final char SIGMA = '\u03A3';

    /** pi mixCHAR value. */
    private static final char PI = '\u03A0';

    /** List of all mixChar char values. */
    private static char[] mixCHAR = {' ', 'A', 'B', 'C', 'D', 'E', 'F', 'G',
            'H', 'I', DELTA, 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R',
            SIGMA, PI, 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '0',
            '1', '2', '3', '4', '5', '6', '7', '8', '9', '.', ',', '(', ')',
            '+', '-', '*', '/', '=', '$', '<', '>', '@', ';', ':', '\''};

    /** char value to store mixCharacter. */
    private char mixCharacter;

    /** 
     * Constructor converting c to the corresponding MIXChar, exceptions
     * when not possible.
     * @param c
     *          c as a character
     */
    public MIXChar(char c) {
        if (!isMIXChar(c)) {
            throw new IllegalArgumentException("Conversion is not possible.");
        }
        mixCharacter = c;
    }

    /** 
     *  Helper method to check if a character is a MIX character. 
     *  @return boolean if char c is equal to a MIXChar
     *  @param c
     *          c as a character
     */
    public static boolean isMIXChar(char c) {
        for (int i = 0; i < MAX_ORDINAL; i++) {
            if (c == mixCHAR[i]) {
                return true;
            }
        }
        return false;
    }

    /**
     * Method to convert MIXChar to Java Character. 
     * @return returns the stored mixCharacter char
     * 
     */
    public char toChar() {
        return mixCharacter;
    }

    /**
     * Method to give numerical value of the MIXChar.
     * @param ordinal
     *              integer ordinal
     * @return return MIXChar at an ordianl value
     */

    public static char atOrdinal(int ordinal) {
        return mixCHAR[ordinal];
    }

    /**
     * Method to returns String with characters corresponding to those 
     * of the input array.
     * @param mixArray
     *          array mixArray
     * @return a mixed character string with characters corresponding to array
     */
    public static String toString(MIXChar[] mixArray) {
        String mixedCharString = "";
        for (int i = 0; i < mixArray.length; i++) {
            mixedCharString += mixArray[i].toChar();
        }
        return mixedCharString;
    }

    /**      
     * Static method to return array of MIXChar characters corresponding to the 
     * chars in s. Throws exception if any if the string's characters do not 
     * correspond to MIXChar character.
     * @param s
     *          String s passed in
     * @return array of MIXChar characters according to the chars in String s.
     */
    public static MIXChar[] toMIXChar(String s) {
        MIXChar[] mixArray = new MIXChar[s.length()];
        for (int i = 0; i < s.length(); i++) {
            MIXChar newMIXChar = new MIXChar(s.charAt(i));
            mixArray[i] = newMIXChar;
        }
        return mixArray;
    }

    /**
     * Method to find numerical value of a MIXChar.
     * @return integer value of MIXChar
     */
    public int ordinal() {
        for (int i = 0; i < MAX_ORDINAL; i++) {
            if (mixCharacter == mixCHAR[i]) {
                return i;
            }
        }
        return mixCharacter;
    }

    /**
     * Method toString to return string containing MIXChar.
     * @return string containing this MIXChar as a Java char
     */
    public String toString() {
        return "" + mixCharacter;
    }
}