package q3;

/**
 * Class that contains a long[] and a count of how many characters 
 * are in the message object.  The message represents a packed string 
 * of MIXChar's.
 * @author sehyung kim
 * @version 1.0
 * 
 */
public class Message {

    /** integer max ordinal value. */
    private static final int MAX_ORDINAL = 56;

    /** integer max value in the MIXChar. */
    private static final int MAX_MIXCHAR = 11;

    /** stores the long array. */
    private long[] longArray;

    /** stores the integer to count #. */
    private int count;

    /**
     * Constructor where values of the m should be packed 11 MIXChar characters 
     * per long in the instance array with the last long element having  
     * fewer than 11 characters packed into it. The instance array should 
     * be sized as small as possible and the count instance variable holds 
     * total number of character.
     * @param m array name of MIXChar array
     */
    public Message(MIXChar[] m) {
        count = m.length;
        makeLong(m);
    }
    
    /**
     * Constructor values of the spacked 11 MIXChar characters per long 
     * in the instance array, with the last long element having  
     * fewer than 11 characters packed into it. The instance array should
     * besized as small as possible and the count instance variable holds
     * total number of character.
     * @param s
     *          String s for the message input
     */
    public Message(String s) {
        count = s.length();
        MIXChar[] mixArray = MIXChar.toMIXChar(s);
        makeLong(mixArray);
    }

    /**
     * Method to insert values into the longArray with 11 MIXChars from 
     * mixArray array for each long.
     * @param mixArray
     *          character array
     * @return longArray with 11 MIXChars
     */
    public long[] makeLong(MIXChar[] mixArray) {
        int size = (int) Math.ceil(mixArray.length / (double) MAX_MIXCHAR);
        longArray = new long[size];

        for (int i = 0; i < size; i++) {
            long packedMIX = 0;

            for (int j = 0; j < MAX_MIXCHAR; j++) {
                if (j + MAX_MIXCHAR * i == count) {
                    longArray[i] = packedMIX;
                    return longArray;
                }

                packedMIX +=
                    mixArray[(int) (j + MAX_MIXCHAR * i)].ordinal()
                           * (long) Math.pow(MAX_ORDINAL, MAX_MIXCHAR - j - 1);
            }   
            longArray[i] = packedMIX;
        }
        return longArray;
    }

//Returns a string corresponding to the characters in the message.</p>

    /**
     * Method to give the string corresponding to the chars in the msg.
     * @return String message
     */
    public String toString() {
        String message = "";

        for (int i = 0; i < longArray.length; i++) {
            long elevenMIXChar = longArray[i];

            for (int j = 0; j < MAX_MIXCHAR; j++) {
                if (j + i * MAX_MIXCHAR == count) {
                    return message;
                }

                int ordinal = (int) Long.divideUnsigned(elevenMIXChar,
                        (long) Math.pow(MAX_ORDINAL, MAX_MIXCHAR - j - 1));
                elevenMIXChar = Long.remainderUnsigned(elevenMIXChar,
                        (long) Math.pow(MAX_ORDINAL, MAX_MIXCHAR - j - 1));
                char mixChar = MIXChar.atOrdinal(ordinal);
                message += mixChar;
            }
        }
        return message;
    }

    /**
     * Method to format the longArray as an unsigned integer.
     * @return a string instance long[] formatted
     */
    public String toLong() {
        String message = "";

        for (int i = 0; i < longArray.length; i++) {
            message += Long.toUnsignedString(longArray[i]) + " ";
        }
        return message;
    }
}