package q3;

import java.util.Scanner;

/**
 * Driver to input a message using a MIX character, encode that message
 * into a MIX Char value and decode it back into java.
 * @author sehyung kim
 * @version 1.0
 *
 */
public class TestMIXChar {

    /**
     * Reads a line from the input, and prints an error message if any 
     * characters are invalid MIX characters.  
     * If all the characters are MIX characters, convert them to have the 
     * correct numerical values, then encode them into a Message and 
     * print out the resulting long[] (as unsigned strings).  
     * Then, decodes the Message, convert the MIXChar characters to a 
     * Java string and print out the resulting Java String.
     * @param args
     *              unused
     */
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        
        boolean endLoop = false;

        while (!endLoop) {
        try {
            System.out.println("Please enter a message using MIX characters.");

            String messageString = scan.nextLine();
            
            Message message = new Message(messageString);

            System.out.println("The encoded message is : ");
            System.out.println(message.toLong());

            System.out.println("The decoded message is : ");
            System.out.println(message.toString());
            
            endLoop = true;

        } catch (IllegalArgumentException e) {
            System.out.println("Invalid Input");
        }
        }
       
        scan.close();
    }
}