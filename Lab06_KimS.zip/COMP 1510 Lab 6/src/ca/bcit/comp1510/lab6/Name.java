/**
 * 
 */
package ca.bcit.comp1510.lab6;

/**
 * Name.  Uses constructor, accessors and mutators, specific type methods 
 * and toString() method to calculate and return name outputs. 
 * @author erickim
 * @version 1.0
 */

public class Name {
    /**
     * Declared private instance variable firstname.
     */
    private String firstName;
    /**
     * Declared private instance variable middlename.
     */
    private String middleName;
    /**
     * Declared private instance variable lastname.
     */
    private String lastName;

    /**
     * Constants used in random generator, avoid magic numbers.
     */
    public static final int TWENTYSIX = 26; 
    
    /**
     * Constructor to set up the first, middle, and last name components.
     * @param first **first name**
     * @param middle **middle name**
     * @param last **last name** 
     */
    public Name(String first, String middle, String last) {
        firstName = first;
        if (firstName.trim().isEmpty()) {
            firstName = "John";
        } else {
            firstName = firstName.toLowerCase();
            String firstLetter = firstName.substring(0, 1).toUpperCase();
            String rest = firstName.substring(1, first.length());
            firstName = firstLetter + rest;
        }
        
        middleName = middle;
        if (middleName.trim().isEmpty()) {
            middleName = "Rudolf";
        } else {
            middleName = middleName.toLowerCase();
            String firstLetter = middleName.substring(0, 1).toUpperCase();
            String rest = middleName.substring(1, middleName.length());
            middleName = firstLetter + rest;
        }
    
        lastName = last;
        if (lastName.trim().isEmpty()) {
            lastName = "Doe";
        } else {
            lastName = lastName.toLowerCase();
            String firstLetter = lastName.substring(0, 1).toUpperCase();
            String rest = lastName.substring(1, lastName.length());
            lastName = firstLetter + rest;
        }
        }
    

    /**
     * Accessor.
     * @return the firstName
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * Mutator.
     * @param first the firstName to set
     */
    public void setFirstName(String first) {
        firstName = first;
        if (first.trim().isEmpty()) {
            return;
        } else {
            first = first.toLowerCase();
            String firstLetter = first.substring(0, 1).toUpperCase();
            String rest = first.substring(1, first.length());
            firstName = firstLetter + rest;
        }
    }

    /**
     * Accessor.
     * @return the middleName
     */
    public String getMiddleName() {
        return middleName;
    }

    /**
     * Mutator.
     * @param middle the middleName to set
     */
    public void setMiddleName(String middle) {
        middleName = middle;
        if (middle.trim().isEmpty()) {
            middle = "Rudolf";
        } else {
            middle = middle.toLowerCase();
            String firstLetter = middle.substring(0, 1).toUpperCase();
            String rest = middle.substring(1, middle.length());
            middle = firstLetter + rest;
        }
     }    

    /**
     * Accessor.
     * @return the lastName
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * Mutator.
     * @param last the lastname to set
     */
    public void setLastName(String last) {
        lastName = last;
        if (last.trim().isEmpty()) {
            last = "Doe";
        } else {
            last = last.toLowerCase();
            String firstLetter = last.substring(0, 1).toUpperCase();
            String rest = last.substring(1, last.length());
            last = firstLetter + rest;
        }
     }    

     /**
     * Returns a String composed of the concatenation of the information in the
     * Name.
     * @return first,middle,last name as string
     */
    
    public int getNameLength() {
        int totalLength = firstName.length() + middleName.length() 
                          + lastName.length();
        return totalLength;
    }
    /**
     * Method to capitalize first letter of names.
     * @return capital initials of first,middle,last name.
     */
    public String getNameUpper() {
        String initialsUpper = firstName.substring(0, 1)
                            + middleName.substring(0, 1)
                            + lastName.substring(0, 1);
        return initialsUpper.toUpperCase();              
    }
    
    
    /**
     * Method to take first,middle,lastname inputs and change
     * order of them as written below.
     * @return rearranged string names
     */
    public String getNameOrder() {
        return lastName + ", " + firstName + ", "
               + middleName;
    }
    
    
    /**
     * Method to get n and return nth char.
     * @param n as an integer
     * @return int n character from string
     */
    public char getN(int n) {
        if (n <= firstName.length() + middleName.length() + lastName.length()) {
            String str = firstName + middleName + lastName;
            return str.charAt(n - 1);
        } else {
            char strInvalid = '@';
            return strInvalid;
        }
       
    }
    
    /**
     * Method to get n and return nth char.
     * @param input as a string
     * @return true or false if strings equal
     */
    public boolean getEqual(String input) {
        return input.equals(firstName);

    }
    
    /**
     * Method to compare two names.
     * @param nameParts as a string
     * @return true or false if strings equal
     */
    public boolean getName(String nameParts) {
        
        return nameParts.equals(firstName + middleName + lastName);
    }

    
    
    /** 
     * String method.
     * @return returns strings of methods.
     */
    public String toString() {
        return "Name: firstName= " + firstName + ", middleName= " 
                    + middleName + ", lastName= " + lastName
                    + "\nThe 25th Character is= " + getN(TWENTYSIX);
        }

}
