/**
 * 
 */
package ca.bcit.comp1510.lab6;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

/**
 * MathematicsTest.
 * 
 * @author erickim
 * @version 1.0
 */
public class NameTest {

    /**
     * Instance of Name object is created. 
     */
    private Name name = new Name(" ", " ", " ");
    /**
     * Instance of Name object is created. 
     */
    private Name name1 = new Name("john", " ", " ");
    /**
     * Instance of Name object is created. 
     */
    private Name name2 = new Name(" ", "rudolf", " ");
    /**
     * Instance of Name object is created. 
     */
    private Name name3 = new Name(" ", " ", "doe");
    /**
     * Instance of Name object is created. 
     */
    private Name name4 = new Name("random", "naming ", "testingforjavalab");

    /**
     * Tests blank toString method from Name class to check if methods work.
     */
    @Test
    public void testToString() {
        String expected = "Name: firstName= " + "John" + ", middleName= " 
                + "Rudolf" + ", lastName= " + "Doe"
                + "\nThe 25th Character is= " + "@";
        assertEquals(expected, name.toString());
    }
    
    /**
     * Tests blank toString method from Name class to check if methods work.
     */
    @Test
    public void testBlankFirst() {
        String expected = "Name: firstName= " + "John" + ", middleName= " 
                + "Rudolf" + ", lastName= " + "Doe"
                + "\nThe 25th Character is= " + "@";
        assertEquals(expected, name1.toString());
    }
    
    /**
     * Tests blank toString method from Name class to check if methods work.
     */
    @Test
    public void testBlankMiddle() {
        String expected = "Name: firstName= " + "John" + ", middleName= " 
                + "Rudolf" + ", lastName= " + "Doe"
                + "\nThe 25th Character is= " + "@";
        assertEquals(expected, name2.toString());
    }
    
    /**
     * Tests blank toString method from Name class to check if methods work.
     */
    @Test
    public void testBlankLast() {
        String expected = "Name: firstName= " + "John" + ", middleName= " 
                + "Rudolf" + ", lastName= " + "Doe"
                + "\nThe 25th Character is= " + "@";
        assertEquals(expected, name3.toString());
    }
    
    /**
     * Tests blank toString method from Name class to check if methods work.
     */
    @Test
    public void testCharacterFirst() {
        String expected = "Name: firstName= " + "Random" + ", middleName= " 
                + "Naming " + ", lastName= " + "Testingforjavalab"
                + "\nThe 25th Character is= " + "v";
        assertEquals(expected, name4.toString());
    }
}
