/**
 * 
 */
package ca.bcit.comp1510.lab6;

import java.util.Scanner;


/**
 * NameDriver. Prompts user for input, and returns output from user input
 * calling public Name class methods.
 * @author erickim
 * @version 1.0 
 */
public class NameDriver {

    /**
     * Drives the program.
     * @param args unused
     */
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        

        System.out.println("Enter in first name");
        String first = scan.nextLine();
        
        System.out.println("Enter in middle name");
        String middle = scan.nextLine();
        
        System.out.println("Enter in last name");
        String last = scan.nextLine();
        
        // creates and calls name class with parameters input.
        Name name = new Name(first, middle, last);
        
        System.out.println("Enter in integer n: ");
        int n = scan.nextInt();
        
        scan.nextLine();
        System.out.println("\nEnter in another first name: ");
        String inputf = scan.nextLine();
        
        System.out.println("Enter in another middle name: ");
        String inputm = scan.nextLine();
       
        System.out.println("Enter in another last name: ");
        String inputl = scan.nextLine();
        
        System.out.println(name);
        
        System.out.println("The nth char selected is: "
                + name.getN(n));
        
        System.out.println("The first name equals original first?: "
                + name.getEqual(inputf));
        
        System.out.println("All name parts equals original name?: "
                + name.getName(inputf + inputm + inputl));
       
        
        scan.close();
        
    }

}

//Yes it works for all names.