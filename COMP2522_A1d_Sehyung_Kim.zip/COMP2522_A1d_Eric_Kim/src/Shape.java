/*
 * Creates an abstract Shape class which stores variables 
 * to define a shape which is used in other classes which 
 * extend Shape
 * 
 * @author Eric Kim
 * @version 1.0
 */
public abstract class Shape {
    
    /* Width of the shape */
    protected int width;
    /* Height of the shape */
    protected int height;
    /* Type of shape */
    protected String t;
    /* Grid structure of the shape */
    protected char[][] grid;

    /*
     * Constructor for the Shape
     * 
     * @param width width of the shape
     * @param height height of the shape
     * @param t type of shape
     * @throws BadWidthException 
     */
    protected Shape(final int width, final int height, final String t) throws BadWidthException {
        this.width = width;
        this.height = height;
        this.t = t;
        this.grid = new char[height][width];
    }
    
    /*
     * Method that returns the width of the shape
     */
    public int getWidth() {
        return width;
    }
    /*
     * Method that returns the height of the shape
     */
    public int getHeight() {
        return height;
    }
    
    /*
     * Method that returns the value inside the shape grid
     * at specific index
     */
    public String getCharAt(final int row, final int col){
        return String.valueOf(grid[row][col]);
    }
    
}
