/*
 * Creates a Triangle class that extends the shape class
 * 
 * @author Eric Kim
 * @version 1.0
 */
public class Triangle extends Shape {
    
    /*
     * Constructor for Triangle
     * 
     * @param width of the triangle
     * @param height of the triangle
     * @throws BadWidthException if width is not an odd number
     */
    public Triangle(final int width, final int height) throws BadWidthException {
        super(width, (width / 2) + 1, "t");
        if (width % 2 == 0) {
            throw new BadWidthException();
        }

        // Triangle grid row index
        for (int i = 0; i < this.height; i++) {

            // Triangle content column index
            for (int j = 0; j < width; j++) {

                if (j == width / 2 || (j >= width / 2 - i && j <= width / 2 + i)) {
                    grid[i][j] = '@';
                } else {
                    grid[i][j] = ' ';
                }
            }
        }
    }
}
