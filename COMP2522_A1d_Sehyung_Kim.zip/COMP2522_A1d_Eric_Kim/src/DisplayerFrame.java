import javafx.scene.*;
import javafx.stage.*;
import javafx.application.*;
import javafx.scene.layout.*;
import javafx.scene.control.*;

/*
 * Creates a DisplayerFrame class which extends Application
 * Setups GUIDisplayer using javafx.
 * 
 * @author Eric Kim
 * @version 1.0
 */
public class DisplayerFrame extends Application{

    static Shape shape;
    public void start(Stage stage) {
        GridPane root = new GridPane();
        for (int row = 0; row < shape.getHeight(); row++) {
            for (int col = 0; col < shape.getWidth(); col++) {
                root.add(new Button(shape.getCharAt(row, col)), col, row);
            }
        }

        root.setMinSize(10,10);
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.setTitle("My Shape");
        stage.show();
    }
}
