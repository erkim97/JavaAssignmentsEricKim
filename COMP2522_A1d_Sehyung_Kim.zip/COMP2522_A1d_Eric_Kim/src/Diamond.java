/*
 * Creates a Diamond class that extends Shape class.
 * 
 * @author Eric Kim
 * @version 1.0
 */
public class Diamond extends Shape {
    
    /*
     * Constructor for Diamond
     * 
     * @param width width of the diamond
     * @param height height of the diamond
     * @throws BadWidthException if width is not a odd number
     */
    public Diamond(final int width, final int height) throws BadWidthException {
        super(width, width, "d");
        if (width % 2 == 0) {
            throw new BadWidthException();
        }

        // Diamond grid row index
        for (int i = 0; i < this.height; i++) {

            // Diamond grid column index
            for (int j = 0; j < width; j++) {

                // Top half of Diamond
                if (i <= this.height / 2) {
                    if (j == width / 2 || (j >= width / 2 - i && j <= width / 2 + i)) {
                        grid[i][j] = '#';
                    } else {
                        grid[i][j] = ' ';
                    }
                    // Bottom half of Diamond
                } else {
                    if (j == width / 2 || (j > width / 2 - (this.height - i) && j < width / 2 + (this.height - i))) {
                        grid[i][j] = '#';
                    } else {
                        grid[i][j] = ' ';
                    }
                }
            }
        }

    }
}
