import javafx.application.Application;

/*
 * Creates a GUIDisplayer that implements the Displayer interface.
 *
 * 
 * @author Eric Kim
 * @version 1.0
 */
public class GUIDisplayer implements Displayer {
    
    /*
     * Method that displays the shape to the GUI
     */
    public void displayShape(Shape shape) {
        DisplayerFrame.shape = shape;
        Application.launch(DisplayerFrame.class);
    }
}
