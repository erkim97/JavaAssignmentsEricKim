import java.lang.Exception;

public class BadWidthException extends Exception {
}
