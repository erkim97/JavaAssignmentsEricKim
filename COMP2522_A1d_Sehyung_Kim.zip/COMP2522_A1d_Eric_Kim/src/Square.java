/*
 * Creates a Square class that extends the Rectangle class
 * 
 * @author Eric Kim
 * @version 1.0
 */

public class Square extends Rectangle {
    
    /*
     * Constructor for Square 
     * 
     * @param width width of square
     * @param height height of the square
     * @throws BadWidthException
     */
    public Square(final int width, final int height) throws BadWidthException {
        super(width, width, "s");

    }
}
