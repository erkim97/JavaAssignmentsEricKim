/*
 * Creates a ConsoleDisplay Class that implements a Displayer interface.
 * Prints a shape to the console.
 * 
 * @author Eric Kim
 * @version 1.0
 */
public class ConsoleDisplayer implements Displayer {

    public void displayShape(Shape shape) {
        for(int i = 0; i < shape.getHeight(); i++){
            for(int j = 0; j < shape.getWidth(); j++){
                System.out.print(shape.getCharAt(i, j));
            }
            System.out.println();
        }
    }
}
