/*
 * Creates a Displayer interface that has an undefined displayShape method.
 * 
 *  @author Eric Kim
 *  @version 1.0
 */
public interface Displayer {
    void displayShape(Shape shape);
}
