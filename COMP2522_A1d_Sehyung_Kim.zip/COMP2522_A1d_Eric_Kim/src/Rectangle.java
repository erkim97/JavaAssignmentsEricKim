/*
 * Creates a Rectangle class that extends the shape class
 *  
 * 
 * @author Eric Kim
 * @version 1.0
 */
public class Rectangle extends Shape {
    
    /*
     * Constructor for Rectangle
     * 
     * @param width width of rectangle
     * @param height height of rectangle
     * @throws BadWidthException 
     */
    public Rectangle(final int width, final int height) throws BadWidthException {
        super(width, height, "r");

        // Rectangle grid structure
        for (int i = 0; i < height; i++) {
            for (int j = 0; j < width; j++) {
                grid[i][j] = '*';
            }
        }
    }
    
    /*
     * Constructor for Rectangle 2
     * Allows square class to call super
     * 
     * @param width width of rectangle
     * @param height height of rectangle
     * @param t type of shape
     * @throws BadWidthException 
     */
    public Rectangle(final int width, final int height, final String t) throws BadWidthException {
        super(width, height, t);

        // Rectangle grid structure
        for (int i = 0; i < height; i++) {
            for (int j = 0; j < width; j++) {
                grid[i][j] = '*';
            }
        }
    }
}
