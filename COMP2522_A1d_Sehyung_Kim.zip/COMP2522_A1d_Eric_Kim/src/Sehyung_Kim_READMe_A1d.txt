Eric (Sehyung) Kim, A01089966, COMP 2522 A1d README file

Purpose: To practice basic Java skills and to provide a means of exploring the WHY and the HOW in Object Oriented Programming in the future enhancements of assignment 1a.

Description: You are to develop a program that prints out shapes : Rectangle, Triangle, Diamond, Right-Angle-Triangle, Square given the type, width, height. In addition the shape may be displayed using a GUI interface OR a standard console. See Assignments #1a,#1b, and #1c for further details.

Require a Displayer type (chose between abstract class, concrete class, or interface). The Displayer type has ONE method displayShape(Shape shape). Implementation of this method should be found in the appropriate displayer class: ConsoleDisplayer or GUIDisplayer.

The main method is modified to take an additional argument either ConsoleDisplayer or GUIDisplayer.  Make sure that you use Main.java source code that is on D2L as a starting point.

The GUIDisplayer displayShape() will make use of the DisplayerFrame class which is an Application (Javafx) to display the shape [code provided].  GUIDisplayer class will need to set the static �shape� member of the DisplayerFrame. For simplicity, each value of the table is stored in a Button.  To have the GUI work you�ll need to launch it as an application using the line: Application.launch(DisplayerFrame.class);

ALL Shape classes including the Shape class MUST have in their Constuctor declaration line �throws BadWidthException� even if they do not throw the exception.

(HINT) Rectangle, Triangle, RTriangle, Diamond, Square are all shapes (HINT) In fact a Square is-a Rectangle (HINT)
