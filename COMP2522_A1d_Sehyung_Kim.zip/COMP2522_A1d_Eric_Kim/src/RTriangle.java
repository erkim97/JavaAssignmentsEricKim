/*
 * Creates a Right Triangle class that extends the shape class
 * 
 * @author Eric Kim
 * @version 1.0
 */
public class RTriangle extends Shape {
    
    /*
     * Constructor for Right Triangle
     * 
     * @param width width of right triangle
     * @param height of right triangle
     * @throws BadWidthException if width is not an odd number
     */
    public RTriangle(final int width, final int height) throws BadWidthException {
        super(width, width, "Rt");
        if (width % 2 == 0) {
            throw new BadWidthException();
        }
        
        // Height of the Right triangle structure
        for (int i = 0; i < this.height; i++) {
            
            // Width of the Right triangle structure
            for (int j = 0; j < width; j++) {
                if (j >= width - i - 1) {
                    grid[i][j] = '@';
                } else {
                    grid[i][j] = ' ';
                }
            }
        }
    }
}



