package A1a;
/*
 * Program that creates an arithmetic table. 
 * First argument specifies 
 * if table is multiplication or 
 * addition. Second argument specifies 
 * what value the arithmatic table
 * will start at and the third argument 
 * specifies what value the arithmetic 
 * table will end at.
 */

/**
 * @author Eric Kim
 */
public class ArithmeticTable
{
 
 // enum types add and mult
    private static enum TableType   
    {
        ADD, MULT
    };
    
 // Tabletype instance
    private TableType tableType;
    
 // stores math operator as string
    private String operator;
    
 // array list for arithmetic table as float
    private float[][] table; 
    
 // start value of table as int
    private int start;              

 // end value of table as int
    private int end;                
    
 // array size as an int
    private int arraySize;
    
    public boolean argumentCheck(String[] args)
    {
        if(args.length!=3)
        {
            System.err.println("Usage: Main <type> <start> <stop>");
            System.err.println("\tWhere <type> is one of +, \"*\"");
            System.err.println("\tand <start> is between 1 and 100");
            System.err.println("\tand <stop> is between 1 and 100");
            System.err.println("\tand start < stop");
            return false;
        }        

        if(args[0].charAt(0) == '+')
            tableType = TableType.ADD;
        else
            tableType = TableType.MULT;
    
        int sta;
        int sto;

        try
        {
            sta = Integer.parseInt(args[1]);
            sto = Integer.parseInt(args[2]);
        }
        catch(NumberFormatException ex)
        {
            System.err.println("Usage: Main <type> <start> <stop>");
            System.err.println("\tWhere <type> is one of +, -, \"*\", /");
            System.err.println("\tand <start> is between 1 and 100");
            System.err.println("\tand <stop> is between 1 and 100");
            System.err.println("\tand start < stop");
            return false;
        }

        if((sta < 1 || sta > 100)||((sto < 1 || sto > 100)))
        {
            System.err.println("Usage: Main <type> <start> <stop>");
            System.err.println("\tWhere <type> is one of +, -, \"*\", /");
            System.err.println("\tand <start> is between 1 and 100");
            System.err.println("\tand <stop> is between 1 and 100");
            System.err.println("\tand start < stop");
            return false;
        }

        if(sta >= sto)
        {
            System.err.println("Usage: Main <type> <start> <stop>");
            System.err.println("\tWhere <type> is one of +, -, \"*\", /");
            System.err.println("\tand <start> is between 1 and 100");
            System.err.println("\tand <stop> is between 1 and 100");
            System.err.println("\tand start < stop");
            return false;
        }
        
        start = sta;
        end = sto;
        return true;
    }

    // main method
    public static void main(String[] args)
    {
        ArithmeticTable table = new ArithmeticTable();
        if (table.argumentCheck(args))
        {
            table.createTable(table.start, table.end, table.tableType);
            table.printTable();
        }
    }

    // Arithmetic table
    public void createTable(int begin, int finish, TableType tableType)
    {
        arraySize = end - start + 1;    // defines array size
        table = new float[arraySize][arraySize];    // creates array
        start = begin;
        end = finish;

        // Switch cases ADD or MULT
        switch (tableType)
        { 
     // if + is argument value, addition table
            case ADD: 
                for (int row = 0; row < table.length; row++)
                    for (int col = 0; col < table.length; col++)
                        table[row][col] = (row + start) + (col + start);
            break;
     
     // if * is argument value, creates multiplication table
            case MULT: 
                for (int row = 0; row < table.length; row++)
                    for (int col = 0; col < table.length; col++)
                        table[row][col] = (row + start) * (col + start);
            break;
        }
    }

    // print Arithmetic table
    public void printTable()
    {
        String s = "----";
        System.out.printf("\n");
        
        // which operator used, prints it
        if (tableType == TableType.ADD)
            operator = "+";
        else
            operator = "*";
        System.out.printf("%4s", operator);

        // prints header numbers
        System.out.printf("  ");
        for (int i = 0; i < table.length; i++)
            System.out.printf("%4d", (i + start));

        System.out.printf("\n");

        // prints under header numbers
        System.out.printf("  ");
        for (int i = 0; i <= table.length; i++)
            System.out.printf("%4s", s);
            System.out.printf("\n");

        // prints side column numbers and array
        for (int row = 0; row < table.length; row++)
        {
            System.out.printf("%4d |", row + start);
            for (int col = 0; col < table.length; col++)
                System.out.printf("%4.0f", table[row][col]);
            
            System.out.printf("\n");
        }
    }
}