[Sehyung(Eric) Kim], [A01089966], [C], [March 31, 2019]

This assignment is [100]% complete.


------------------------
Question one (WordCounter) status:

[complete]

------------------------
Question two (Primes) status:

[complete]

------------------------
Question three (TestStudent and supporting classes) status:

[complete]
Hard coded in data, with random test scores.
------------------------
Question four (TestCourse and supporting classes) status:

[complete]
Hard coded in data, with random test scores.
------------------------
