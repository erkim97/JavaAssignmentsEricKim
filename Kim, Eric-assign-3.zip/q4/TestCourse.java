package q4;

import java.util.Random;

import q3.Address;
import q3.Student;

/**
 * <p> Driver for the Course class to print out all students in
 * the course and the entire class test average.</p>
 *
 * @author eric kim
 * @version 1.0
 */
public class TestCourse {
    /**
     * <p>This is the main method (entry point) that gets called by the JVM.</p>
     *
     * @param args command line arguments.
     * @throws Exception 
     */
    public static void main(String[] args) {
        final int randomNum = 101;
        final int three = 3;
        Random generator = new Random();
        
        Course course = new Course("COMP1510"); 
        Address school = new Address("123 Willingdon Ave", "Burnaby", 
                "BC", "A1B 2CD");
        Address gHome = new Address("111 Willow Street", "Coquitlam", 
                "BC", "V1B 3K4");
        Address jHome = new Address("123 Willow Street", "Coquitlam", 
                "BC", "V1B 3K4");
        Address bHome = new Address("135 Willow Street", "Coquitlam", 
                "BC", "V1B 3K4");
        Address cHome = new Address("168 Willow Street", "Coquitlam", 
                "BC", "V1B 3K4");
        Address eHome = new Address("189 Willow Street", "Coquitlam", 
                "BC", "V1B 3K4");
        
        Student gates = new Student("Gates", "Bill", gHome, school);
        Student jobs = new Student("Jobs", "Steve", jHome, school);
        Student bezos = new Student("Bezos", "Jeff", bHome, school);
        Student cook = new Student("Cook", "Tim", cHome, school);
        Student kim = new Student("Kim", "Eric", eHome, school);


        gates.setTestScore(1, generator.nextInt(randomNum));
        gates.setTestScore(2, generator.nextInt(randomNum));
        gates.setTestScore(three, generator.nextInt(randomNum));
        gates.average();

        jobs.setTestScore(1, generator.nextInt(randomNum));
        jobs.setTestScore(2, generator.nextInt(randomNum));
        jobs.setTestScore(three, generator.nextInt(randomNum));
        jobs.average();
        
        bezos.setTestScore(1, generator.nextInt(randomNum));
        bezos.setTestScore(2, generator.nextInt(randomNum));
        bezos.setTestScore(three, generator.nextInt(randomNum));
        bezos.average();

        cook.setTestScore(1, generator.nextInt(randomNum));
        cook.setTestScore(2, generator.nextInt(randomNum));
        cook.setTestScore(three, generator.nextInt(randomNum));
        cook.average();
        
        kim.setTestScore(1, generator.nextInt(randomNum));
        kim.setTestScore(2, generator.nextInt(randomNum));
        kim.setTestScore(three, generator.nextInt(randomNum));
        kim.average();
        
        course.addStudent(gates); 
        course.addStudent(jobs); 
        course.addStudent(bezos); 
        course.addStudent(cook); 
        course.addStudent(kim); 
        
        System.out.println("The following students are in COMP1510:");
        course.roll();         
        
        System.out.println("THe Overall COMP1510 test average is: " 
                + course.average());
        System.out.println("Question four was called and ran sucessfully.");
    }

};
