/**
 * 
 */
package q4;

import q3.Student;
import java.util.ArrayList;
import java.util.List;

/**
 * <p> Course that represents a course taken at school, that
 * tracks up to five students as represented by the modified 
 * Student class from the previous project. Prints out toString()
 * from Student class with all the information of each student,
 * and averages out all student test scores in the course.</p>
 * @author erickim
 * @version 1.0
 */
public class Course { 

    /**
     * Declares a variable to store course name.
     */
    private String name; 

    /**
     * Creates an ArrayList to store students for course.
     */
    private List<Student> students; 

    /**
     * Constrcutor for class Course.
     * @param name of the course
     */
    public Course(String name) { 
        this.name = name; 
        students = new ArrayList<Student>(); 
    } 

    /**
     * Method which accepts and stores student in array.
     * @param student to add to array
     */
    public void addStudent(Student student) { 
        final int five = 5;
        if (students.size() <= five) { 
            students.add(student);
            } else {
            throw new ArrayIndexOutOfBoundsException("Out of Bounds Exc."
                    + " size is more than 5");
        } 
    } 

    /**
     * Method to calculate average of all student test scores.
     * @return average of test scores
     */
    public double average() {
        double total = 0.00;
        double average = 0.00;
        
        for (Student student : students) {
            total += student.average();
        }
        average = total / students.size();
        return average;
    }
    
    /**
     * Method to print all students in the course.
     */
    public void roll() { 
        System.out.println("Course: " + name); 
        System.out.println("Students:"); 

        for (Student student : students) { 
            System.out.println("\n" + student.toString()); 
        } 
    } 
}


