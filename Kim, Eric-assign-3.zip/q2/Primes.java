package q2;

import java.util.ArrayList;
import java.util.Scanner;

/**
 * <p>Using the Sieve of Eratosthenes method to determine which
 * numbers and number of numbers are prime when entering in an 
 * upper bound integer.</p>
 *
 * @author eric kim
 * @version 1.0
 */

      public class Primes {
            /**
             * Initialize Boolean list with arraylist.
             */
            private ArrayList<Boolean> primes;
           
            /**
             * Constructor used to initialize primes ArrayList to have 
             * maximum index n.
             * @param n integer n
             */
            public Primes(int n) {
             
            primes = new ArrayList<Boolean>();
             
            for (int i = 0; i <= n; i++) {
                primes.add(true);
            }
             
            calculatePrimes(n);
             
            }
            /**
             * private method using Sieve of Eratosthenes to determine
             * which indices are prime or not.
             * @param n as an int
             */
            private void calculatePrimes(int n) {
             
            for (int p = 2; p * p <= n; p++) {
                if (primes.get(p)) {
                    for (int i = p * 2; i <= n; i += p) {
                        primes.set(i, false);
                    }
                }
            }
            }
            /**
             * method to print the list of prime numbers.
             */
            public void printPrimes() { 
            for (int i = 2; i < primes.size(); i++) {
            if (primes.get(i)) {
                System.out.print(i + " ");
            }
            }
             
            System.out.println();
             
            }
            /**
             * Method to count number of int representing number of primes in 
             * the range [0,N].
             * @return returns int count c
             */
            public int countPrimes() {
             
            int c = 0;
             
            for (int i = 2; i < primes.size(); i++) {
             
            if (primes.get(i)) {
                c++;
            }
             
            }
             
            return c;
             
            }
            
            /**
             * Method to determine if x is prime or not in range [0,N].
             * @param x as an int
             * @return true if x is prime or false if not
             */
            public boolean isPrime(int x) {
             
            return primes.get(x);
             
            }
            
    /**
     * <p>This is the main method (entry point) that gets called by the JVM.</p>
     *
     * @param args command line arguments.
     */
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        
        System.out.println("This program uses the sieve of Eratosthenes "
                + "to determine which numbers are prime.");
         
        System.out.println("Enter an upper bound: ");
         
        int n = scan.nextInt();
         
        while (n <= 1) {
        System.out.println("Upper bound must be greater than 1! Reenter: ");
        n = scan.nextInt(); 
        }
         
        Primes primes = new Primes(n);
         
        int count = primes.countPrimes();         
        System.out.println("There are " + count + " primes:");
        System.out.println("The prime numbers between 0 and " + n + " are: ");
        primes.printPrimes();
        
        scan.close();
        
        System.out.println("Question two was called and ran sucessfully.");

        }
         
    }

