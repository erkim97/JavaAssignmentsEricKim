/**
 * 
 */
package q1;

/**
 * <p> Word class to store each word text and store the frequency
 * of times each word appears. Implements a comparable<word> interface. </p>
 * @author Eric Kim
 * @version 1.0
 *
 */
public class Word implements Comparable<Word> {

    /**
     * String to store each word text.
     */
    private final String word;

    /**
     * Stores integer frequency for number of word instances.
     */
    private int frequency;

    /**
     * Constructor for word and frequency Word class.
     * @param word
     *          Pass in a String word
     */
    public Word(String word) {
          this.word = word;
          
          this.frequency = 1;
    }

    /**
     * Accessor to get word.
     * @return returns the word
     */
    public String getWord() {
          return word;
    }

    /**
     * Accessor to get frequency.
     * @return returns the frequency
     */
    public int getFrequency() {
          return frequency;
    }

    /**
     * Helper method to increase frequency of word occurance
     * by one.
     */
    public void incrementFrequency() {
          frequency++;
    }

    /**
     * toString helper method to output word and 
     * number of frequencies.
     * @return word : frequency
     */
    public String toString() {
          return word + " : " + frequency;
    }

    /**
     * Helper method to accept another Word as the parameter
     * to compare Words and higher frequency comes first.
     * @param w Word
     * @return returns an int
     */
    public int compareTo(Word w) {
          if (this.frequency > w.frequency) {
                return -1;
          }
          if (this.frequency < w.frequency) {
                return 1;
          }
          // Returns same frequency
          return 0; 
    }

    /**
    * Overrides equals method so that contains() method of list works.
    * @return returns true or false
    * @param obj object
    * @Override
    */    
    public boolean equals(Object obj) {
          if (obj instanceof Word) {
                Word w = (Word) obj;
                if (this.word.equalsIgnoreCase(w.word)) {
                     return true;
                }
          }
          return false;
    }
    @Override
    public int hashCode() {
        return word.hashCode();
    }
}