package q1;

import java.io.File;

import java.io.FileNotFoundException;

import java.util.ArrayList;

import java.util.Collections;

import java.util.List;

import java.util.Scanner;

/**
 * <p> Tells us how many distinct words there are in the enclosed text file 
 * which is a plaintextcopy of the King James Bible, available from 
 * Project Gutenberg. The file is provided in the src directory of this
 * folder.</p>
 *
 * @author Eric Kim
 * @version 1.0
 */
public class WordCounter {

   /**
    * Initializes arraylist Word to store words and count.
    */
   private List<Word> words;
   
   /**
    * Constructor for WordCounter with words objects in arraylist Word.
    */
   public WordCounter() {
         // initializing the array list
         words = new ArrayList<Word>();
   }

   /**
   * method to parse a file.
   *
   * @param fileName 
   *            name of file, src/bible.txt
   * @return Number of unique words from array list
   */
   public int parseBook(String fileName) {

         try {
               // opening file, will throw exception if not found
               Scanner scan = new Scanner(new File(fileName));
               
               while (scan.hasNext()) {
                    // getting the word and creating a Word obejct.
                    String word = scan.next().toLowerCase();
                    
                    // New word object w to run methods from
                    Word w = new Word(word);

                    // Checks if arraylist already contains unique word.
                    if (words.contains(w)) {
                          // If arraylist contains unique word, add +1 frequency
                          words.get(words.indexOf(w)).incrementFrequency();
                    } else {
                          // Add unique word as a new word object
                          words.add(w);
                    }
               }
               scan.close();
               
         } catch (FileNotFoundException e) {
               // If user input into scanner file name not found error
               System.out.println(e);
         }
         // Return number of unique words
         return words.size();
         
   }

   /**
   * method to print top n words.
   *
   * @param n
   *            number of words to display
   */

   public void printTopWords(int n) {
         // Sorts the words from the Word array according to number.
         Collections.sort(words);
         
         // Gets first n words from Word Arraylist. First ten in this case.
         for (int i = 0; i < n; i++) {
               System.out.println(words.get(i));
         }
   }

   /**
    * Drives the program.
    * @param args unused.
    */
   public static void main(String[] args) {
        /**
         * Magic number 10.
         */
        final int ten = 10;
        
         // scanner to read input file name from user
         Scanner scan = new Scanner(System.in);
         System.out.print("Enter file name (src/bible.txt): "
                 + "Please wait a while as it takes some time! :)");

         // getting file name
         String fileName = scan.nextLine();

         // creating a WordCounter
         WordCounter counter = new WordCounter();

         // parsing the file
         int n = counter.parseBook(fileName);

         // displaying stats and printing top 10 words
         System.out.println(n + " unique words are in src/bible.txt");
         System.out.println("The top 10 words are: ");
         counter.printTopWords(ten);
         
         System.out.println("Question one was called and ran successfully");
         
         scan.close();
   }

}