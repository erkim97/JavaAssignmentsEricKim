package q3;

import java.util.Random;

/**
 * <p>Driver to test the Student class, sets an address and 
 * school address alongside student objects, sets the test scores
 * of each student object, averages them and prints out the information.</p>
 *
 * @author eric kim
 * @version 1.0
 */
public class TestStudent {
    /**
     * <p>This is the main method (entry point) that gets called by the JVM.</p>
     *
     * @param args command line arguments.
     */
    public static void main(String[] args) {
            final int randomNum = 101;
            final int three = 3;
            Random generator = new Random();
            
            Address school = new Address("123 Willingdon Ave", "Burnaby", 
                    "BC", "A1B 2CD");

            Address jHome = new Address("123 Willow Street", "Coquitlam", 
                    "BC", "V1B 3K4");

            Student john = new Student("John", "Smith", jHome, school);

            Address mHome = new Address("123 Austin Ave", "Coquitlam", 
                    "BC", "V1C 2K4");

            Student mary = new Student("Mary", "May", mHome, school);

            john.setTestScore(1, generator.nextInt(randomNum));
            john.setTestScore(2, generator.nextInt(randomNum));
            john.setTestScore(three, generator.nextInt(randomNum));
            john.average();

            mary.setTestScore(1, generator.nextInt(randomNum));
            mary.setTestScore(2, generator.nextInt(randomNum));
            mary.setTestScore(three, generator.nextInt(randomNum));
            mary.average();

            System.out.println(john);
            System.out.println();
            System.out.println(mary);
        }
}
