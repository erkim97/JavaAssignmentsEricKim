package q3;

/**
 * Represents a BCIT student.
 * 
 * @author eric kim
 * @version 1.0
 */
public class Student {
    /** First name of this student. */
    private String firstName;

    /** Last name of this student. */
    private String lastName;

    /** Home address of this student. */
    private Address homeAddress;

    /** School address of this student.  Can be shared by other students */
    private Address schoolAddress;

    /** Test score one of this student. */
    private int test1;
    
    /** Test score two of this student. */
    private int test2;

    /** Test score three of this student. */
    private int test3;

    /** Average test score of this student. */
    private double averageScore;

    /** Magic number integer 3. */
    private final int three = 3;
    /**
     * Constructs a Student object that contains the specified values.
     * @param first a String representing the first name
     * @param last a String representing the last name
     * @param home an Address object containing the home address
     * @param school an Address object containing the school address
     */
    public Student(String first, String last, Address home, Address school) {
        firstName = first;
        lastName = last;
        homeAddress = home;
        schoolAddress = school;
        test1 = 0;
        test2 = 0;
        test3 = 0;
    }
  
    /**
     * Method to set the test scores of the student.
     * @param testNumber test# 1, 2 or 3
     * @param testScore test score of test 1, 2 or 3
     */
    public void setTestScore(int testNumber, int testScore) {
        switch(testNumber) {
            case 1:
                test1 = testScore;
                break;

            case 2:
                test2 = testScore;
                break;

            case three:
                test3 = testScore;
                break;

            default:
                return;

        }
    }
    
    /**
     * Method to get the test scores with each test of the student.
     * @param testNumber test# 1, 2 or 3
     * @return returns the test
     */
    public int getTestScore(int testNumber) {
        switch(testNumber) {
            case 1:
                return test1;

            case 2:
                return test2;

            case three:
                return test3;

            default:
                return 0;

        }
    }
    
    /**
     * Method to calculate the average score of the 3 tests of the
     * student.
     * @return average score of all three tests for student.
     */
    public double average() {
        averageScore = (test1 + test2 + test3) / (double) three;
        return averageScore;
    }
    
    
    /**
     * Returns a String description of this Student object.
     * @return description a String
     */
    public String toString() {
        String result;

        result = firstName + " " + lastName + "\n";
        result += "Home Address:\n" + homeAddress + "\n";
        result += "School Address:\n" + schoolAddress + "\n";
        result += "Test #1: " + test1 + "\n";
        result += "Test #2: " + test2 + "\n";
        result += "Test #3: " + test3 + "\n";
        result += "Average Score: " + averageScore;
        
        return result;
    }
}

